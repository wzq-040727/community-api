package com.neuedu.mall.pojo.vo.admin;

import com.alibaba.fastjson.annotation.JSONField;
import com.neuedu.mall.pojo.vo.base.RecursionVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "菜单Vo", description = "菜单Vo")
public class MenuVo extends RecursionVo<MenuVo> {
    private static final long serialVersionUID = -7522504986620020169L;

    @ApiModelProperty(value = "菜单名称")
    @JSONField(name = "name")
    private String menuName;
    @ApiModelProperty(value = "菜单组件")
    @JSONField(name = "component")
    private String menuComponent;
    @ApiModelProperty(value = "菜单图标")
    @JSONField(name = "icon")
    private String menuIcon;
    @ApiModelProperty(value = "菜单访问路径")
    @JSONField(name = "path")
    private String menuPath;

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getMenuComponent() {
        return menuComponent;
    }

    public void setMenuComponent(String menuComponent) {
        this.menuComponent = menuComponent;
    }

    public String getMenuIcon() {
        return menuIcon;
    }

    public void setMenuIcon(String menuIcon) {
        this.menuIcon = menuIcon;
    }

    public String getMenuPath() {
        return menuPath;
    }

    public void setMenuPath(String menuPath) {
        this.menuPath = menuPath;
    }
}
