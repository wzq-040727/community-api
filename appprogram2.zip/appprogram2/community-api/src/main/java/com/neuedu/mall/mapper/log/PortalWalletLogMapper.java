package com.neuedu.mall.mapper.log;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.log.PortalWalletLog;
import com.neuedu.mall.pojo.model.log.WalletLogSearchModel;
import com.neuedu.mall.pojo.vo.log.WalletLogVo;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface PortalWalletLogMapper extends BaseMapper<PortalWalletLog> {
    List<WalletLogVo> getWalletLogList(WalletLogSearchModel walletLogSearchModel);
}
