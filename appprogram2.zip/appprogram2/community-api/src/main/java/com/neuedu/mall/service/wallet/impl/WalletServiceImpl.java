package com.neuedu.mall.service.wallet.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.mall.constants.OrderConstants;
import com.neuedu.mall.constants.RespConstants;
import com.neuedu.mall.constants.WalletConstants;
import com.neuedu.mall.mapper.wallet.WalletMapper;
import com.neuedu.mall.pojo.dto.order.OrderDto;
import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.dto.user.UserDto;
import com.neuedu.mall.pojo.dto.wallet.WalletDto;
import com.neuedu.mall.pojo.entity.wallet.Wallet;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.log.PortalWalletLogModel;
import com.neuedu.mall.pojo.model.wallet.PaymentModel;
import com.neuedu.mall.pojo.model.wallet.WalletInitModel;
import com.neuedu.mall.pojo.model.wallet.WalletModel;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.pojo.vo.wallet.TransferConfirmVo;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.lock.DistributedLockService;
import com.neuedu.mall.service.log.LogService;
import com.neuedu.mall.service.sms.SmsService;
import com.neuedu.mall.service.user.UserService;
import com.neuedu.mall.service.wallet.WalletService;
import com.neuedu.mall.sysconfig.security.CurrentUser;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@Service
public class WalletServiceImpl extends BaseServiceImpl implements WalletService {
    private final static Logger logger = LoggerFactory.getLogger(WalletServiceImpl.class);

    @Autowired
    WalletMapper walletMapper;



    @Autowired
    DistributedLockService distributedLockService;

    @Autowired
    LogService logService;

    @Autowired
    UserService userService;

    @Autowired
    SmsService smsService;



    @Override
    @Transactional(readOnly = true)
    public RespVo<Object> walletBalance(BaseModel baseModel) throws Exception {
        Wallet wallet = getWallet(CurrentUser.getUserId());
        return RespVoHandle.setSuccess(wallet.getWalletBalance());
    }




    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> initWallet(WalletInitModel walletInitModel) throws Exception {
        // 新建钱包
        Wallet wallet = new Wallet();
        wallet.setWalletPassword(DigestUtils.md5Hex(walletInitModel.getWalletPassword()));
        wallet.setUserId(walletInitModel.getUserId());
        wallet.setWalletBalance(BigDecimal.ZERO);
        wallet.setCreateTime(new Date());
        walletMapper.insert(wallet);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(readOnly = true)
    public WalletDto walletInfo() throws Exception {
        Wallet wallet = getWallet(CurrentUser.getUserId());
        WalletDto walletDto = new WalletDto();
        BeanUtils.copyProperties(walletDto, wallet);
        return walletDto;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> recharge(WalletModel walletModel) throws Exception {
        Wallet wallet = getWallet(CurrentUser.getUserId());
        BigDecimal newBalance = wallet.getWalletBalance().add(walletModel.getAmount());
        wallet.setWalletBalance(newBalance);
        walletMapper.updateById(wallet);
        // 记录钱包使用日志
        saveLog(wallet, "WALLET_RECHARGE", walletModel.getAmount(), WalletConstants.WALLET_USE_TYPE_RECHARGE);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(readOnly = true)
    public RespVo<TransferConfirmVo> transferConfirm(WalletModel walletModel) throws Exception {
        UserDto targetUser = userService.getUserInfo(walletModel.getTargetPhone());
        if (Objects.isNull(targetUser) || Objects.isNull(targetUser.getId())) {
            return RespVoHandle.setBizError("对方用户不存在");
        }
        if (Objects.equals(targetUser.getId(), CurrentUser.getUserId())) {
            return RespVoHandle.setBizError("不允许给自己转账");
        }
        TransferConfirmVo confirmVo = new TransferConfirmVo();
        BeanUtils.copyProperties(confirmVo, targetUser);
        confirmVo.setAmount(walletModel.getAmount());
        return RespVoHandle.setSuccess(confirmVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> transfer(WalletModel walletModel) throws Exception {
        Wallet wallet = getWallet(CurrentUser.getUserId());
        BigDecimal newBalance = wallet.getWalletBalance().subtract(walletModel.getAmount());
        int compare = newBalance.compareTo(BigDecimal.ZERO);
        if (compare < 0) {
            return RespVoHandle.setBizError("余额不足，请充值");
        }
        wallet.setWalletBalance(newBalance);
        wallet.setUpdateTime(new Date());

        // 校验手机验证码
        SmsDto smsDto = new SmsDto();
        RespVo<Object> respVo = smsService.verifySms(smsDto);
        if (respVo.getCode() != RespConstants.MSG_CODE_SUCCESS) {
            return RespVoHandle.setBizError("短信验证码不正确");
        }
        // 对方钱包操作
        UserDto targetUser = userService.getUserInfo(walletModel.getTargetPhone());
        if (targetUser == null || targetUser.getId() == 0) {
            return RespVoHandle.setBizError("对方用户不存在");
        }
        Wallet targetWallet = getWallet(targetUser.getId());
        BigDecimal targetBalance = targetWallet.getWalletBalance().add(walletModel.getAmount());
        targetWallet.setWalletBalance(targetBalance);
        targetWallet.setUpdateTime(new Date());
        walletMapper.updateById(wallet);
        walletMapper.updateById(targetWallet);

        // 记录钱包使用日志
        saveLog(wallet, "WALLET_TRANSFER_OUT", walletModel.getAmount(), WalletConstants.WALLET_USE_TYPE_OUTER);
        saveLog(targetWallet, "WALLET_TRANSFER_IN", walletModel.getAmount(), WalletConstants.WALLET_USE_TYPE_ENTER);

        return RespVoHandle.setSuccess();
    }


    private Wallet getWallet(Integer userId) {
        QueryWrapper<Wallet> queryWrapper =
                new QueryWrapper<Wallet>().eq("user_id", userId);
        return walletMapper.selectOne(queryWrapper);
    }

    private void saveLog(Wallet wallet, String orderNo, BigDecimal amount, Integer type) throws Exception {
        PortalWalletLogModel walletLog = new PortalWalletLogModel();
        walletLog.setWalletId(wallet.getId());
        walletLog.setOrderNo(orderNo);
        walletLog.setAmount(amount);
        walletLog.setState(WalletConstants.WALLET_USE_STATE_SUCCESS);
        walletLog.setType(type);
        walletLog.setCreateTime(new Date());
        logService.saveWalletLog(walletLog);
    }
}
