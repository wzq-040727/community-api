package com.neuedu.mall.utils;

import java.util.List;

public class UrlUtils {
    public static boolean needAuthorizeFilter(String urlx)
    {
        UrlFilter urlFilter = new UrlFilter();
        List<String> list = urlFilter.getUnAuthorizeFilter();
        String url = urlx.split("\\?")[0];
        for (String urlRes : list) {
            if (urlRes.startsWith("end:")) {
                String v = urlRes.split(":")[1];
                if (url.endsWith(v)) {
                    return false;
                }
                if (url.contains("." + v + "?")) {
                    return false;
                }
            }
            else if (url.contains(urlRes)) {
                return false;
            }
        }
        return true;
    }
}
