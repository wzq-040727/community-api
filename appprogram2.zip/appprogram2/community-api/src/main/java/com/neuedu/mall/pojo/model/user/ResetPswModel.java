package com.neuedu.mall.pojo.model.user;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "重置密码入参对象", description = "重置密码入参对象")
public class ResetPswModel extends BaseModel
{
    private static final long serialVersionUID = 1552024416456436087L;

    @ApiModelProperty(value = "用户id", required = true)
    private int userId;
    @ApiModelProperty(value = "手机号码", required = true)
    private String phone;
    @ApiModelProperty(value = "密码", required = true)
    private String userPassword;
    @ApiModelProperty(value = "手机验证码", required = true)
    private String verCode;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getVerCode() {
        return verCode;
    }

    public void setVerCode(String verCode) {
        this.verCode = verCode;
    }
}
