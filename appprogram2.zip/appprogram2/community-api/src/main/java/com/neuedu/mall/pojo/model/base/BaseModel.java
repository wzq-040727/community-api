package com.neuedu.mall.pojo.model.base;

import com.neuedu.mall.pojo.vo.user.CoreUserVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

@ApiModel(value = "公共入参", description = "公共入参")
public class BaseModel implements Serializable {
    private static final long serialVersionUID = -8412540586044564938L;

    @ApiModelProperty(value = "当前页码")
    private int pageNum;
    @ApiModelProperty(value = "每页记录数")
    private int pageSize;
    @ApiModelProperty(value = "访问者ip", hidden = true)
    private String clientIp;
    @ApiModelProperty(value = "当前登录用户:无需传入，系统自动注入", hidden = true)
    private CoreUserVo currentUser;

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public CoreUserVo getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(CoreUserVo currentUser) {
        this.currentUser = currentUser;
    }
}
