package com.neuedu.mall.sysconfig.aspect;

import com.github.pagehelper.PageHelper;
import com.neuedu.mall.pojo.model.base.BaseModel;
import org.apache.commons.lang3.ObjectUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;

@Configuration
@Aspect
public class StartPageAspect {
    /**
     * 定义切入点
     */
    @Pointcut("@annotation(com.neuedu.mall.sysconfig.annotation.StartPage)")
    public void StartPage() {
    }

    @Around("StartPage()")
    public Object doAround(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        int vPageNum = 1;
        int vPageSize = 10;
        BaseModel baseModel;
        // 获取传入参数中的分页信息
        Object[] args = proceedingJoinPoint.getArgs();
        for (Object arg : args) {
            if(arg instanceof BaseModel) {
                baseModel = (BaseModel) arg;
                vPageNum= ObjectUtils.isEmpty(baseModel.getPageNum()) ? vPageNum : baseModel.getPageNum();
                vPageSize=ObjectUtils.isEmpty(baseModel.getPageSize())? vPageSize : baseModel.getPageSize();
                break;
            }
        }
        PageHelper.startPage(vPageNum, vPageSize);
        return proceedingJoinPoint.proceed();
    }
}
