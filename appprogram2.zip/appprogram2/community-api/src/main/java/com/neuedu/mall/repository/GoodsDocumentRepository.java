package com.neuedu.mall.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.neuedu.mall.pojo.document.GoodsDocument;

public interface GoodsDocumentRepository extends ElasticsearchRepository<GoodsDocument, Integer> {

}
