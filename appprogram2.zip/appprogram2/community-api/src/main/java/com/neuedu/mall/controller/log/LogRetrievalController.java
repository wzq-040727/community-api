package com.neuedu.mall.controller.log;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.dto.log.GoodsBrowseLogDto;
import com.neuedu.mall.pojo.model.log.WalletLogSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.log.WalletLogVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.service.log.LogRetrievalService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@Api(tags = "日志检索")
@RequestMapping("/log/retrieval")
public class LogRetrievalController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(LogRetrievalController.class);

    @Autowired
    LogRetrievalService logRetrievalService;

    @PostMapping(value = "/wallet/list")
    @ApiOperation(value = "查询钱包使用记录", notes = "查询钱包使用记录")
    public RespVo<PagerVo<WalletLogVo>> walletLogList(HttpServletRequest request, @RequestBody WalletLogSearchModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("日志管理-查询钱包使用记录");
            }
            return logRetrievalService.walletLogList(reqParams);
        } catch (Exception ex) {
            throw new CoreException("日志管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/goods/browse/list")
    @ApiOperation(value = "查询商品浏览记录Top10", notes = "查询商品浏览记录Top10")
    public List<GoodsBrowseLogDto> goodsBrowseList(HttpServletRequest request)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("日志管理-查询商品浏览记录Top10");
            }
            return logRetrievalService.goodsBrowseList();
        } catch (Exception ex) {
            throw new CoreException("日志管理：发生系统异常", ex);
        }
    }
}
