package com.neuedu.mall.mapper.user;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.user.Area;
import com.neuedu.mall.pojo.model.user.AreaModel;
import com.neuedu.mall.pojo.vo.user.AreaVo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AreaMapper extends BaseMapper<Area> {
    List<AreaVo> queryAreaList(AreaModel areaModel);
}
