package com.neuedu.mall.sysconfig.interceptor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CustomInterceptorConfig implements WebMvcConfigurer {
    //所有的WebMvcConfigurerAdapter组件都会一起起作用
    @Bean //将组件注册在容器中
    public CustomInterceptorConfig webMvcConfigurerAdapter() {
        return new CustomInterceptorConfig(){
            @Override
            public void addInterceptors(InterceptorRegistry registry){
                registry.addInterceptor(new CustomHandlerInterceptor());
            }
        };
    }
}
