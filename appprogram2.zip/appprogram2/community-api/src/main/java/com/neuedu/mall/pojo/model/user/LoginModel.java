package com.neuedu.mall.pojo.model.user;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "登录入参对象", description = "登录入参对象")
public class LoginModel extends BaseModel {
    private static final long serialVersionUID = -5005286087425777134L;

    @ApiModelProperty(value = "手机号码")
    private String phone;
    @ApiModelProperty(value = "密码")
    private String userPassword;
    @ApiModelProperty(value = "身份类型")
    private String identityType;

}
