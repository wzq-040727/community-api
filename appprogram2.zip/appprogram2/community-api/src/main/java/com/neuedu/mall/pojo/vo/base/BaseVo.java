package com.neuedu.mall.pojo.vo.base;

import java.io.Serializable;

public class BaseVo implements Serializable {
    private static final long serialVersionUID = 2853858916142896725L;
}
