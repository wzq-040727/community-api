package com.neuedu.mall.constants;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SecurityConstants {
    public final static String base64Security = "ODgwYTA0NTUtYmYwNS0xMWVkLWE1MmEtOWMyZGNkY2I0NTU5";

    public final static long expiresIn = 18000000;

    public final static String issuer = "neuedu-cloud";

    public final static List<String> audiences = Stream.of("97deab8e-bf05-11ed-a52a-9c2dcdcb4559",
            "9f2bcde3-bf05-11ed-a52a-9c2dcdcb4559", "a2e1dc5b-bf05-11ed-a52a-9c2dcdcb4559").collect(Collectors.toList());

    public final static String tokenType = "bearer";

    public final static List<String> unSecurityUrlList = Stream.of(
            "/register",
            "/login",
            "/check",
            "/password/reset",
            "/goods/list/search",
            "/category/tree",
            "/carts/count",
            "/area/tree",
            "/goods/data",
            "/goods/store/query",
            "/store/goods/select",
            "/special/range",
            "/special/entry",
            "swagger-ui.html",
        "webjars/springfox-swagger-ui",
            "swagger-resources",
            "csrf",
            "error",
            "swagger-resources/configuration/security").collect(Collectors.toList());

    public static boolean isSecurityUrl(String url){
        boolean flag = true;
        for(String vUrl : unSecurityUrlList){
            if (url.contains(vUrl)) {
                flag = false;
                break;
            }
        }
        return flag;
    }
}

