package com.neuedu.mall.service.sms.impl;

import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.enums.SmsSender;
import com.neuedu.mall.pojo.model.sms.SmsModel;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.cache.CacheService;
import com.neuedu.mall.service.sms.SmsService;
import com.neuedu.mall.utils.SequenceUtils;
import com.neuedu.mall.utils.sms.factory.SmsFactory;
import com.neuedu.mall.utils.sms.product.ISmsService;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;

@Service
public class SmsServiceImpl extends BaseServiceImpl implements SmsService {
    private final static Logger logger = LoggerFactory.getLogger(SmsServiceImpl.class);

    private final static String SMS_CACHE_KEY_TEMPLATE = "cache:sms:{0}";

    private final static int SMS_CACHE_OVERDUE_TIME = 5;

    @Autowired
    CacheService cacheService;

    @Override
    public RespVo<Object> sendSms(SmsModel smsModel) throws Exception {
        SmsDto smsDto = new SmsDto();
        BeanUtils.copyProperties(smsDto, smsDto);
        // 1.生成验证码
        String validNumber = SequenceUtils.creatNumber(6);
        // 2.设置短信内容
        smsDto.setContent("您的短信验证码：" + validNumber);
        // 获取短信工厂
        SmsFactory smsFactory = SmsFactory.getFactory();
        ISmsService service = smsFactory.getService(SmsSender.ALI);
        // 设置缓存
        String cacheKey = MessageFormat.format(SMS_CACHE_KEY_TEMPLATE, smsDto.getPhone());
        cacheService.opsForValueInterval(cacheKey, validNumber, SMS_CACHE_OVERDUE_TIME);
        service.sendSms(smsDto);
        return RespVoHandle.setSuccess();
    }

    @Override
    public RespVo<Object> verifySms(SmsDto smsDto) throws Exception {
//        String cacheKey = MessageFormat.format(SMS_CACHE_KEY_TEMPLATE, smsDto.getPhone());
//        String validNumber = (String) cacheService.getValue(cacheKey);
//        if (StringUtils.isBlank(validNumber) || !Objects.equals(smsDto.getValidNumber(), validNumber)){
//            return RespVoHandle.setBizError("验证码错误");
//        }
//        cacheService.deleteValue(cacheKey);
        return RespVoHandle.setSuccess();
    }
}
