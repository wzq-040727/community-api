package com.neuedu.mall.utils;

import java.util.ArrayList;
import java.util.List;

public class UrlFilter {
    private List<String> unAuthorizeFilter = new ArrayList<>();
    private List<String> unCheckXmlFilter = new ArrayList<>();

    public List<String> getUnAuthorizeFilter()
    {
        return this.unAuthorizeFilter;
    }

    public void setUnAuthorizeFilter(List<String> unAuthorizeFilter) {
        this.unAuthorizeFilter = unAuthorizeFilter;
    }

    public List<String> getUnCheckXmlFilter() {
        return this.unCheckXmlFilter;
    }

    public void setUnCheckXmlFilter(List<String> unCheckXmlFilter) {
        this.unCheckXmlFilter = unCheckXmlFilter;
    }
}
