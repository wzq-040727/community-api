package com.neuedu.mall.utils.convert;

import org.apache.commons.beanutils.Converter;
import org.apache.commons.lang3.time.DateUtils;

import java.text.SimpleDateFormat;

@SuppressWarnings("unchecked")
public class CustomerDateConvert implements Converter{
    public Object convert(Class arg0, Object arg1)
    {
        try
        {
            if ((arg1 != null) && (!"".equals(arg1))) {
                if ((arg1 instanceof java.util.Date)) {
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                    return df.parse(df.format(new java.util.Date(((java.util.Date)arg1).getTime())));
                }
                if ((arg1 instanceof Long)) {
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    return df.parse(df.format(arg1));
                }
                String[] pattern = { "yyyy-MM", "yyyyMM", "yyyy/MM", "yyyyMMdd", "yyyy.MM.dd", "yyyy-MM-dd", "yyyy/MM/dd", "yyyyMMddHHmmss", "yyyy.MM.dd HH.mm.ss", "yyyy-MM-dd HH:mm:ss", "yyyy/MM/dd HH:mm:ss" };
                if ((arg1 instanceof Object[])) {
                    Object[] at = (Object[])(Object[])arg1;
                    if ((at[0] != null) && (!at[0].equals(""))) {
                        return DateUtils.parseDate(at[0].toString(), pattern);
                    }
                    return null;
                }

                return DateUtils.parseDate(arg1.toString(), pattern);
            }

            return null;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return arg1;
    }
}
