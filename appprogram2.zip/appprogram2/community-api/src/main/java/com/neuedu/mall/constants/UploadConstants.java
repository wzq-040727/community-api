package com.neuedu.mall.constants;

public class UploadConstants {
    // 文件类型-图片
    public final static String FILE_TYPE_PORTRAIT = "Y";
    public final static String NO = "N";
}
