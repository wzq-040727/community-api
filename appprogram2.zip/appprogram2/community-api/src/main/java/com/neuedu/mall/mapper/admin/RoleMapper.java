package com.neuedu.mall.mapper.admin;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.admin.Role;
import com.neuedu.mall.pojo.model.admin.RoleModel;
import com.neuedu.mall.pojo.vo.admin.RoleVo;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface RoleMapper extends BaseMapper<Role> {
    List<RoleVo> getRoleList(RoleModel roleModel);
}
