package com.neuedu.mall.pojo.vo.user;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "CoreTokenVo:令牌信息")
public class CoreTokenVo extends BaseVo {
    private static final long serialVersionUID = -8407221728725435203L;

    @ApiModelProperty(value = "访问令牌")
    private String accessToken;

    @ApiModelProperty(value = "令牌过期时间")
    private String expiresIn;

    @ApiModelProperty(value = "令牌类型")
    private String tokenType;

    @ApiModelProperty(value = "登录用户信息")
    private CoreUserVo userInfo;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public CoreUserVo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(CoreUserVo userInfo) {
        this.userInfo = userInfo;
    }
}
