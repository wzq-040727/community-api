package com.neuedu.mall.pojo.model.goods;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "收藏查询条件", description = "收藏查询条件")
public class FavoritesModel extends BaseModel {
    private static final long serialVersionUID = 4628128700354292041L;

    @ApiModelProperty(value = "商品编号")
    private String goodsNo;

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }
}
