package com.neuedu.mall.service.search;

import com.neuedu.mall.pojo.dto.goods.GoodsDto;
import com.neuedu.mall.pojo.model.goods.GoodsSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.goods.GoodsVo;
import com.neuedu.mall.pojo.vo.response.RespVo;

import java.util.List;

/**
 * 搜索服务接口
 *
 * @author mazh
 */
public interface SearchService {
    /**
     * 搜索服务接口-获取商品列表(ES)
     *
     * @param reqParams GoodsSearchModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<PagerVo<GoodsVo>> searchGoodsList(GoodsSearchModel reqParams) throws Exception;

    /**
     * 搜索服务接口-根据商品编号更新ES搜索信息
     *
     * @param goodsDtoList List<GoodsDto>
     * @throws Exception 异常.
     */
    RespVo<Object> updateGoodsSearchInfo(List<GoodsDto> goodsDtoList) throws Exception;

    /**
     * 搜索服务接口-将所有商品放入ES
     *
     * @throws Exception 异常.
     */
    void insertAllGoods() throws Exception;
}
