package com.neuedu.mall.service.user;

import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.user.AreaModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.user.AreaTreeVo;
import com.neuedu.mall.pojo.vo.user.AreaVo;

import java.util.List;

/**
 * 区域服务接口
 * 
 * @author mazh
 */
public interface AreaService {
    /**
     * 区域服务接口-获取区域树形列表
     *
     * @param baseModel BaseModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<List<AreaTreeVo>> getAreaTree(BaseModel baseModel) throws Exception;

    /**
     * 区域服务接口-管理端获取区域列表
     *
     * @param areaModel AreaModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<PagerVo<AreaVo>> getAreaList(AreaModel areaModel) throws Exception;

    /**
     * 区域服务接口-增加区域
     *
     * @param areaModel AreaModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> addArea(AreaModel areaModel) throws Exception;

    /**
     * 区域服务接口-删除区域
     *
     * @param areaModel AreaModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> deleteArea(AreaModel areaModel) throws Exception;

    /**
     * 区域服务接口-修改区域
     *
     * @param areaModel AreaModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> updateArea(AreaModel areaModel) throws Exception;
}
