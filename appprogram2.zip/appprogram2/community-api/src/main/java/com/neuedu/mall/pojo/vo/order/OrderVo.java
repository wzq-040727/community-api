package com.neuedu.mall.pojo.vo.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@ApiModel(value = "OrderVo:订单信息")
public class OrderVo extends BaseVo {
    private static final long serialVersionUID = 3756545384356438417L;

    @ApiModelProperty(value = "订单id")
    private Integer id;
    @ApiModelProperty(value = "订单编号")
    private String orderNo;
    @ApiModelProperty(value = "订单总金额")
    private BigDecimal totalPrice;
    @ApiModelProperty(value = "订单支付类型")
    private Integer paymentType;
    @ApiModelProperty(value = "订单支付方式")
    private Integer paymentSubtype;
    @ApiModelProperty(value = "送货方式")
    private Integer deliveryType;
    @ApiModelProperty(value = "订单状态")
    private Integer orderState;
    @ApiModelProperty(value = "订单创建时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    @ApiModelProperty(value = "订单修改时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    @ApiModelProperty(value = "订单商品详情")
    private List<OrderDetailVo> orderDetailVoList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    public Integer getPaymentSubtype() {
        return paymentSubtype;
    }

    public void setPaymentSubtype(Integer paymentSubtype) {
        this.paymentSubtype = paymentSubtype;
    }

    public Integer getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(Integer deliveryType) {
        this.deliveryType = deliveryType;
    }

    public Integer getOrderState() {
        return orderState;
    }

    public void setOrderState(Integer orderState) {
        this.orderState = orderState;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public List<OrderDetailVo> getOrderDetailVoList() {
        return orderDetailVoList;
    }

    public void setOrderDetailVoList(List<OrderDetailVo> orderDetailVoList) {
        this.orderDetailVoList = orderDetailVoList;
    }
}
