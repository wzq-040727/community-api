package com.neuedu.mall.pojo.model.community;

import com.neuedu.mall.pojo.model.base.PagerModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "物业账单入参")
public class ChargeModel extends PagerModel {
    private static final long serialVersionUID = -8923068161657551891L;

    @ApiModelProperty("id")
    private int id;
    @ApiModelProperty("缴费状态")
    private Integer chargeStatus;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getChargeStatus() {
        return chargeStatus;
    }

    public void setChargeStatus(Integer chargeStatus) {
        this.chargeStatus = chargeStatus;
    }
}
