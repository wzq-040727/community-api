package com.neuedu.mall.service.admin;

import com.neuedu.mall.pojo.model.admin.RoleMenuModel;
import com.neuedu.mall.pojo.model.admin.RoleModel;
import com.neuedu.mall.pojo.model.admin.RoleUserModel;
import com.neuedu.mall.pojo.vo.admin.RoleMenuVo;
import com.neuedu.mall.pojo.vo.admin.RoleUserVo;
import com.neuedu.mall.pojo.vo.admin.RoleVo;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;

import java.util.List;

/**
 * 权限管理服务接口.
 *
 * @author mazh.
 */
public interface RoleManageService {
    /**
     * 权限管理服务接口-获取全部角色
     *
     * @param roleModel RoleModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<PagerVo<RoleVo>> getRoleList(RoleModel roleModel) throws Exception;

    /**
     * 权限管理服务接口-获取全部角色-不分页
     *
     * @param roleModel RoleModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<List<RoleVo>> getAllRoleList(RoleModel roleModel) throws Exception;


    /**
     * 权限管理服务接口-新增角色
     *
     * @param roleModel RoleModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> addRole(RoleModel roleModel) throws Exception;

    /**
     * 权限管理服务接口-修改角色
     *
     * @param roleModel RoleModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> updateRole(RoleModel roleModel) throws Exception;

    /**
     * 权限管理服务接口-获取角色和菜单菜单关联信息
     *
     * @param roleModel RoleModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<RoleMenuVo> roleMenuList(RoleModel roleModel) throws Exception;

    /**
     * 权限管理服务接口-保存角色和菜单菜单关联信息
     *
     * @param roleMenuModel RuleMenuModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> saveRoleMenuLink(RoleMenuModel roleMenuModel) throws Exception;

    /**
     * 权限管理服务接口-获取全部用户
     *
     * @param roleUserModel RoleUserModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<PagerVo<RoleUserVo>> getUserList(RoleUserModel roleUserModel) throws Exception;

    /**
     * 权限管理服务接口-保存角色和用户关联信息
     *
     * @param roleUserModel RoleUserModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> saveRoleUserLink(RoleUserModel roleUserModel) throws Exception;
}
