package com.neuedu.mall.utils;

import org.apache.commons.beanutils.BeanUtils;

public class BeanUtilsEx {
    public static boolean hasProperty(Object obj, String name) {
        try {
            BeanUtils.getProperty(obj, name);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}
