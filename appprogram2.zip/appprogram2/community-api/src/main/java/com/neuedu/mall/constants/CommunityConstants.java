package com.neuedu.mall.constants;

public class CommunityConstants {
    public static final Integer COMPLAINT_STATUS_BEFORE_HANDLE = 0;
    public static final Integer COMPLAINT_STATUS_AFTER_HANDLE = 1;
    public static final Integer PARKING_TYPE_UNDERGROUND = 1;
    public static final Integer PARKING_TYPE_ON_THE_GROUND = 2;
    public static final Integer PARKING_STATUS_DISABLE = 0;
    public static final Integer PARKING_STATUS_ENABLE = 1;
    public static final Integer VISITOR_STATUS_UN_USING = 0;
    public static final Integer VISITOR_STATUS_USING = 1;
    public static final Integer CHARGE_STATUS_BEFORE_PAY = 0;
    public static final Integer CHARGE_STATUS_AFTER_PAY = 1;
}
