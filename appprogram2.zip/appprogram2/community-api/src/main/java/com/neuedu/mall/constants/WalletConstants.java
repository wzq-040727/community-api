package com.neuedu.mall.constants;

public class WalletConstants {
    // 钱包使用状态-成功
    public final static Integer WALLET_USE_STATE_SUCCESS = 1;
    // 钱包使用状态-失败
    public final static Integer WALLET_USE_STATE_FAILED = 2;
    // 钱包使用类型-商品支付
    public final static Integer WALLET_USE_TYPE_PAYMENT = 1;
    // 钱包使用类型-充值
    public final static Integer WALLET_USE_TYPE_RECHARGE = 2;
    // 钱包使用类型-转入
    public final static Integer WALLET_USE_TYPE_ENTER = 3;
    // 钱包使用类型-转出
    public final static Integer WALLET_USE_TYPE_OUTER = 4;
    // 钱包使用类型-退款
    public final static Integer WALLET_USE_TYPE_REFUND = 5;
    // 钱包使用类型-物业缴费
    public final static Integer WALLET_USE_TYPE_CHARGE = 6;
}
