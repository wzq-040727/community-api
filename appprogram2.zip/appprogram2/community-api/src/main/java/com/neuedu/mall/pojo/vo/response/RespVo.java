package com.neuedu.mall.pojo.vo.response;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;

/**
 * 响应值对象类，用于封装API响应数据
 * 包含响应码、响应体、类型、描述和消息等字段
 * 支持泛型，可以灵活处理不同的响应体类型
 */
public class RespVo<T> implements Serializable {
    private static final long serialVersionUID = 2140298130784359588L;

    // 响应状态码
    private int code;
    // 响应主体数据，支持泛型
    private T body;
    // 响应类型
    private String type;
    // 响应描述信息
    private Object desc;
    // 响应消息
    private Object msg;

    public Object getMsg() {
        return this.msg;
    }

    public void setMsg(Object msg) {
        this.msg = msg;
    }

    public RespVo() {
    }

    public RespVo(int code, T body, String type, String desc, Object msg) {
        this.code = code;
        this.body = body;
        this.type = type;
        this.desc = desc;
        this.msg = msg;
    }

    /**
     * 将响应对象转换为JSON字符串
     * @return JSON格式的字符串表示
     */
    public String toJSONString() {
        JSONObject msgTemp = new JSONObject();
        msgTemp.put("code", this.code);
        msgTemp.put("body", this.body);
        msgTemp.put("desc", this.desc);
        msgTemp.put("msg", this.msg);
        return msgTemp.toJSONString();
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public T getBody() {
        return this.body;
    }

    public void setBody(T body) {
        this.body = body;
    }

    public Object getDesc() {
        return this.desc;
    }

    public void setDesc(Object desc) {
        this.desc = desc;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
