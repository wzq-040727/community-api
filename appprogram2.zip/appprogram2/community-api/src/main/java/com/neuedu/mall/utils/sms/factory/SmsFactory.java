package com.neuedu.mall.utils.sms.factory;


import com.neuedu.mall.pojo.enums.SmsSender;
import com.neuedu.mall.utils.sms.product.ISmsService;
import com.neuedu.mall.utils.sms.product.impl.AliSmsServiceImpl;
import com.neuedu.mall.utils.sms.product.impl.RlYtxSmsServiceImpl;

import java.util.EnumMap;
import java.util.Map;

/**
 * @author mazh.
 * @note 短信工厂
 */
public class SmsFactory {
	private final Map<SmsSender, ISmsService> map = new EnumMap<>(SmsSender.class);

	public SmsFactory(){
		this.map.put(SmsSender.RL_YTX, new RlYtxSmsServiceImpl());
		this.map.put(SmsSender.ALI, new AliSmsServiceImpl());
	}

	public static SmsFactory getFactory(){
		return new SmsFactory();
	}

	public ISmsService getService(SmsSender argType){
		return map.get(argType);
	}
}
