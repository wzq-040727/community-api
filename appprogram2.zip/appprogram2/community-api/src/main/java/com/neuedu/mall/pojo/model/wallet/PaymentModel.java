package com.neuedu.mall.pojo.model.wallet;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "支付服务入参", description = "支付服务入参")
public class PaymentModel extends BaseModel {
    private static final long serialVersionUID = -7475783132274457412L;

    @ApiModelProperty(value = "订单号")
    private String orderNo;
    @ApiModelProperty(value = "物业缴费订单号")
    private String chargeNo;
    @ApiModelProperty(value = "钱包密码")
    private String walletPassword;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getChargeNo() {
        return chargeNo;
    }

    public void setChargeNo(String chargeNo) {
        this.chargeNo = chargeNo;
    }

    public String getWalletPassword() {
        return walletPassword;
    }

    public void setWalletPassword(String walletPassword) {
        this.walletPassword = walletPassword;
    }
}
