package com.neuedu.mall.mapper.wallet;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.wallet.Wallet;
import org.springframework.stereotype.Repository;

@Repository
public interface WalletMapper extends BaseMapper<Wallet> {
}
