package com.neuedu.mall.pojo.vo.goods;

import java.util.List;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "GoodsDataVo:商品详细信息")
public class GoodsDataVo extends BaseVo {
    private static final long serialVersionUID = 5636584753270866472L;
    @ApiModelProperty(value = "id")
    private int id;
    @ApiModelProperty(value = "商品编号")
    private String goodsNo;
    @ApiModelProperty(value = "商品名称")
    private String goodsName;
    @ApiModelProperty(value = "商品介绍")
    private String goodsIntroduce;
    @ApiModelProperty(value = "商品详细说明")
    private String goodsContent;
    @ApiModelProperty(value = "图片列表")
    private List<GoodsPictureVo> pictures;
    @ApiModelProperty(value = "价格信息")
    private GoodsPriceVo prices;
    @ApiModelProperty(value = "收藏次数")
    private int favoritesCnt;
    @ApiModelProperty(value = "当前用户是否收藏")
    private String isFavorites;
    @ApiModelProperty(value = "销量")
    private int salesCount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getGoodsIntroduce() {
        return goodsIntroduce;
    }

    public void setGoodsIntroduce(String goodsIntroduce) {
        this.goodsIntroduce = goodsIntroduce;
    }

    public String getGoodsContent() {
        return goodsContent;
    }

    public void setGoodsContent(String goodsContent) {
        this.goodsContent = goodsContent;
    }

    public List<GoodsPictureVo> getPictures() {
        return pictures;
    }

    public void setPictures(List<GoodsPictureVo> pictures) {
        this.pictures = pictures;
    }

    public GoodsPriceVo getPrices() {
        return prices;
    }

    public void setPrices(GoodsPriceVo prices) {
        this.prices = prices;
    }

    public int getFavoritesCnt() {
        return favoritesCnt;
    }

    public void setFavoritesCnt(int favoritesCnt) {
        this.favoritesCnt = favoritesCnt;
    }

    public String getIsFavorites() {
        return isFavorites;
    }

    public void setIsFavorites(String isFavorites) {
        this.isFavorites = isFavorites;
    }

    public int getSalesCount() {
        return salesCount;
    }

    public void setSalesCount(int salesCount) {
        this.salesCount = salesCount;
    }
}
