package com.neuedu.mall.utils.sms.product.impl;

import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.enums.SmsSender;
import com.neuedu.mall.utils.sms.product.ISmsService;

public class RlYtxSmsServiceImpl implements ISmsService {

    @Override
    public void setProperty(SmsSender key, String value) throws Exception {

    }

    @Override
    public boolean sendSms(SmsDto smsDto) throws Exception {
        System.out.println("发送成功");
        return true;
    }
}
