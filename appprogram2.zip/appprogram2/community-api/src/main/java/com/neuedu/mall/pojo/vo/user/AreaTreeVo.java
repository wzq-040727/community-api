package com.neuedu.mall.pojo.vo.user;


import com.neuedu.mall.pojo.vo.base.RecursionVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "AreaTreeVo:区域信息")
public class AreaTreeVo extends RecursionVo<AreaTreeVo> {
    private static final long serialVersionUID = -6150030330841069374L;

    @ApiModelProperty(value = "区域id")
    private int areaId;
    @ApiModelProperty(value = "区域编号")
    private String areaNo;
    @ApiModelProperty(value = "区域名称")
    private String areaName;
    @ApiModelProperty(value = "类型")
    private int areaType;

    public int getAreaId() {
        return areaId;
    }

    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public String getAreaNo() {
        return areaNo;
    }

    public void setAreaNo(String areaNo) {
        this.areaNo = areaNo;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public int getAreaType() {
        return areaType;
    }

    public void setAreaType(int areaType) {
        this.areaType = areaType;
    }
}
