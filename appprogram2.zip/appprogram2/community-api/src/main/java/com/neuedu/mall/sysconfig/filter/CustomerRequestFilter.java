package com.neuedu.mall.sysconfig.filter;

import com.neuedu.mall.utils.UrlUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.xml.xss.request.CustomerHttpRequestWrapper;
import org.springframework.xml.xss.request.CustomerHttpRequestWrapperBodyHandler;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class CustomerRequestFilter implements Filter {
    private final static Logger logger = LoggerFactory.getLogger(CustomerRequestFilter.class);

    public CustomerHttpRequestWrapperBodyHandler customerHttpRequestWrapperBodyHandler;

    public CustomerHttpRequestWrapperBodyHandler getCustomerHttpRequestWrapperBodyHandler()
    {
        return this.customerHttpRequestWrapperBodyHandler;
    }

    public void setCustomerHttpRequestWrapperBodyHandler(CustomerHttpRequestWrapperBodyHandler customerHttpRequestWrapperBodyHandler) {
        this.customerHttpRequestWrapperBodyHandler = customerHttpRequestWrapperBodyHandler;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        String url = null;
        try {
            HttpServletRequest req = (HttpServletRequest)request;
            url = req.getRequestURL().toString();
            if (!UrlUtils.needAuthorizeFilter(url)) {
                chain.doFilter(request, response);
            } else {
                String contentType = request.getContentType();
                if ((contentType != null) && ((contentType.contains("x-www-form-urlencoded")) || (contentType.contains("form-data")))) {
                    chain.doFilter(request, response);
                }
                else
                {
                    CustomerHttpRequestWrapper xssRequest;
                    if (this.customerHttpRequestWrapperBodyHandler != null) {
                        xssRequest = new CustomerHttpRequestWrapper((HttpServletRequest)request, this.customerHttpRequestWrapperBodyHandler);
                    } else {
                        xssRequest = new CustomerHttpRequestWrapper((HttpServletRequest)request);
                    }
                    chain.doFilter(xssRequest, response);
                }
            }
        }
        catch (Exception e) {
            logger.error("[CustomerRequestFilter-doFilter]：过滤器异常, 异常url: " + url, e);
            throw new ServletException(e);
        }
    }

    @Override
    public void destroy() {

    }
}
