package com.neuedu.mall.sysconfig.datasource;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect
@Component
@Order(1)
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class DataSourceAspect {
    /**
     * 切入点 admin 包以及子孙包下的所有类
     */
    @Pointcut("execution(* com.neuedu.mall.*..*.*(..))")
    public void aspect() {}

    // 前置方法
    @Before("aspect()")
    public void before(JoinPoint point) {
        MethodSignature signature = (MethodSignature)point.getSignature();
        Method method = signature.getMethod();
        DataSource dataSource = null;
        // 获取方法注解
        if (method != null && method.isAnnotationPresent(DataSource.class)) {
            dataSource = method.getAnnotation(DataSource.class);
        }
        if (dataSource != null && StringUtils.isNotEmpty(dataSource.value())) {
            DataSourceRouter.setDataSource(dataSource.value());
        }
    }

    // 后置方法
    @After("aspect()")
    public void after(JoinPoint point) {
        // 清空配置,避免对以后的Service 产生影响
        DataSourceRouter.clearDataSource();
    }
}