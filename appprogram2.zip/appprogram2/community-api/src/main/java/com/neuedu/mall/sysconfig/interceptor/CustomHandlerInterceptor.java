package com.neuedu.mall.sysconfig.interceptor;

import com.neuedu.mall.constants.SecurityConstants;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.sysconfig.security.JwtHelper;
import io.jsonwebtoken.Claims;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class CustomHandlerInterceptor implements HandlerInterceptor {
    private final static Logger logger = LoggerFactory.getLogger(CustomHandlerInterceptor.class);

    //目标方法执行之前
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = null;
        String msg;
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset = UTF-8");
        try {
            if (!SecurityConstants.isSecurityUrl(request.getRequestURI())){
                return true;
            }
            token = request.getHeader("x-access-token");
            if (StringUtils.isBlank(token)){
                msg = "accessToken为空，请求被拒绝！";
                logger.error(msg);
                RespVo<Object> respVo = RespVoHandle.setTokenError(msg);
                response.getOutputStream().write(respVo.toJSONString().getBytes());
                return false;
            }
            Claims claims = JwtHelper.parseJWT(token, SecurityConstants.base64Security);
            if (claims == null){
                msg = "accessToken超时或无效，请求被拒绝！";
                logger.error(msg);
                RespVo<Object> respVo = RespVoHandle.setTokenError(msg);
                response.getOutputStream().write(respVo.toJSONString().getBytes());
                return false;
            }
            return true;
        }
        catch (Exception ex){
            msg = "[CustomHandlerInterceptor-preHandle]：拦截器Token处理异常，异常为：" + ex.getMessage();
            logger.error(msg, ex);
            RespVo<Object> respVo = RespVoHandle.setError(msg);
            response.getOutputStream().write(respVo.toJSONString().getBytes());
            return false;
        }


    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
    }
}
