package com.neuedu.mall.mapper.user;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.user.User;
import com.neuedu.mall.pojo.model.user.LoginModel;
import com.neuedu.mall.pojo.model.user.UserInfoModel;
import com.neuedu.mall.pojo.vo.user.CoreUserVo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper extends BaseMapper<User> {

    CoreUserVo queryUserInfo(LoginModel loginModel);


}
