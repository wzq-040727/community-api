package com.neuedu.mall.pojo.model.community;

import com.neuedu.mall.pojo.model.base.PagerModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "车位管理入参")
public class ParkingModel extends PagerModel {
    private static final long serialVersionUID = -8374075180007077681L;

    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("车位名称")
    private String parkingName;
    @ApiModelProperty("车位类型")
    private Integer parkingType;
    @ApiModelProperty("车位状态")
    private Integer parkingStatus;
    @ApiModelProperty("车牌号")
    private String licensePlate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getParkingName() {
        return parkingName;
    }

    public void setParkingName(String parkingName) {
        this.parkingName = parkingName;
    }

    public Integer getParkingType() {
        return parkingType;
    }

    public void setParkingType(Integer parkingType) {
        this.parkingType = parkingType;
    }

    public Integer getParkingStatus() {
        return parkingStatus;
    }

    public void setParkingStatus(Integer parkingStatus) {
        this.parkingStatus = parkingStatus;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }
}
