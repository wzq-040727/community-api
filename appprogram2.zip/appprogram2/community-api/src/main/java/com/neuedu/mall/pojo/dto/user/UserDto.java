package com.neuedu.mall.pojo.dto.user;

import com.neuedu.mall.pojo.dto.base.BaseDto;
import lombok.Data;

import java.util.Date;


@Data
public class UserDto extends BaseDto {

    private static final long serialVersionUID = 6067754681267406510L;

    private Integer id;
    private String phone;
    private String userName;
    private String sex;
    private String mail;
    private String avatar;
    private String userPassword;
    private Integer userStatus;
    private Date lastLoginTime;

   }
