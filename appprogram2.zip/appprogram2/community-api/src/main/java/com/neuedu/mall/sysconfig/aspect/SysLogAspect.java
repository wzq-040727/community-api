package com.neuedu.mall.sysconfig.aspect;

import com.neuedu.mall.sysconfig.annotation.SysLog;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * 自定义日志切面
 */
@Aspect
@Component
public class SysLogAspect {
    private final static Logger logger = LoggerFactory.getLogger(SysLogAspect.class);

    // 以自定义 @SysLog 注解为切点
    @Pointcut("@annotation(com.neuedu.mall.sysconfig.annotation.SysLog)")
    public void SysLog() {
    }

    /**
     * 切点之前
     * @param joinPoint
     * @throws Throwable
     */
    @Before("SysLog()")
    public void before(JoinPoint joinPoint) throws Throwable {
        // 得到 HttpServletRequest
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        assert attributes != null;
        HttpServletRequest request = attributes.getRequest();
        logger.info("============ before ==========");
        // 获取WebLog注解信息
        String info = getWebLogInfo(joinPoint);
        logger.info("Point Info    : {}", info);
        // 请求地址URL
        logger.info("URL	: {}", request.getRequestURL().toString());
        // 请求方法
        logger.info("HTTP Method : {}", request.getMethod());
        // 具体切入执行方法
        logger.info("Class Method : {}.{}", joinPoint.getSignature().getDeclaringTypeName(),
                joinPoint.getSignature().getName());
        // 请求IP
        logger.info("IP	: {}", request.getRemoteAddr());// 打印描述信息
        // 请求参数
        logger.info("Input Parameter : {}", Arrays.asList(joinPoint.getArgs()));
    }

    /**
     * 环绕
     *
     * @param proceedingJoinPoint
     * @return
     * @throws Throwable
     */
    @Around("SysLog()")
    public Object doAround(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        logger.info("============ doAround ==========");
        long startTime = System.currentTimeMillis();
        Object result = proceedingJoinPoint.proceed();
        // 打印出参
        logger.info("Output Parameter : {}", result);
        // 执行时间
        logger.info("Execution Time : {} ms", System.currentTimeMillis() - startTime);
        return result;
    }

    /**
     * 获取日志注解信息
     * @param joinPoint
     * @return
     * @throws Exception
     */
    public String getWebLogInfo(JoinPoint joinPoint) throws Exception {
        // 获取切入点的目标类
        String targetName = joinPoint.getTarget().getClass().getName();
        Class<?> targetClass = Class.forName(targetName);
        // 获取切入方法名
        String methodName = joinPoint.getSignature().getName();
        // 获取切入方法参数
        Object[] arguments = joinPoint.getArgs();
        // 获取目标类的所有方法
        Method[] methods = targetClass.getMethods();
        for (Method method : methods) {
            // 方法名相同、包含目标注解、方法参数个数相同（避免有重载）
            if (method.getName().equals(methodName) && method.isAnnotationPresent(SysLog.class)
                    && method.getParameterTypes().length == arguments.length) {
                return method.getAnnotation(SysLog.class).value();
            }
        }
        return "";
    }
}
