package com.neuedu.mall.sysconfig.mq.producer;

import com.neuedu.mall.sysconfig.mq.config.RabbitMQConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DelayMessageProducer {
    private final static Logger logger = LoggerFactory.getLogger(DelayMessageProducer.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void sendMsg(String message, Integer delayTime) {
        logger.info("rabbitMQ消息发送: " + message);
        rabbitTemplate.convertAndSend(RabbitMQConfig.DELAYED_EXCHANGE_NAME, RabbitMQConfig.DELAYED_ROUTING_KEY, message, a -> {
            a.getMessageProperties().setDelay(delayTime * 1000);
            return a;
        });
    }
}
