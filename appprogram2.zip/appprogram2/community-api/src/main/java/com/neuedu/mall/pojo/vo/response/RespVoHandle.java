package com.neuedu.mall.pojo.vo.response;


import com.neuedu.mall.constants.RespConstants;

public class RespVoHandle {
    public RespVoHandle() {
    }

//当前代码是 `RespVoHandle` 类中的两个静态方法，用于构建表示成功响应的 `RespVo` 对象。
// `RespVo` 通常用于封装 API 响应，包含响应体（body）、消息（msg）、状态码（code）和描述（desc）等信息。
//
//1. `setSuccess(T body)`：此方法接受一个类型为 `T` 的参数 `body`，并将其设置为响应体。该方法创建一个
// 新的 `RespVo` 对象，设置其 `body` 为传入的参数，`msg` 为空字符串，`code` 为
// `RespConstants.MSG_CODE_SUCCESS`（通常表示成功的状态码），`desc` 为
// `RespConstants.MSG_CODE_SUCCESS_DESC`（通常表示成功的描述信息）。最后返回这个 `RespVo` 对象。
//
//2. `setSuccess()`：此方法不接受任何参数，用于构建一个没有响应体的成功响应。它创建一个新的 `RespVo` 对象，
// 设置 `code` 为 `RespConstants.MSG_CODE_SUCCESS`，`msg` 为空字符串，`desc` 为
// `RespConstants.MSG_CODE_SUCCESS_DESC`。最后返回这个 `RespVo` 对象。
//
//这两个方法都使用了泛型 `<T>`，使得 `RespVo` 可以承载任何类型的响应体。它们的主要区别在于是否需要携带响应数据（body）。

    public static <T> RespVo<T> setSuccess(T body) {
        RespVo<T> dataInfo = new RespVo<T>();
        dataInfo.setBody(body);
        dataInfo.setMsg("");
        dataInfo.setCode(RespConstants.MSG_CODE_SUCCESS);
        dataInfo.setDesc(RespConstants.MSG_CODE_SUCCESS_DESC);
        return dataInfo;
    }

    public static <T> RespVo<T> setSuccess() {
        return setSuccess(null);
    }

    public static <T> RespVo<T> setSuccess(T body, String extDesc) {
        RespVo<T> dataInfo = new RespVo<T>();
        dataInfo.setBody(body);
        dataInfo.setMsg("");
        dataInfo.setCode(RespConstants.MSG_CODE_SUCCESS);
        dataInfo.setDesc(extDesc);
        return dataInfo;
    }

    public static <T> RespVo<T> setError(String msg) {
        RespVo<T> dataInfo = new RespVo<T>();
        dataInfo.setCode(RespConstants.MSG_CODE_SYS_ERR);
        dataInfo.setDesc(RespConstants.MSG_CODE_SYS_ERR_DESC);
        dataInfo.setMsg(msg);
        return dataInfo;
    }

    public static <T> RespVo<T> setBizError(String msg) {
        RespVo<T> dataInfo = new RespVo<T>();
        dataInfo.setCode(RespConstants.MSG_CODE_BIZ_ERR);
        dataInfo.setDesc(RespConstants.MSG_CODE_BIZ_ERR_DESC);
        dataInfo.setMsg(msg);
        return dataInfo;
    }

    public static <T> RespVo<T> setTokenError(String msg) {
        RespVo<T> dataInfo = new RespVo<T>();
        dataInfo.setCode(RespConstants.MSG_CODE_TOKEN_ERR);
        dataInfo.setDesc(RespConstants.MSG_CODE_TOKEN_ERR_DESC);
        dataInfo.setMsg(msg);
        return dataInfo;
    }
}
