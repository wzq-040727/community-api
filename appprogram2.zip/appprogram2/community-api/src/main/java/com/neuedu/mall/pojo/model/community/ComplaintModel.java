package com.neuedu.mall.pojo.model.community;

import com.neuedu.mall.pojo.model.base.PagerModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "报事报修入参")
public class ComplaintModel extends PagerModel {
    private static final long serialVersionUID = 8594730704226580667L;

    @ApiModelProperty("id")
    private int id;
    @ApiModelProperty("用户id")
    private int userId;
    @ApiModelProperty("事项内容")
    private String complaintContent;
    @ApiModelProperty("事项状态")
    private Integer complaintStatus;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getComplaintContent() {
        return complaintContent;
    }

    public void setComplaintContent(String complaintContent) {
        this.complaintContent = complaintContent;
    }

    public Integer getComplaintStatus() {
        return complaintStatus;
    }

    public void setComplaintStatus(Integer complaintStatus) {
        this.complaintStatus = complaintStatus;
    }
}
