package com.neuedu.mall.service.wallet;

import com.neuedu.mall.pojo.dto.wallet.WalletDto;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.wallet.PaymentModel;
import com.neuedu.mall.pojo.model.wallet.WalletInitModel;
import com.neuedu.mall.pojo.model.wallet.WalletModel;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.wallet.TransferConfirmVo;

/**
 * 支付服务接口.
 *
 * @author mazh.
 */
public interface WalletService {

    /**
     * 支付服务接口-查询用户钱包余额
     *
     * @param baseModel BaseModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> walletBalance(BaseModel baseModel) throws Exception;



    /**
     * 支付服务接口-初始化用户钱包
     *
     * @param walletInitModel WalletInitModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> initWallet(WalletInitModel walletInitModel) throws Exception;

    /**
     * 支付服务接口-查询当前用户钱包
     *
     * @return WalletDto
     * @throws Exception 异常.
     */
    WalletDto walletInfo() throws Exception;

    /**
     * 支付服务接口-钱包充值
     *
     * @param walletModel WalletModel
     * @return WalletDto
     * @throws Exception 异常.
     */
    RespVo<Object> recharge(WalletModel walletModel) throws Exception;

    /**
     * 支付服务接口-转帐前校验
     *
     * @param walletModel WalletModel
     * @return WalletDto
     * @throws Exception 异常.
     */
    RespVo<TransferConfirmVo> transferConfirm(WalletModel walletModel) throws Exception;

    /**
     * 支付服务接口-钱包转账
     *
     * @param walletModel WalletModel
     * @return WalletDto
     * @throws Exception 异常.
     */
    RespVo<Object> transfer(WalletModel walletModel) throws Exception;

   }
