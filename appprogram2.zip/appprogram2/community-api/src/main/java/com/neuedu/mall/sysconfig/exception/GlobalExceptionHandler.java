package com.neuedu.mall.sysconfig.exception;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;

@ControllerAdvice
@ResponseBody
public class GlobalExceptionHandler {
    private final static Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(value = CoreException.class)
    public RespVo<Object> handleCoreException(CoreException coreException, HttpServletResponse response) {
        String errorMsg;
        try {
            errorMsg = coreException.getMessage();
            logger.error("系统异常", coreException);
        } catch (Exception e) {
            errorMsg = "未知异常";
            logger.error("未知异常", coreException);
            e.printStackTrace();
        }
        return RespVoHandle.setError(errorMsg);
    }

    @ExceptionHandler(value = BizException.class)
    public RespVo<Object> handleBizException(BizException bizException, HttpServletResponse response) {
        String errorMsg;
        try {
            errorMsg = bizException.getMessage();
            logger.error("业务异常", bizException);
        } catch (Exception e) {
            errorMsg = "未知业务异常";
            logger.error("未知业务异常", bizException);
            e.printStackTrace();
        }
        return RespVoHandle.setBizError(errorMsg);
    }
}
