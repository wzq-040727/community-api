package com.neuedu.mall.constants;

public class RespConstants {
    public static String MSG_CODE = "code";
    public static String MSG_BODY = "body";
    public static String MSG_DESC = "desc";
    public static int MSG_CODE_SUCCESS = 200;

    public static int MSG_CODE_SYS_ERR = 0;
    public static int MSG_CODE_TOKEN_ERR = 999;
    public static int MSG_CODE_BIZ_ERR = 300;
    public static int MSG_CODE_FIELD_ERR = 400;
    public static int MSG_CODE_BLOCK_ERR = 429;
    public static String MSG_CODE_SUCCESS_DESC = "成功";
    public static String MSG_CODE_SYS_ERR_DESC = "系统异常";
    public static String MSG_CODE_TOKEN_ERR_DESC = "token异常";
    public static String MSG_CODE_BIZ_ERR_DESC = "业务处理异常";
    public static String MSG_CODE_FIELD_ERR_DESC = "操作失败";
    public static String MSG_CODE_BLOCK_ERR_DESC = "当前请求人数过多，请您稍候再试";
}
