package com.neuedu.mall.service.log.impl;

import com.neuedu.mall.mapper.log.PortalGoodsBrowseLogMapper;
import com.neuedu.mall.mapper.log.PortalWalletLogMapper;
import com.neuedu.mall.pojo.dto.log.GoodsBrowseLogDto;
import com.neuedu.mall.pojo.dto.wallet.WalletDto;
import com.neuedu.mall.pojo.model.log.WalletLogSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.log.WalletLogVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.log.LogRetrievalService;
import com.neuedu.mall.service.wallet.WalletService;
import com.neuedu.mall.sysconfig.annotation.StartPage;
import com.neuedu.mall.sysconfig.context.SpringContextHolder;
import com.neuedu.mall.sysconfig.datasource.DataSource;
import com.neuedu.mall.sysconfig.datasource.DataSourceRouter;
import com.neuedu.mall.sysconfig.security.CurrentUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Service
public class LogRetrievalServiceImpl extends BaseServiceImpl implements LogRetrievalService {
    private final static Logger logger = LoggerFactory.getLogger(LogRetrievalServiceImpl.class);

    @Autowired
    PortalWalletLogMapper portalWalletLogMapper;
    @Autowired
    PortalGoodsBrowseLogMapper portalGoodsBrowseLogMapper;

    @Override
    @StartPage
    @Transactional(readOnly = true)
    @DataSource(DataSourceRouter.SLAVER)
    public RespVo<PagerVo<WalletLogVo>> walletLogList(WalletLogSearchModel walletLogModel) throws Exception {
        WalletDto walletDto = getWalletData();
        walletLogModel.setWalletId(walletDto.getId());
        PagerVo<WalletLogVo> respVo = this.queryPager(portalWalletLogMapper.getWalletLogList(walletLogModel));
        return RespVoHandle.setSuccess(respVo);
    }

    public WalletDto getWalletData() throws Exception{
        ExecutorService executor = Executors.newCachedThreadPool();
        Integer userId = CurrentUser.getUserId();
        // 提交异步任务
        Future<WalletDto> futureTask = executor.submit(new Callable<WalletDto>() {
            @Override
            public WalletDto call() throws Exception {
                WalletService walletService = (WalletService) SpringContextHolder.getBean("walletServiceImpl");
                CurrentUser.setUserId(String.valueOf(userId));
                return walletService.walletInfo();
            }
        });
        // 关闭线程池
        executor.shutdown();
        return futureTask.get();
    }

    @Override
    @Transactional(readOnly = true)
    @DataSource(DataSourceRouter.SLAVER)
    public List<GoodsBrowseLogDto> goodsBrowseList() throws Exception {
        return portalGoodsBrowseLogMapper.getBrowseLogListTop();
    }
}
