package com.neuedu.mall.constants;

public class OrderConstants {
    // 未支付
    public final static Integer ORDER_STATE_BEFORE_PAY = -1;
    // 已支付
    public final static Integer ORDER_STATE_AFTER_PAY = 1;
    // 待发货
    public final static Integer ORDER_STATE_BEFORE_SEND_OUT = 2;
    // 已发货
    public final static Integer ORDER_STATE_AFTER_SEND_OUT = 3;
    // 订单完成
    public final static Integer ORDER_STATE_FINISH = 9;
    // 订单关闭
    public final static Integer ORDER_STATE_CLOSED = -9;
    // 支付类型-线上支付
    public final static Integer PAYMENT_TYPE_ONLINE = 1;
    // 支付方式-系统钱包
    public final static Integer PAYMENT_SUB_TYPE_WALLER = 1;
    // 送货方式-快递
    public final static Integer DELIVERY_TYPE_EXPRESS = 1;
    // 送货方式-自取
    public final static Integer DELIVERY_TYPE_SELF_PICKUP = 2;
    public final static int ORDER_DELAY_CANCEL_TIME_SECOND = 600;
}
