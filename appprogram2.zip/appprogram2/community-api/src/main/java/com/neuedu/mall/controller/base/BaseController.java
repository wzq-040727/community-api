package com.neuedu.mall.controller.base;

public class BaseController {
}
