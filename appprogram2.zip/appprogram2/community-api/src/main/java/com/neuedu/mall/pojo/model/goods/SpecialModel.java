package com.neuedu.mall.pojo.model.goods;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class SpecialModel extends BaseModel {
    private static final long serialVersionUID = -6431655682288962004L;

    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("模块id")
    private Integer specialId;
    @ApiModelProperty("模块名称")
    private String specialName;
    @ApiModelProperty("模块状态")
    private Integer specialStatus;
    @ApiModelProperty("商品编号")
    private String goodsNo;
    @ApiModelProperty("商品编号列表")
    List<String> goodsNoList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSpecialId() {
        return specialId;
    }

    public void setSpecialId(Integer specialId) {
        this.specialId = specialId;
    }

    public String getSpecialName() {
        return specialName;
    }

    public void setSpecialName(String specialName) {
        this.specialName = specialName;
    }

    public Integer getSpecialStatus() {
        return specialStatus;
    }

    public void setSpecialStatus(Integer specialStatus) {
        this.specialStatus = specialStatus;
    }

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }

    public List<String> getGoodsNoList() {
        return goodsNoList;
    }

    public void setGoodsNoList(List<String> goodsNoList) {
        this.goodsNoList = goodsNoList;
    }
}
