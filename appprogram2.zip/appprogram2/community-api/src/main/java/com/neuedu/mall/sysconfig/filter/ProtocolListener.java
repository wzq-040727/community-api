package com.neuedu.mall.sysconfig.filter;

import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 协议过滤器.针对指定的请求设置信息.
 */
public class ProtocolListener extends HttpServlet implements Filter {

    private static final long serialVersionUID = 1293632890250027794L;
    private final static Logger logger = LoggerFactory.getLogger(ProtocolListener.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        res.addHeader(HttpHeaderEnum.ACAC.getHttpHeaderCode(), "true");
        res.addHeader(HttpHeaderEnum.ACAM.getHttpHeaderCode(), "POST, GET, OPTIONS");
        res.addHeader(HttpHeaderEnum.ACAH.getHttpHeaderCode(), "X-Pagination-Current-Page,content-type,accessToken,accessClientId,accessReqFlag,X-Requested-With,version");
        //        res.addHeader(HttpHeaderEnum.ACAH.getHttpHeaderCode(), "X-Pagination-Current-Page,content-type,accessToken,accessClientId,X-Requested-With,version");
        res.addHeader(HttpHeaderEnum.ACEH.getHttpHeaderCode(),
                HttpHeaderEnum.ACXTP.getHttpHeaderCode() + "," + HttpHeaderEnum.ACXAU.getHttpHeaderCode() + "," + HttpHeaderEnum.NEWTOKEN.getHttpHeaderCode());
        res.addHeader(HttpHeaderEnum.ACAO.getHttpHeaderCode(), req.getHeader("origin"));
        res.addHeader(HttpHeaderEnum.ACMA.getHttpHeaderCode(), "3600");
        res.setHeader("P3P", "CP=CAO PSA OUR");

        res.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset = UTF-8");

        if ("OPTIONS".equalsIgnoreCase(req.getMethod())) {
            res.setStatus(200);
            return;
        }
        try {
            chain.doFilter(request, response);
        } catch (Exception ex) {
            String url = req.getRequestURL().toString();
            String userAgent = req.getHeader("user-agent");
            String msg = ex.getMessage();
            String resMsg;
            if (msg != null && (msg.contains("Connection reset by peer") || msg.contains("断开的管道"))) {
                resMsg = "[ProtocolListener-doFilter]：过滤器异常： Connection reset by peer，url： " + url + ", exp：" + msg;
            } else {
                resMsg = "[ProtocolListener-doFilter]：过滤器异常：url：" + url + "exp：" + msg;
            }
            logger.error(resMsg, ex);
            RespVo<Object> respVo = RespVoHandle.setError(resMsg);
            res.getOutputStream().write(respVo.toJSONString().getBytes());
        }
    }

}
