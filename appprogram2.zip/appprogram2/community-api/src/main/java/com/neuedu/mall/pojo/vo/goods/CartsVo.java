package com.neuedu.mall.pojo.vo.goods;

import java.util.List;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "CartsVo:购物车信息")
public class CartsVo extends BaseVo {
    private static final long serialVersionUID = 9060172585216323625L;
    @ApiModelProperty(value = "店铺编号")
    private String storeNo;
    @ApiModelProperty(value = "店铺名称")
    private String storeName;
    @ApiModelProperty(value = "购物车商品详细信息")
    private List<CartsDataVo> dataList;

    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public List<CartsDataVo> getDataList() {
        return dataList;
    }

    public void setDataList(List<CartsDataVo> dataList) {
        this.dataList = dataList;
    }
}
