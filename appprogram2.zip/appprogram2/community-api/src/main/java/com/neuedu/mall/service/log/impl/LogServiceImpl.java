package com.neuedu.mall.service.log.impl;

import com.neuedu.mall.constants.UserConstant;
import com.neuedu.mall.mapper.log.AdminLoginLogMapper;
import com.neuedu.mall.mapper.log.PortalGoodsBrowseLogMapper;
import com.neuedu.mall.mapper.log.PortalLoginLogMapper;
import com.neuedu.mall.mapper.log.PortalWalletLogMapper;
import com.neuedu.mall.pojo.entity.log.AdminLoginLog;
import com.neuedu.mall.pojo.entity.log.PortalGoodsBrowseLog;
import com.neuedu.mall.pojo.entity.log.PortalLoginLog;
import com.neuedu.mall.pojo.entity.log.PortalWalletLog;
import com.neuedu.mall.pojo.model.log.LoginLogModel;
import com.neuedu.mall.pojo.model.log.PortalGoodsBrowseLogModel;
import com.neuedu.mall.pojo.model.log.PortalWalletLogModel;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.log.LogService;
import com.neuedu.mall.sysconfig.datasource.DataSource;
import com.neuedu.mall.sysconfig.datasource.DataSourceRouter;
import com.neuedu.mall.sysconfig.exception.CoreException;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Async("CustomThreadExecutor")
public class LogServiceImpl extends BaseServiceImpl implements LogService {
    private final static Logger logger = LoggerFactory.getLogger(LogServiceImpl.class);

    @Autowired
    PortalLoginLogMapper portalLoginLogMapper;

    @Autowired
    PortalGoodsBrowseLogMapper portalGoodsBrowseLogMapper;

    @Autowired
    PortalWalletLogMapper portalWalletLogMapper;

    @Autowired
    AdminLoginLogMapper adminLoginLogMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    @DataSource(DataSourceRouter.SLAVER)
    public void saveLoginLog(LoginLogModel loginLogModel, String identityType) throws Exception {
        if (identityType.equals(UserConstant.USER_IDENTITY_TYPE_PORTAL)) {
            PortalLoginLog entity = new PortalLoginLog();
            BeanUtils.copyProperties(entity, loginLogModel);
            portalLoginLogMapper.insert(entity);
        } else if (identityType.equals(UserConstant.USER_IDENTITY_TYPE_ADMIN)) {
            AdminLoginLog entity = new AdminLoginLog();
            BeanUtils.copyProperties(entity, loginLogModel);
            adminLoginLogMapper.insert(entity);
        } else {
            throw new CoreException("登录身份类型错误");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @DataSource(DataSourceRouter.SLAVER)
    public void saveGoodsBrowseLog(PortalGoodsBrowseLogModel portalGoodsBrowseLogModel) throws Exception {
        PortalGoodsBrowseLog entity = new PortalGoodsBrowseLog();
        BeanUtils.copyProperties(entity, portalGoodsBrowseLogModel);
        portalGoodsBrowseLogMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @DataSource(DataSourceRouter.SLAVER)
    public void saveWalletLog(PortalWalletLogModel portalWalletLogModel) throws Exception {
        PortalWalletLog entity = new PortalWalletLog();
        BeanUtils.copyProperties(entity, portalWalletLogModel);
        portalWalletLogMapper.insert(entity);
    }
}
