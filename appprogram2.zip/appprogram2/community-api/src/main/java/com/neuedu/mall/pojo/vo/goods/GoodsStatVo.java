package com.neuedu.mall.pojo.vo.goods;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(value = "GoodsStatVo:商品统计列表")
public class GoodsStatVo extends BaseVo
{
    private static final long serialVersionUID = -532741833572220972L;

    @ApiModelProperty(value = "销售商品")
    private List<String> salesRankingNames;
    @ApiModelProperty(value = "销售数量")
    private List<Integer> salesRankingCounts;
    @ApiModelProperty(value = "浏览商品")
    private List<String> browseRankingNames;
    @ApiModelProperty(value = "浏览次数")
    private List<Integer> browseRankingCounts;

    public List<String> getSalesRankingNames() {
        return salesRankingNames;
    }

    public void setSalesRankingNames(List<String> salesRankingNames) {
        this.salesRankingNames = salesRankingNames;
    }

    public List<Integer> getSalesRankingCounts() {
        return salesRankingCounts;
    }

    public void setSalesRankingCounts(List<Integer> salesRankingCounts) {
        this.salesRankingCounts = salesRankingCounts;
    }

    public List<String> getBrowseRankingNames() {
        return browseRankingNames;
    }

    public void setBrowseRankingNames(List<String> browseRankingNames) {
        this.browseRankingNames = browseRankingNames;
    }

    public List<Integer> getBrowseRankingCounts() {
        return browseRankingCounts;
    }

    public void setBrowseRankingCounts(List<Integer> browseRankingCounts) {
        this.browseRankingCounts = browseRankingCounts;
    }
}
