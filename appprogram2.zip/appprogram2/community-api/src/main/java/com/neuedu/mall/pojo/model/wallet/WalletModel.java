package com.neuedu.mall.pojo.model.wallet;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

@ApiModel(value = "钱包管理入参", description = "钱包管理入参")
public class WalletModel extends BaseModel {
    private static final long serialVersionUID = -4238648225636245658L;

    @ApiModelProperty(value = "钱包密码")
    private String walletPassword;
    @ApiModelProperty(value = "操作金额")
    private BigDecimal amount;
    @ApiModelProperty(value = "转账目标手机号")
    private String targetPhone;
    @ApiModelProperty(value = "验证码")
    private String verCode;

    public String getWalletPassword() {
        return walletPassword;
    }

    public void setWalletPassword(String walletPassword) {
        this.walletPassword = walletPassword;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getTargetPhone() {
        return targetPhone;
    }

    public void setTargetPhone(String targetPhone) {
        this.targetPhone = targetPhone;
    }

    public String getVerCode() {
        return verCode;
    }

    public void setVerCode(String verCode) {
        this.verCode = verCode;
    }
}
