package com.neuedu.mall.utils.sms.product;

import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.enums.SmsSender;

public interface ISmsService {
    /**
     * 设置属性
     * @throws Exception
     */
    public void setProperty(SmsSender key, String value) throws Exception;

    /**
     * 发送短信
     * @throws Exception
     */
    public boolean sendSms(SmsDto smsDto) throws Exception;
}
