package com.neuedu.mall.controller.admin;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.model.admin.RoleMenuModel;
import com.neuedu.mall.pojo.model.admin.RoleModel;
import com.neuedu.mall.pojo.model.admin.RoleUserModel;
import com.neuedu.mall.pojo.vo.admin.RoleMenuVo;
import com.neuedu.mall.pojo.vo.admin.RoleUserVo;
import com.neuedu.mall.pojo.vo.admin.RoleVo;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.service.admin.RoleManageService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@Api(tags = "角色管理")
@RequestMapping("/admin/role/manage")
public class RoleManageController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(RoleManageController.class);

    @Autowired
    RoleManageService roleManageService;

    @PostMapping(value = "/add")
    @ApiOperation(value = "新增角色", notes = "新增角色")
    public RespVo<Object> addRole(HttpServletRequest request, @RequestBody RoleModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-新增角色");
            }
            return roleManageService.addRole(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/update")
    @ApiOperation(value = "修改角色", notes = "修改角色")
    public RespVo<Object> updateRole(HttpServletRequest request, @RequestBody RoleModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-修改角色");
            }
            return roleManageService.updateRole(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/list")
    @ApiOperation(value = "获取全部角色", notes = "获取全部角色")
    public RespVo<PagerVo<RoleVo>> getRoleList(HttpServletRequest request, @RequestBody RoleModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-获取全部角色");
            }
            return roleManageService.getRoleList(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/list/all")
    @ApiOperation(value = "获取全部角色-不分页", notes = "获取全部角色-不分页")
    public RespVo<List<RoleVo>> getAllRoleList(HttpServletRequest request, @RequestBody RoleModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-获取全部角色-不分页");
            }
            return roleManageService.getAllRoleList(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/menuLink/data")
    @ApiOperation(value = "获取角色和菜单菜单关联信息", notes = "获取角色和菜单菜单关联信息")
    public RespVo<RoleMenuVo> roleMenuList(HttpServletRequest request, @RequestBody RoleModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-获取角色和菜单菜单关联信息");
            }
            return roleManageService.roleMenuList(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/menuLink/save")
    @ApiOperation(value = "保存角色和菜单菜单关联信息", notes = "保存角色和菜单菜单关联信息")
    public RespVo<Object> saveRoleMenuLink(HttpServletRequest request, @RequestBody RoleMenuModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-保存角色和菜单菜单关联信息");
            }
            return roleManageService.saveRoleMenuLink(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/user/info/list")
    @ApiOperation(value = "管理端获取用户列表", notes = "管理端获取用户列表")
    public RespVo<PagerVo<RoleUserVo>> getUserList(HttpServletRequest request, @RequestBody RoleUserModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-管理端获取用户列表");
            }
            return roleManageService.getUserList(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/userLink/save")
    @ApiOperation(value = "保存角色和用户关联信息", notes = "保存角色和用户关联信息")
    public RespVo<Object> saveRoleUserLink(HttpServletRequest request, @RequestBody RoleUserModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("角色管理-保存角色和用户关联信息");
            }
            return roleManageService.saveRoleUserLink(reqParams);
        } catch (Exception ex) {
            throw new CoreException("角色管理：发生系统异常", ex);
        }
    }
}
