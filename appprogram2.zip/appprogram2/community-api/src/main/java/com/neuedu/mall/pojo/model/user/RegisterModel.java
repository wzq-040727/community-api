package com.neuedu.mall.pojo.model.user;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "注册入参对象", description = "注册入参对象")
public class RegisterModel extends BaseModel {
    private static final long serialVersionUID = -4394632030042909567L;

    @ApiModelProperty(value = "手机号码")
    private String phone;
    @ApiModelProperty(value = "密码")
    private String userPassword;
    @ApiModelProperty(value = "手机验证码")
    private String verCode;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getVerCode() {
        return verCode;
    }

    public void setVerCode(String verCode) {
        this.verCode = verCode;
    }
}
