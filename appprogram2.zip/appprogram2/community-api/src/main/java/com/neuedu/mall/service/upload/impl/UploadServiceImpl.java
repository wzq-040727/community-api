package com.neuedu.mall.service.upload.impl;

import com.neuedu.mall.pojo.model.UploadModel;
import com.neuedu.mall.pojo.vo.upload.UploadResultVo;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.upload.UploadService;
import com.neuedu.mall.utils.FileUtils;
import com.neuedu.mall.utils.SequenceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class UploadServiceImpl extends BaseServiceImpl implements UploadService {
    private final static Logger logger = LoggerFactory.getLogger(UploadServiceImpl.class);

    @Value("${customFile.savePath}")
    String sysPath;

    @Override
    public UploadResultVo uploadFile(UploadModel uploadModel) throws Exception {
        UploadResultVo resultVo = new UploadResultVo();
        String fileName = uploadModel.getFileName();
        String fileExt = fileName.substring(fileName.lastIndexOf("."));
        String vFileName = SequenceUtils.getUUID() + fileExt;
        String vFileNameWithPath = sysPath + "\\" + uploadModel.getUploadType().savePath + "\\" + vFileName;
        FileUtils.writeFileByBytes(uploadModel.getFileBytes(), vFileNameWithPath);
        resultVo.setFileUrl(uploadModel.getUploadType().savePath + "/" + vFileName);
        resultVo.setFileName(vFileName);
        logger.info("文件上传成功！文件路径：" + vFileName);
        return resultVo;
    }
}
