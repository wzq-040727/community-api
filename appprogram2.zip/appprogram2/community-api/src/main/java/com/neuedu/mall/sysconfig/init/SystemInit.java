package com.neuedu.mall.sysconfig.init;

import com.neuedu.mall.service.search.SearchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

@Component
@EnableAsync
public class SystemInit implements InitializingBean {
    private final static Logger logger = LoggerFactory.getLogger(SystemInit.class);

    @Autowired
    SearchService searchService;

    @Override
    @Async("CustomThreadExecutor")
    public void afterPropertiesSet() throws Exception {
        logger.info("elasticsearch-数据装载开始");
        searchService.insertAllGoods();
        logger.info("elasticsearch-数据装载完成");
    }
}
