package com.neuedu.mall.pojo.model.admin;

import java.util.List;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "角色与菜单关联入参", description = "角色与菜单关联入参")
public class RoleMenuModel extends BaseModel {
    private static final long serialVersionUID = -9114466681166924147L;

    @ApiModelProperty(value = "角色id")
    private Integer roleId;
    @ApiModelProperty(value = "菜单id列表")
    private List<Integer> menuIdList;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public List<Integer> getMenuIdList() {
        return menuIdList;
    }

    public void setMenuIdList(List<Integer> menuIdList) {
        this.menuIdList = menuIdList;
    }
}
