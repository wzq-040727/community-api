package com.neuedu.mall.service.upload;

import com.neuedu.mall.pojo.model.UploadModel;
import com.neuedu.mall.pojo.vo.upload.UploadResultVo;

/**
 * 文件上传服务接口.
 * @author mazh.
 */
public interface UploadService {
    /**
     * 文件上传服务接口-文件上传
     * @param uploadModel UploadModel
     * @return UploadDto
     * @throws Exception 异常
     */
    UploadResultVo uploadFile(UploadModel uploadModel) throws Exception;
}
