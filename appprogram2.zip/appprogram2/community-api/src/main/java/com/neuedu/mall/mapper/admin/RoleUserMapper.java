package com.neuedu.mall.mapper.admin;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.dto.admin.RoleUserDto;
import com.neuedu.mall.pojo.entity.admin.RoleUser;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleUserMapper extends BaseMapper<RoleUser> {
    List<RoleUserDto> getRoleUserByUserIdList(List<Integer> userIdList);
}
