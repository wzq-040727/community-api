package com.neuedu.mall.sysconfig.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Date;
import java.util.List;

/*
 * 构造及解析jwt的工具类
 */
public class JwtHelper {
    private final static Logger logger = LoggerFactory.getLogger(JwtHelper.class);

    /**
     * 解密token.
     * @param jsonWebToken jsonWebToken
     * @param base64Security base64Security
     * @return Claims
     */
    public static Claims parseJWT(String jsonWebToken, String base64Security) {
        try {
            return Jwts.parser()
                    .setSigningKey(DatatypeConverter.parseBase64Binary(base64Security))
                    .setAllowedClockSkewSeconds(600).parseClaimsJws(jsonWebToken)
                    .getBody();
        } catch (Exception ex) {
            logger.error("[JwtHelper-parseJWT]：token解密失败，jsonWebToken：" + jsonWebToken, ex);
            return null;
        }
    }

    /**
     * 创建token.
     * @param name name
     * @param claims claims
     * @param audience audience
     * @param issuer issuer
     * @param millis millis
     * @param base64Security base64Security
     * @return Claims
     * @throws Exception e
     */
    public static String createJWT(String name, List<String[]> claims, String audience, String issuer, long millis, String base64Security)
            throws Exception {
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        // 添加构成JWT的参数
        JwtBuilder builder = Jwts.builder();
        builder.setHeaderParam("typ", "JWT");
        builder.claim("unique_name", name);
        for (String[] claim : claims) {
            builder.claim(claim[0], claim[1]);
        }
        builder.setIssuer(issuer);
        builder.setAudience(audience);
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        // 生成签名密钥
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(base64Security);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
        builder.signWith(signatureAlgorithm, signingKey);
        // 添加Token过期时间
        if (millis >= 0) {
            long expMillis = nowMillis + millis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp).setNotBefore(now);
        }
        // 生成JWT
        return builder.compact();
    }
}
