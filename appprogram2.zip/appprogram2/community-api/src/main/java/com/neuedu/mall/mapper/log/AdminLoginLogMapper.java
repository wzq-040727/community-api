package com.neuedu.mall.mapper.log;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.log.AdminLoginLog;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminLoginLogMapper extends BaseMapper<AdminLoginLog> {
}
