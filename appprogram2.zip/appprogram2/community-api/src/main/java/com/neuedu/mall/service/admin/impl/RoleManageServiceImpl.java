package com.neuedu.mall.service.admin.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.mall.mapper.admin.MenuMapper;
import com.neuedu.mall.mapper.admin.RoleMapper;
import com.neuedu.mall.mapper.admin.RoleMenuMapper;
import com.neuedu.mall.mapper.admin.RoleUserMapper;
import com.neuedu.mall.pojo.dto.admin.RoleUserDto;
import com.neuedu.mall.pojo.entity.admin.Menu;
import com.neuedu.mall.pojo.entity.admin.Role;
import com.neuedu.mall.pojo.entity.admin.RoleMenu;
import com.neuedu.mall.pojo.entity.admin.RoleUser;
import com.neuedu.mall.pojo.model.admin.RoleMenuModel;
import com.neuedu.mall.pojo.model.admin.RoleModel;
import com.neuedu.mall.pojo.model.admin.RoleUserModel;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.user.UserInfoModel;
import com.neuedu.mall.pojo.vo.admin.MenuVo;
import com.neuedu.mall.pojo.vo.admin.RoleMenuVo;
import com.neuedu.mall.pojo.vo.admin.RoleUserVo;
import com.neuedu.mall.pojo.vo.admin.RoleVo;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.pojo.vo.user.CoreUserVo;
import com.neuedu.mall.service.admin.AuthService;
import com.neuedu.mall.service.admin.RoleManageService;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.user.UserService;
import com.neuedu.mall.sysconfig.annotation.StartPage;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RoleManageServiceImpl extends BaseServiceImpl implements RoleManageService {
    private final static Logger logger = LoggerFactory.getLogger(RoleManageServiceImpl.class);

    @Autowired
    RoleMapper roleMapper;
    @Autowired
    RoleMenuMapper roleMenuMapper;
    @Autowired
    RoleUserMapper roleUserMapper;
    @Autowired
    AuthService authService;
    @Autowired
    UserService userService;
    @Autowired
    MenuMapper menuMapper;

    @Override
    @Transactional(readOnly = true)
    @StartPage
    public RespVo<PagerVo<RoleVo>> getRoleList(RoleModel roleModel) throws Exception {
        PagerVo<RoleVo> respVo = this.queryPager(roleMapper.getRoleList(roleModel));
        return RespVoHandle.setSuccess(respVo);
    }

    @Override
    @Transactional(readOnly = true)
    public RespVo<List<RoleVo>> getAllRoleList(RoleModel roleModel) throws Exception {
        return RespVoHandle.setSuccess(roleMapper.getRoleList(roleModel));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> addRole(RoleModel roleModel) throws Exception {
        // 判断重复
        QueryWrapper<Role> queryWrapper = new QueryWrapper<Role>()
                .eq("role_name", roleModel.getRoleName());
        List<Role> roles = roleMapper.selectList(queryWrapper);
        if (roles.size() > 0) {
            return RespVoHandle.setBizError("角色名称重复，请检查");
        }
        Role entity = new Role();
        BeanUtils.copyProperties(entity, roleModel);
        entity.setCreateTime(new Date());
        roleMapper.insert(entity);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> updateRole(RoleModel roleModel) throws Exception {
        Role entity = new Role();
        BeanUtils.copyProperties(entity, roleModel);
        entity.setUpdateTime(new Date());
        roleMapper.updateById(entity);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(readOnly = true)
    public RespVo<RoleMenuVo> roleMenuList(RoleModel roleModel) throws Exception {
        RoleMenuVo roleMenuVo = new RoleMenuVo();
        List<MenuVo> fullMenuList = authService.getAuthMenuList(new BaseModel(), true).getBody();
        roleMenuVo.setMenuVoList(fullMenuList);
        QueryWrapper<RoleMenu> queryWrapper = new QueryWrapper<RoleMenu>()
                .eq("role_id", roleModel.getId());
        List<RoleMenu> roleMenuList = roleMenuMapper.selectList(queryWrapper);
        if (roleMenuList.size() > 0) {
            roleMenuVo.setCheckedIdList(roleMenuList.stream().map(RoleMenu::getMenuId).collect(Collectors.toList()));
        } else {
            roleMenuVo.setCheckedIdList(Collections.emptyList());
        }
        return RespVoHandle.setSuccess(roleMenuVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> saveRoleMenuLink(RoleMenuModel roleMenuModel) throws Exception {
        RoleMenu entity;
        Map<String, Object> deleteMap = new HashMap<>();
        deleteMap.put("role_id", roleMenuModel.getRoleId());
        roleMenuMapper.deleteByMap(deleteMap);
        List<Integer> parentIdList = new ArrayList<>();
        List<Menu> menuList = menuMapper.selectList(null);
        Menu menu;
        for (Integer menuId : roleMenuModel.getMenuIdList()) {
            entity = new RoleMenu();
            entity.setRoleId(roleMenuModel.getRoleId());
            entity.setMenuId(menuId);
            entity.setCreateTime(new Date());
            roleMenuMapper.insert(entity);
            // 判断是否添加添加父节点
            menu = menuList.stream().filter(item -> item.getId().equals(menuId)).collect(Collectors.toList()).get(0);
            if (!Objects.equals(menu.getParentId(), 0) && menu.getParentId() != null) {
                if (!parentIdList.contains(menu.getParentId())
                        && !roleMenuModel.getMenuIdList().contains(menu.getParentId())) {
                    parentIdList.add(menu.getParentId());
                    entity = new RoleMenu();
                    entity.setRoleId(roleMenuModel.getRoleId());
                    entity.setMenuId(menu.getParentId());
                    entity.setCreateTime(new Date());
                    roleMenuMapper.insert(entity);
                }
            }
        }
        // 更新角色修改时间
        Role role = new Role();
        role.setId(roleMenuModel.getRoleId());
        role.setUpdateTime(new Date());
        roleMapper.updateById(role);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<PagerVo<RoleUserVo>> getUserList(RoleUserModel roleUserModel) throws Exception {
        // 调用用户中心获取用户列表
        UserInfoModel reqModel = new UserInfoModel();
        BeanUtils.copyProperties(reqModel, roleUserModel);
        RespVo<PagerVo<CoreUserVo>> resVo = userService.getUserList(reqModel);
        PagerVo<CoreUserVo> pagerVo = resVo.getBody();
        // 获取所有用户权限列表
        List<RoleUserDto> roleUserList = roleUserMapper.getRoleUserByUserIdList
                (pagerVo.getRecords().stream().map(CoreUserVo::getId).collect(Collectors.toList()));
        List<RoleUserVo> resVoList = new ArrayList<>();
        RoleUserVo newUserVo;
        for (CoreUserVo coreUserVo : pagerVo.getRecords()) {
            newUserVo = new RoleUserVo();
            // 获取角色信息
            List<RoleUserDto> filterList =
                    roleUserList.stream().filter(item -> item.getUserId().equals(coreUserVo.getId())).collect(Collectors.toList());
            if (filterList.size() > 0) {
                BeanUtils.copyProperties(newUserVo, filterList.get(0));
            }
            BeanUtils.copyProperties(newUserVo, coreUserVo);
            resVoList.add(newUserVo);
        }

        // 角色信息筛选
        if (roleUserModel.getRoleId() != null && roleUserModel.getRoleId() != 0) {
            resVoList = resVoList.stream()
                    .filter(item -> {
                        return item.getRoleId() != null && item.getRoleId().equals(roleUserModel.getRoleId());
                    }).collect(Collectors.toList());
            pagerVo.setTotal(resVoList.size());
        }

        PagerVo<RoleUserVo> resPagerVo = new PagerVo<>();
        resPagerVo.setPageNum(pagerVo.getPageNum());
        resPagerVo.setPageSize(pagerVo.getPageSize());
        resPagerVo.setTotal(pagerVo.getTotal());
        resPagerVo.setRecords(resVoList);
        return RespVoHandle.setSuccess(resPagerVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> saveRoleUserLink(RoleUserModel roleUserModel) throws Exception {
        // 先删再插
        Map<String, Object> deleteMap = new HashMap<>();
        deleteMap.put("user_id", roleUserModel.getUserId());
        roleUserMapper.deleteByMap(deleteMap);
        RoleUser entity = new RoleUser();
        entity.setUserId(roleUserModel.getUserId());
        entity.setRoleId(roleUserModel.getRoleId());
        entity.setCreateTime(new Date());
        roleUserMapper.insert(entity);
        return RespVoHandle.setSuccess();
    }
}
