package com.neuedu.mall.constants;

public class CommonConstants {
    public final static String YES = "Y";
    public final static String NO = "N";
    public final static String TRUE = "true";
    public final static String FALSE = "false";
    public final static Integer ONE = 1;
    public final static Integer ZERO = 0;
}
