package com.neuedu.mall.pojo.dto.log;

import com.neuedu.mall.pojo.dto.base.BaseDto;

public class GoodsBrowseLogDto extends BaseDto {
    private static final long serialVersionUID = -5093618840867847589L;

    private String goodsNo;
    private Integer count;

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
