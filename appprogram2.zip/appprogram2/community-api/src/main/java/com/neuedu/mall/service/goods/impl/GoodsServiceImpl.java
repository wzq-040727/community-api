package com.neuedu.mall.service.goods.impl;

import com.neuedu.mall.mapper.goods.GoodsMapper;
import com.neuedu.mall.pojo.dto.goods.GoodsDocDto;
import com.neuedu.mall.pojo.model.goods.GoodsSearchModel;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.goods.GoodsService;
import com.neuedu.mall.service.lock.DistributedLockService;
import com.neuedu.mall.service.log.LogService;
import com.neuedu.mall.service.search.SearchService;
import com.neuedu.mall.service.upload.UploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GoodsServiceImpl extends BaseServiceImpl implements GoodsService {
    private final static Logger logger = LoggerFactory.getLogger(GoodsServiceImpl.class);


    @Autowired
    GoodsMapper goodsMapper;



    @Override
    public List<GoodsDocDto> getGoodsList(GoodsSearchModel reqParams) throws Exception {
        return goodsMapper.getGoodsListForES(reqParams);
    }


}
