package com.neuedu.mall.pojo.enums;

public enum SmsSender {
    // 容联.云通讯
    RL_YTX("RL-YTX", "容联.云通讯"),
    ALI("ALI", "阿里云")
    ;

    // 产品类型
    public final String breed;
    // 产品描述
    public final String desc;

    SmsSender(String breed, String desc) {
        this.breed = breed;
        this.desc = desc;
    }
}
