package com.neuedu.mall.pojo.model.sms;

import com.neuedu.mall.pojo.model.base.BaseModel;

public class SmsModel extends BaseModel {
    private static final long serialVersionUID = 4349526460468350939L;

    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
