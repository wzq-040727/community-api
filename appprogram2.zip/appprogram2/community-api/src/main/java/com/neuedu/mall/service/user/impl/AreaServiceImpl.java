package com.neuedu.mall.service.user.impl;

import java.util.*;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.mall.pojo.entity.user.Area;
import com.neuedu.mall.pojo.model.user.AreaModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.user.AreaTreeVo;
import com.neuedu.mall.pojo.vo.user.AreaVo;
import com.neuedu.mall.sysconfig.annotation.StartPage;
import com.neuedu.mall.utils.SequenceUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neuedu.mall.mapper.user.AreaMapper;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.service.user.AreaService;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;

@Service
public class AreaServiceImpl extends BaseServiceImpl implements AreaService {
    private final static Logger logger = LoggerFactory.getLogger(AreaServiceImpl.class);

    @Autowired
    AreaMapper areaMapper;

    @Override
    @Transactional(readOnly = true)
    public RespVo<List<AreaTreeVo>> getAreaTree(BaseModel baseModel) throws Exception {
        List<AreaTreeVo> areaVoList = getAllAreaTreeVoList();
        // 区域Vo列表排序
        areaVoList = areaVoList.stream().sorted(Comparator.comparing(AreaTreeVo::getId)).collect(Collectors.toList());
        // 筛选出一级区域
        List<AreaTreeVo> rootAreaList = new ArrayList<>();
        for (AreaTreeVo areaTreeVo : areaVoList) {
            if (areaTreeVo.getAreaType() == 1) {
                AreaTreeVo vo = new AreaTreeVo();
                BeanUtils.copyProperties(vo, areaTreeVo);
                rootAreaList.add(vo);
            }
        }
        rootAreaList = this.handleRecursion(rootAreaList, areaVoList, AreaTreeVo.class);
        return RespVoHandle.setSuccess(rootAreaList);
    }

    @Override
    @Transactional(readOnly = true)
    @StartPage
    public RespVo<PagerVo<AreaVo>> getAreaList(AreaModel areaModel) throws Exception {
        PagerVo<AreaVo> respVo = this.queryPager(areaMapper.queryAreaList(areaModel));
        return RespVoHandle.setSuccess(respVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> addArea(AreaModel areaModel) throws Exception {
        Area entity = new Area();
        // 判断重复
        QueryWrapper<Area> queryWrapper = new QueryWrapper<Area>()
                .eq("area_name", areaModel.getAreaName())
                .eq("area_type", areaModel.getAreaType());
        List<Area> areaList = areaMapper.selectList(queryWrapper);
        if (areaList.size() > 0) {
            return RespVoHandle.setBizError("不允许重复添加区域");
        }
        BeanUtils.copyProperties(entity, areaModel);
        entity.setAreaNo(SequenceUtils.getUUID());
        entity.setCreateTime(new Date());
        areaMapper.insert(entity);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> deleteArea(AreaModel areaModel) throws Exception {
        Area entity = areaMapper.selectById(areaModel.getId());
        if (Objects.isNull(entity)) {
            return RespVoHandle.setBizError("区域删除失败");
        }
        QueryWrapper<Area> queryWrapper = new QueryWrapper<Area>()
                .eq("parent_id", areaModel.getId());
        List<Area> areaList = areaMapper.selectList(queryWrapper);
        if (areaList.size() > 0) {
            return RespVoHandle.setBizError("当前区域存在下级区域，无法删除");
        }
        areaMapper.deleteById(areaModel.getId());
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> updateArea(AreaModel areaModel) throws Exception {
        Area entity = new Area();
        BeanUtils.copyProperties(entity, areaModel);
        entity.setUpdateTime(new Date());
        areaMapper.updateById(entity);
        return RespVoHandle.setSuccess();
    }

    private List<AreaTreeVo> getAllAreaTreeVoList() throws Exception {
        List<AreaTreeVo> areaVoList = new ArrayList<>();
        List<Area> areaList;
        // 获取所有区域
        areaList = areaMapper.selectList(null);
        // 区域实体列表整理为VoList
        for (Area area : areaList) {
            if (area.getParentId() == null) {
                area.setParentId(0);
            }
            AreaTreeVo treeVo = new AreaTreeVo();
            BeanUtils.copyProperties(treeVo, area);
            areaVoList.add(treeVo);
        }
        return areaVoList;
    }
}
