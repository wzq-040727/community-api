package com.neuedu.mall.pojo.vo.upload;


import com.neuedu.mall.pojo.vo.base.BaseVo;

public class UploadResultVo extends BaseVo {
    private static final long serialVersionUID = 4298013790177149074L;

    private String fileName;
    private String fileUrl;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}
