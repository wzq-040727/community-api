package com.neuedu.mall.service.admin;

import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.vo.admin.MenuVo;
import com.neuedu.mall.pojo.vo.response.RespVo;

import java.util.List;

/**
 * 权限服务接口.
 *
 * @author mazh.
 */
public interface AuthService {
    /**
     * 权限服务接口-获取用户菜单
     *
     * @param baseModel BaseModel
     * @param isFull    boolean
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<List<MenuVo>> getAuthMenuList(BaseModel baseModel, boolean isFull) throws Exception;
}
