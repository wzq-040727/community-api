package com.neuedu.mall.pojo.dto.base;

import com.neuedu.mall.pojo.vo.user.CoreUserVo;

import java.io.Serializable;

public class BaseDto implements Serializable {
    private static final long serialVersionUID = -7617564379952616288L;

    private CoreUserVo currentUser;
}
