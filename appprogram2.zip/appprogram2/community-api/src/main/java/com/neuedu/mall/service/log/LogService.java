package com.neuedu.mall.service.log;

import com.neuedu.mall.pojo.model.log.LoginLogModel;
import com.neuedu.mall.pojo.model.log.PortalGoodsBrowseLogModel;
import com.neuedu.mall.pojo.model.log.PortalWalletLogModel;

/**
 * 日志服务接口.
 * 
 * @author mazh.
 */
public interface LogService {
    /**
     * 日志服务接口-保存登录日志
     *
     * @param loginLogModel PortalLoginLog
     * @param identityType  String
     * @throws Exception 异常.
     */
    void saveLoginLog(LoginLogModel loginLogModel, String identityType) throws Exception;

    /**
     * 日志服务接口-保存商品浏览日志
     *
     * @param portalGoodsBrowseLogModel PortalGoodsBrowseLogModel
     * @throws Exception 异常.
     */
    void saveGoodsBrowseLog(PortalGoodsBrowseLogModel portalGoodsBrowseLogModel) throws Exception;

    /**
     * 日志服务接口-保存钱包使用日志
     *
     * @param portalWalletLogModel PortalWalletLogModel
     * @throws Exception 异常.
     */
    void saveWalletLog(PortalWalletLogModel portalWalletLogModel) throws Exception;
}
