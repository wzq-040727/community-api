package com.neuedu.mall.controller.search;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.dto.goods.GoodsDto;
import com.neuedu.mall.pojo.model.goods.GoodsSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.goods.GoodsVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.service.search.SearchService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(value = "/search")
@Api(tags = "搜索管理")
public class SearchController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(SearchController.class);

    @Autowired
    SearchService searchService;

    @PostMapping(value = "/goods/list/search")
    @ApiOperation(value = "搜索商品列表", notes = "搜索商品列表")
    public RespVo<PagerVo<GoodsVo>> searchGoodsList(HttpServletRequest request, @RequestBody GoodsSearchModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("搜索管理-模糊查询商品列表");
            }
            return searchService.searchGoodsList(reqParams);

        } catch (Exception ex) {
            throw new CoreException("搜索管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/goods/update")
    @ApiOperation(value = "根据商品编号更新ES搜索信息", notes = "根据商品编号更新ES搜索信息")
    public RespVo<Object> updateGoodsSearchInfo(HttpServletRequest request, @RequestBody List<GoodsDto> reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("搜索管理-根据商品编号更新ES搜索信息");
            }
            return searchService.updateGoodsSearchInfo(reqParams);

        } catch (Exception ex) {
            throw new CoreException("搜索管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/goods/init")
    @ApiOperation(value = "全量更新ES搜索信息", notes = "全量更新ES搜索信息")
    public RespVo<Object> initAllGoods(HttpServletRequest request)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("搜索管理-全量更新ES搜索信息");
            }
            searchService.insertAllGoods();
            return RespVoHandle.setSuccess();
        } catch (Exception ex) {
            throw new CoreException("搜索管理：发生系统异常", ex);
        }
    }
}
