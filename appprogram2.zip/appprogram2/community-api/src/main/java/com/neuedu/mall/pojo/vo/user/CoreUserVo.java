package com.neuedu.mall.pojo.vo.user;

import com.alibaba.fastjson.annotation.JSONField;
import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

@ApiModel(value = "UserVo:用户信息")
public class CoreUserVo extends BaseVo {
    private static final long serialVersionUID = -6814218228326249530L;

    @ApiModelProperty(value = "id")
    private Integer id;
    @ApiModelProperty(value = "手机号码")
    private String phone;
    @ApiModelProperty(value = "用户名")
    private String userName;
    @ApiModelProperty(value = "性别")
    private String sex;
    @ApiModelProperty(value = "电子邮件")
    private String mail;
    @ApiModelProperty(value = "头像")
    private String avatar;
    @JSONField(serialize = false)
    @ApiModelProperty(value = "密码")
    private String userPassword;
    @ApiModelProperty(value = "用户状态")
    private Integer userStatus;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "上次登录时间")
    private Date lastLoginTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public Integer getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(Integer userStatus) {
        this.userStatus = userStatus;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }
}
