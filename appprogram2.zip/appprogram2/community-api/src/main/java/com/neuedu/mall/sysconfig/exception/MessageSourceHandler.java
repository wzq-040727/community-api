package com.neuedu.mall.sysconfig.exception;

import com.neuedu.mall.sysconfig.context.SpringContextHolder;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

public class MessageSourceHandler {
    public static String getMessage(String messageKey, Object[] param, String defaultMsg) {
        MessageSource messageSource = (MessageSource)SpringContextHolder.getBean("messageSource");
        return messageSource.getMessage(messageKey, param, defaultMsg, LocaleContextHolder.getLocale());
    }
}
