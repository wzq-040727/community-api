package com.neuedu.mall.pojo.vo.goods;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "GoodsPictureVo:商品图片信息")
public class GoodsPictureVo extends BaseVo {
    private static final long serialVersionUID = -1765692811820310473L;

    @ApiModelProperty(value = "图片地址")
    private String pictureUrl;

    public GoodsPictureVo() {}

    public GoodsPictureVo(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }
}
