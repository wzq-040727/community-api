package com.neuedu.mall.pojo.entity.user;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
@Data
@TableName("user")
public class User implements Serializable {
    private static final long serialVersionUID = 3578121659478533413L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    private String phone;
    private String userName;
    private String userPassword;
    private String sex;
    private String mail;
    private String avatar;
    private Integer userStatus;
    private Date lastLoginTime;
    private Date createTime;
    private Date updateTime;


}
