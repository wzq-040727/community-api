package com.neuedu.mall.pojo.model.log;

import java.io.Serializable;
import java.util.Date;

public class PortalGoodsBrowseLogModel implements Serializable {
    private static final long serialVersionUID = 9029671504532156695L;

    private Integer id;
    private Integer userId;
    private String goodsNo;
    private String clientIp;
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
