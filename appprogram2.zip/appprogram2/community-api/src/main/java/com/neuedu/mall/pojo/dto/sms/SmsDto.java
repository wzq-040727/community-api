package com.neuedu.mall.pojo.dto.sms;

import com.neuedu.mall.pojo.dto.base.BaseDto;

public class SmsDto extends BaseDto {
    private static final long serialVersionUID = -4505722929828029829L;

    private String phone;

    private String content;

    private String validNumber;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getValidNumber() {
        return validNumber;
    }

    public void setValidNumber(String validNumber) {
        this.validNumber = validNumber;
    }
}
