package com.neuedu.mall.sysconfig.security;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class CurrentUser {
    private static final ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();

    public static void setUserId(String userId) {
        Map<String, Object> map = threadLocal.get();
        if (map == null){
            map = new HashMap<>();
        }
        map.put("user_id", userId);
        CurrentUser.threadLocal.set(map);
    }

    public static Integer getUserId() {
        Map<String, Object> map = CurrentUser.threadLocal.get();
        if (Objects.isNull(map)) {
            return null;
        }
        if (map.containsKey("user_id")){
            String userId = (String) map.get("user_id");
            return Integer.parseInt(userId);
        }
        return null;
    }

    public static void setClientIp(String userId) {
        Map<String, Object> map = threadLocal.get();
        if (map == null){
            map = new HashMap<>();
        }
        map.put("client_ip", userId);
        CurrentUser.threadLocal.set(map);
    }

    public static String getClientIp() {
        Map<String, Object> map = CurrentUser.threadLocal.get();
        if (Objects.isNull(map)) {
            return null;
        }
        return (String) map.get("client_ip");
    }

    public static void clear() {
        CurrentUser.threadLocal.remove();
    }
}
