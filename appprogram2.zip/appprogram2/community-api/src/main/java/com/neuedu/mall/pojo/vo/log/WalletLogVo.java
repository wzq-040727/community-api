package com.neuedu.mall.pojo.vo.log;

import com.alibaba.fastjson.annotation.JSONField;
import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "钱包使用记录Vo", description = "钱包使用记录Vo")
public class WalletLogVo extends BaseVo {
    private static final long serialVersionUID = 7539396593676611740L;

    @ApiModelProperty(value = "id")
    private Integer id;
    private String orderNo;
    @ApiModelProperty(value = "操作金额")
    private BigDecimal amount;
    @ApiModelProperty(value = "操作类型")
    private Integer type;
    @ApiModelProperty(value = "操作结果")
    private Integer state;
    @ApiModelProperty(value = "操作时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
