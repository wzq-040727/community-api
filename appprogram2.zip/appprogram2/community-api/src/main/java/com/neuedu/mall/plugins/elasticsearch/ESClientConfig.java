package com.neuedu.mall.plugins.elasticsearch;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Configuration
public class ESClientConfig {

    @Value("${spring.elasticsearch.rest.uris}")
    private String[] restUris;

    @Bean
    public RestHighLevelClient restHighLevelClient() {
        // 创建多个HttpHost
        HttpHost[] httpHosts = Arrays.stream(restUris).map(HttpHost::create).toArray(HttpHost[]::new);
        return new RestHighLevelClient(RestClient.builder(httpHosts));
    }
}
