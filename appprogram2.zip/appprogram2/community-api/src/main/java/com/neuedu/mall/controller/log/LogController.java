package com.neuedu.mall.controller.log;

import javax.servlet.http.HttpServletRequest;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.model.log.LoginLogModel;
import com.neuedu.mall.pojo.model.log.PortalGoodsBrowseLogModel;
import com.neuedu.mall.pojo.model.log.PortalWalletLogModel;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.service.log.LogService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = "日志管理")
@RequestMapping(value = "/log")
public class LogController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(LogController.class);

    @Autowired
    LogService logService;

    @PostMapping(value = "/loginLog/save")
    @ApiOperation(value = "保存登录日志", notes = "保存登录日志")
    public RespVo<Object> saveLoginLog(HttpServletRequest request, @RequestBody LoginLogModel reqParams,
                                       @RequestParam("identityType") String identityType)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("日志管理-保存登录日志");
            }
            logService.saveLoginLog(reqParams, identityType);
            return RespVoHandle.setSuccess();
        } catch (Exception ex) {
            throw new CoreException("日志管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/browseLog/save")
    @ApiOperation(value = "保存商品浏览日志", notes = "保存商品浏览日志")
    public RespVo<Object> saveGoodsBrowseLog(HttpServletRequest request, @RequestBody PortalGoodsBrowseLogModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("日志管理-保存商品浏览日志");
            }
            logService.saveGoodsBrowseLog(reqParams);
            return RespVoHandle.setSuccess();
        } catch (Exception ex) {
            throw new CoreException("日志管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/walletLog/save")
    @ApiOperation(value = "保存钱包使用日志", notes = "保存钱包使用日志")
    public RespVo<Object> saveWalletLog(HttpServletRequest request, @RequestBody PortalWalletLogModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("日志管理-保存钱包使用日志");
            }
            logService.saveWalletLog(reqParams);
            return RespVoHandle.setSuccess();
        } catch (Exception ex) {
            throw new CoreException("日志管理：发生系统异常", ex);
        }
    }
}
