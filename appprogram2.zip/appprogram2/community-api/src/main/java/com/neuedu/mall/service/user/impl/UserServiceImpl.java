package com.neuedu.mall.service.user.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.mall.constants.RespConstants;
import com.neuedu.mall.constants.SecurityConstants;
import com.neuedu.mall.constants.UserConstant;
import com.neuedu.mall.mapper.user.UserMapper;
import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.dto.user.UserDto;
import com.neuedu.mall.pojo.entity.user.User;
import com.neuedu.mall.pojo.model.UploadModel;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.log.LoginLogModel;
import com.neuedu.mall.pojo.model.user.LoginModel;
import com.neuedu.mall.pojo.model.user.RegisterModel;
import com.neuedu.mall.pojo.model.user.ResetPswModel;
import com.neuedu.mall.pojo.model.user.UserInfoModel;
import com.neuedu.mall.pojo.model.wallet.WalletInitModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.pojo.vo.upload.UploadResultVo;
import com.neuedu.mall.pojo.vo.user.CoreTokenVo;
import com.neuedu.mall.pojo.vo.user.CoreUserVo;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.log.LogService;
import com.neuedu.mall.service.sms.SmsService;
import com.neuedu.mall.service.upload.UploadService;
import com.neuedu.mall.service.user.UserService;
import com.neuedu.mall.sysconfig.annotation.StartPage;
import com.neuedu.mall.sysconfig.exception.BizException;
import com.neuedu.mall.sysconfig.security.CurrentUser;
import com.neuedu.mall.sysconfig.security.JwtHelper;
import com.neuedu.mall.utils.SequenceUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class UserServiceImpl extends BaseServiceImpl implements UserService {
    private final static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    UserMapper userMapper;

    @Autowired
    SmsService smsService;

    @Autowired
    UploadService uploadService;



    @Autowired
    LogService logService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<CoreTokenVo> userLogin(LoginModel loginModel) throws Exception {
        CoreTokenVo coreTokenVo;
        String pswHex = DigestUtils.md5Hex(loginModel.getUserPassword());
        CoreUserVo coreUserVo = userMapper.queryUserInfo(loginModel);
        if (Objects.isNull(coreUserVo)) {
            logger.error("[系统登录]：用户不存在");
            return RespVoHandle.setBizError("用户不存在");
        }
        if (coreUserVo.getUserStatus() != UserConstant.ENABLED) {
            logger.error("[系统登录]：用户被冻结");
            return RespVoHandle.setBizError("用户被冻结");
        }
        if (!Objects.equals(coreUserVo.getUserPassword(), pswHex)) {
            logger.error("[系统登录]：密码不正确");
            return RespVoHandle.setBizError("密码不正确");
        }
        // 登录成功
        User saveUser = new User();
        saveUser.setId(coreUserVo.getId());
        saveUser.setLastLoginTime(new Date()); // 最后一次登录时间
        userMapper.updateById(saveUser);
        logger.info("[系统登录]：用户：" + coreUserVo.getUserName() + " 登录成功！");
        // 保存登录日志
        LoginLogModel loginLog = new LoginLogModel();
        loginLog.setUserId(coreUserVo.getId());
        loginLog.setLoginIp(CurrentUser.getClientIp());
        loginLog.setCreateTime(new Date());
        logService.saveLoginLog(loginLog, loginModel.getIdentityType());
        // 生成Token
        coreTokenVo = getTokenVo(coreUserVo);
        return RespVoHandle.setSuccess(coreTokenVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> userRegister(RegisterModel registerModel) throws Exception {

        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(readOnly = true)
    public RespVo<Object> checkUser(ResetPswModel resetPswModel) throws Exception {
        // 1.校验手机验证码是否有效
        if (!verifySms(resetPswModel)){
            return RespVoHandle.setBizError("验证码错误！");
        }
        User user = new User();
        user.setPhone(resetPswModel.getPhone());
        // 2.根据手机号获取用户id
        QueryWrapper<User> queryWrapper = new QueryWrapper<User>().eq("phone", user.getPhone());
        User currUser = userMapper.selectOne(queryWrapper);
        if (Objects.isNull(currUser)){
            return RespVoHandle.setBizError("用户信息不存在");
        }
        return RespVoHandle.setSuccess(currUser.getId());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> resetPassword(ResetPswModel resetPswModel, boolean isAuth) throws Exception {
        if (isAuth) {
            // 说明是登录状态重置密码，须从token中取用户信息
            Integer userId = CurrentUser.getUserId();
            if (Objects.isNull(userId)) {
                return RespVoHandle.setBizError("用户信息异常");
            }
            resetPswModel.setUserId(userId);
        }
        User user = new User();
        user.setId(resetPswModel.getUserId());
        user.setUserPassword(DigestUtils.md5Hex(resetPswModel.getUserPassword()));
        user.setUpdateTime(new Date());
        userMapper.updateById(user);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<Object> updateUserInfo(UserInfoModel userInfoModel) throws Exception {
        User user = new User();
        BeanUtils.copyProperties(user, userInfoModel);
        user.setId(CurrentUser.getUserId());
        user.setUpdateTime(new Date());
        userMapper.updateById(user);
        return RespVoHandle.setSuccess();
    }

    @Override
    @Transactional(readOnly = true)
    public RespVo<CoreTokenVo> refreshUserInfo(BaseModel baseModel) throws Exception {
        User user = new User();
        user.setId(CurrentUser.getUserId());
        User currUser = userMapper.selectById(user);
        if (Objects.isNull(currUser)){
            RespVoHandle.setBizError("查询用户信息失败");
        }
        CoreUserVo coreUserVo = new CoreUserVo();
        BeanUtils.copyProperties(coreUserVo, currUser);
        CoreTokenVo coreTokenVo = getTokenVo(coreUserVo);
        return RespVoHandle.setSuccess(coreTokenVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RespVo<UploadResultVo> uploadAvatar(UploadModel uploadModel) throws Exception {
        UploadResultVo resultVo = uploadService.uploadFile(uploadModel);
        return RespVoHandle.setSuccess(resultVo);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDto getUserInfo(String phone) throws Exception {
        QueryWrapper<User> queryWrapper = new QueryWrapper<User>().eq("phone", phone).eq("user_status", 1);
        User user = userMapper.selectOne(queryWrapper);
        if (Objects.isNull(user)) {
            return new UserDto();
        }
        UserDto userDto = new UserDto();
        BeanUtils.copyProperties(userDto, user);
        return userDto;
    }

    @Override
    @Transactional(readOnly = true)
    @StartPage
    public RespVo<PagerVo<CoreUserVo>> getUserList(UserInfoModel userInfoModel) throws Exception {
        PagerVo<CoreUserVo> respVo = null;//this.queryPager(userMapper.getUserList(userInfoModel));
        return RespVoHandle.setSuccess(respVo);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CoreUserVo> getUserListByIdList(List<Integer> idList) throws Exception {
        CoreUserVo coreUserVo;
        List<CoreUserVo> userVoList = new ArrayList<>();
        List<User> entityList = userMapper.selectBatchIds(idList);
        for (User entity : entityList) {
            coreUserVo = new CoreUserVo();
            BeanUtils.copyProperties(coreUserVo, entity);
            userVoList.add(coreUserVo);
        }
        return userVoList;
    }

    private CoreTokenVo getTokenVo(CoreUserVo coreUserVo) throws Exception {
        String audience = "platform";
        CoreTokenVo coreTokenVo = new CoreTokenVo();
        List<String[]> claims = getClaims(coreUserVo);
        String accessToken = JwtHelper.createJWT(String.valueOf(coreUserVo.getId()), claims, audience,
                SecurityConstants.issuer,
                SecurityConstants.expiresIn, SecurityConstants.base64Security);
        coreTokenVo.setAccessToken(accessToken);
        coreTokenVo.setExpiresIn(String.valueOf(SecurityConstants.expiresIn));
        coreTokenVo.setTokenType(SecurityConstants.tokenType);
        coreTokenVo.setUserInfo(coreUserVo);
        return coreTokenVo;
    }

    private List<String[]> getClaims(CoreUserVo userVo){
        List<String[]> claims = new ArrayList<String[]>();
        claims.add(new String[] { "userInfo", JSON.toJSONString(userVo)});
        return claims;
    }

    private boolean verifySms(Object obj) throws Exception {
        String phone = BeanUtils.getProperty(obj, "phone");
        String verCode = BeanUtils.getProperty(obj, "verCode");
        SmsDto smsDto = new SmsDto();
        smsDto.setPhone(phone);
        smsDto.setValidNumber(verCode);
        RespVo<Object> respVo = smsService.verifySms(smsDto);
        return respVo.getCode() == RespConstants.MSG_CODE_SUCCESS;
    }
}
