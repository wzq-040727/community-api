package com.neuedu.mall.service.cache;

/**
 * 通用缓存服务接口
 * @author mazh
 */
public interface CacheService {

    /**
     * 通用缓存服务接口-添加缓存
     * @param key String
     * @param value Object
     * @throws Exception 异常
     */
    void opsForValue(String key,Object value) throws Exception;

    /**
     * 通用缓存服务接口-添加缓存（带有效期）
     * @param key String
     * @param value Object
     * @param Minutes int
     * @throws Exception 异常
     */
    void opsForValueInterval(String key,Object value, int Minutes) throws Exception;

    /**
     * 通用缓存服务接口-获取缓存
     * @param key String
     * @return Object
     * @throws Exception 异常
     */
    Object getValue(String key) throws Exception;

    /**
     * 通用缓存服务接口-删除缓存
     * @param key String
     * @throws Exception 异常
     */
    void deleteValue(String key) throws Exception;
}
