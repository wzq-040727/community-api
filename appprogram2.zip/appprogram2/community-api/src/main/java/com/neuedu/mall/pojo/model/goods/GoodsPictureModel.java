package com.neuedu.mall.pojo.model.goods;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "商品图片入参")
public class GoodsPictureModel extends BaseVo {
    private static final long serialVersionUID = -1765692811820310473L;

    @ApiModelProperty(value = "商品图片入参")
    private String pictureUrl;

    public GoodsPictureModel() {
    }

    public GoodsPictureModel(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }
}
