package com.neuedu.mall.service.search.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.neuedu.mall.pojo.document.GoodsDocument;
import com.neuedu.mall.pojo.dto.goods.GoodsDocDto;
import com.neuedu.mall.pojo.dto.goods.GoodsDto;
import com.neuedu.mall.pojo.model.goods.GoodsSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.goods.GoodsVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.repository.GoodsDocumentRepository;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.goods.GoodsService;
import com.neuedu.mall.service.search.SearchService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class SearchServiceImpl extends BaseServiceImpl implements SearchService {
    private final static Logger logger = LoggerFactory.getLogger(SearchServiceImpl.class);

    private final static String ES_INDEX_NAME = "goods";

    @Autowired
    GoodsDocumentRepository esRepository;

    @Autowired
    RestHighLevelClient restHighLevelClient;

    @Autowired
    GoodsService goodsService;

    @Override
    public RespVo<PagerVo<GoodsVo>> searchGoodsList(GoodsSearchModel reqParams) throws Exception {
        PagerVo<GoodsVo> pagerVo = new PagerVo<GoodsVo>();
        SearchRequest searchRequest = new SearchRequest(ES_INDEX_NAME);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        // 商品搜索，模糊查询，设置高亮
        if (StringUtils.isNotBlank(reqParams.getKeyword())) {
            reqParams.setCategoryId(0);
            boolQueryBuilder.should(QueryBuilders.matchQuery("goodsName", reqParams.getKeyword()));
            boolQueryBuilder.should(QueryBuilders.matchQuery("goodsIntroduce", reqParams.getKeyword()));
            HighlightBuilder highlightBuilder = new HighlightBuilder();
            highlightBuilder.field("goodsName");
            highlightBuilder.preTags("<span style='color:red'>");
            highlightBuilder.postTags("</span>");
            searchSourceBuilder.highlighter(new HighlightBuilder().field("goodsName").field("goodsIntroduce")
                    .preTags("<span style='color:red'>").postTags("</span>"));
        }
        // 商品类型查询
        if (reqParams.getCategoryId() != 0) {
            TermQueryBuilder termQuery = QueryBuilders.termQuery("categoryId", reqParams.getCategoryId());
            boolQueryBuilder.must(termQuery);
        }
        // 价格区间查询
        if (reqParams.getMinPrice() != 0 && reqParams.getMaxPrice() != 0) {
            RangeQueryBuilder rangeQueryBuilder =
                    QueryBuilders.rangeQuery("goodsPrice").from(reqParams.getMinPrice()).to(reqParams.getMaxPrice());
            boolQueryBuilder.must(rangeQueryBuilder);
        }
        // 设置排序
        if (StringUtils.isNotBlank(reqParams.getSortOrder())) {
            String order = reqParams.getSortOrder();
            SortOrder sortOrder;
            if (order.equals("desc")) {
                sortOrder = SortOrder.DESC;
            } else {
                sortOrder = SortOrder.ASC;
            }
            searchSourceBuilder.sort(reqParams.getSortKeyWord(), sortOrder);
        }
        searchSourceBuilder.query(boolQueryBuilder);
        // 设置分页参数
        searchSourceBuilder.from((reqParams.getPageNum() - 1) * reqParams.getPageSize());
        searchSourceBuilder.size(reqParams.getPageSize());
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        SearchHits hits = searchResponse.getHits();
        String tmpJsonStr;
        GoodsVo goodsVo;
        List<GoodsVo> recordList = new ArrayList<>();
        for (SearchHit item : hits) {
            HighlightField highlightField;
            Text[] fragments;
            Map<String, Object> sourceAsMap = item.getSourceAsMap();
            Map<String, HighlightField> highlightFields = item.getHighlightFields();
            if (highlightFields.containsKey("goodsName")) {
                highlightField = highlightFields.get("goodsName");
                fragments = highlightField.fragments();
                StringBuilder newGoodsName = new StringBuilder();
                for (Text text : fragments) {
                    newGoodsName.append(text);
                }
                sourceAsMap.put("goodsName", newGoodsName.toString());
            }
            if (highlightFields.containsKey("goodsIntroduce")) {
                highlightField = highlightFields.get("goodsIntroduce");
                fragments = highlightField.fragments();
                StringBuilder newGoodsIntroduce = new StringBuilder();
                for (Text text : fragments) {
                    newGoodsIntroduce.append(text);
                }
                sourceAsMap.put("goodsIntroduce", newGoodsIntroduce.toString());
            }
            tmpJsonStr = JSON.toJSONString(sourceAsMap);
            goodsVo = JSONObject.parseObject(tmpJsonStr, GoodsVo.class);
            recordList.add(goodsVo);
        }
        pagerVo.setPageNum(reqParams.getPageNum());
        pagerVo.setPageSize(reqParams.getPageSize());
        pagerVo.setTotal((int)hits.getTotalHits().value);
        pagerVo.setRecords(recordList);
        return RespVoHandle.setSuccess(pagerVo);
    }

    @Override
    public RespVo<Object> updateGoodsSearchInfo(List<GoodsDto> goodsDtoList) throws Exception {
        GoodsDocument goodsDocuments;
        GoodsSearchModel goodsSearchModel;
        for (GoodsDto goodsDto : goodsDtoList) {
            goodsSearchModel = new GoodsSearchModel();
            goodsSearchModel.setGoodsNo(goodsDto.getGoodsNo());
            List<GoodsDocDto> resList = goodsService.getGoodsList(goodsSearchModel);
            if (resList.size() > 0) {
                goodsDocuments = new GoodsDocument();
                BeanUtils.copyProperties(goodsDocuments, resList.get(0));
                esRepository.save(goodsDocuments);
            }
        }
        return RespVoHandle.setSuccess();
    }

    @Override
    @Async("CustomThreadExecutor")
    public void insertAllGoods() throws Exception {
        List<GoodsDocument> goodsDocumentList;
        GoodsDocument goodsDocument;
        List<GoodsDocDto> docDtoList = goodsService.getGoodsList(new GoodsSearchModel());
        if (docDtoList.size() > 0){
            goodsDocumentList = new ArrayList<>();
            for (GoodsDocDto docDto : docDtoList){
                goodsDocument = new GoodsDocument();
                BeanUtils.copyProperties(goodsDocument, docDto);
                goodsDocumentList.add(goodsDocument);
            }
            esRepository.saveAll(goodsDocumentList);
        }
    }
}
