package com.neuedu.mall.service.cache.impl;

import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.service.cache.CacheService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
@SuppressWarnings("ALL")
public class CacheServiceImpl extends BaseServiceImpl implements CacheService {
    private final static Logger logger = LoggerFactory.getLogger(CacheServiceImpl.class);

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public void opsForValue(String key, Object value) throws Exception {
        try {
            redisTemplate.opsForValue().set(key, value);
        }
        catch (Exception e){
            logger.error("[缓存服务-Redis数据缓存]：缓存写入失败,失败的Key："+key);
        }
    }

    @Override
    public void opsForValueInterval(String key, Object value, int Minutes) throws Exception {
        try {
            redisTemplate.opsForValue().set(key, value, Minutes, TimeUnit.MINUTES);
        }
        catch (Exception e){
            logger.error("[缓存服务-Redis数据缓存]：缓存写入失败,失败的Key："+key);
        }
    }

    @Override
    public Object getValue(String key) throws Exception {
        try {
            Object res = redisTemplate.opsForValue().get(key);
            logger.info("[缓存服务-Redis数据缓存]：获取数据Key: " + key);
            if (res == null) {
                logger.info("[缓存服务-Redis数据缓存]：获取数据Key: " + key + " 结果为空!");
                return null;
            }
            return res;
        } catch (Exception e) {
            logger.error("[缓存服务-Redis数据缓存]：获取数据Key: " + key + " 失败!"+e);
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void deleteValue(String key) throws Exception {
        try {
            redisTemplate.delete(key);
            logger.info("[缓存服务-Redis数据缓存]：删除数据Key: " + key);
        } catch (Exception e) {
            logger.error("[缓存服务-Redis数据缓存]：删除数据Key: " + key + " 失败! 异常为"+e);
            e.printStackTrace();
        }
    }
}
