package com.neuedu.mall.controller.user;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.dto.user.UserDto;
import com.neuedu.mall.pojo.enums.UploadType;
import com.neuedu.mall.pojo.model.UploadModel;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.user.LoginModel;
import com.neuedu.mall.pojo.model.user.RegisterModel;
import com.neuedu.mall.pojo.model.user.ResetPswModel;
import com.neuedu.mall.pojo.model.user.UserInfoModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.pojo.vo.upload.UploadResultVo;
import com.neuedu.mall.pojo.vo.user.CoreTokenVo;
import com.neuedu.mall.pojo.vo.user.CoreUserVo;
import com.neuedu.mall.service.user.UserService;
import com.neuedu.mall.sysconfig.exception.BizException;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(value = "/user")
@Api(tags = "用户管理")
public class UserController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserService userService;


    @ApiOperation(value = "用户登录")
    @PostMapping(value = "/login")
    public RespVo<CoreTokenVo> userLogin(@RequestBody LoginModel loginModel)
            throws Exception {
        return userService.userLogin(loginModel);
    }


}
