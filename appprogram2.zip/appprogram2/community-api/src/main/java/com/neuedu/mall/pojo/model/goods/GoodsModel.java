package com.neuedu.mall.pojo.model.goods;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.List;

public class GoodsModel extends BaseModel {
    private static final long serialVersionUID = -4847739247736012356L;

    @ApiModelProperty(value = "id")
    private Integer id;
    @ApiModelProperty(value = "商品编号")
    private String goodsNo;
    @ApiModelProperty(value = "商品名称")
    private String goodsName;
    @ApiModelProperty(value = "类别id")
    private Integer categoryId;
    @ApiModelProperty(value = "商品介绍")
    private String goodsIntroduce;
    @ApiModelProperty(value = "商品详细说明")
    private String goodsContent;
    @ApiModelProperty(value = "商品图片")
    private String goodsPicture;
    @ApiModelProperty(value = "图片列表")
    private List<GoodsPictureModel> pictures;
    @ApiModelProperty(value = "市场价格")
    private BigDecimal goodsMarketPrice;
    @ApiModelProperty(value = "商品状态")
    private Integer goodsState;
    @ApiModelProperty(value = "商品id列表")
    private List<Integer> goodsIdList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getGoodsIntroduce() {
        return goodsIntroduce;
    }

    public void setGoodsIntroduce(String goodsIntroduce) {
        this.goodsIntroduce = goodsIntroduce;
    }

    public String getGoodsContent() {
        return goodsContent;
    }

    public void setGoodsContent(String goodsContent) {
        this.goodsContent = goodsContent;
    }

    public String getGoodsPicture() {
        return goodsPicture;
    }

    public void setGoodsPicture(String goodsPicture) {
        this.goodsPicture = goodsPicture;
    }

    public List<GoodsPictureModel> getPictures() {
        return pictures;
    }

    public void setPictures(List<GoodsPictureModel> pictures) {
        this.pictures = pictures;
    }

    public BigDecimal getGoodsMarketPrice() {
        return goodsMarketPrice;
    }

    public void setGoodsMarketPrice(BigDecimal goodsMarketPrice) {
        this.goodsMarketPrice = goodsMarketPrice;
    }

    public Integer getGoodsState() {
        return goodsState;
    }

    public void setGoodsState(Integer goodsState) {
        this.goodsState = goodsState;
    }

    public List<Integer> getGoodsIdList() {
        return goodsIdList;
    }

    public void setGoodsIdList(List<Integer> goodsIdList) {
        this.goodsIdList = goodsIdList;
    }
}
