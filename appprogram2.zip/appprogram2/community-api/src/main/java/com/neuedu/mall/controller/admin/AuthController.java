package com.neuedu.mall.controller.admin;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.vo.admin.MenuVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.service.admin.AuthService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@Api(tags = "授权管理")
@RequestMapping("/admin/auth")
public class AuthController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    AuthService authService;

    @PostMapping(value = "/menu/list")
    @ApiOperation(value = "获取用户菜单", notes = "获取用户菜单")
    public RespVo<List<MenuVo>> getAuthMenuList(HttpServletRequest request, @RequestBody BaseModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("权限管理-获取用户菜单");
            }
            return authService.getAuthMenuList(reqParams, false);
        } catch (Exception ex) {
            throw new CoreException("权限管理：发生系统异常", ex);
        }
    }

}
