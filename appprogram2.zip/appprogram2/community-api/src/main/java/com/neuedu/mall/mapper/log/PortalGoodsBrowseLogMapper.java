package com.neuedu.mall.mapper.log;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.dto.log.GoodsBrowseLogDto;
import com.neuedu.mall.pojo.entity.log.PortalGoodsBrowseLog;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PortalGoodsBrowseLogMapper extends BaseMapper<PortalGoodsBrowseLog> {
    List<GoodsBrowseLogDto> getBrowseLogListTop();
}
