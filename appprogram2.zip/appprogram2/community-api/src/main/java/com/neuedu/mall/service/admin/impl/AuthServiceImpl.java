package com.neuedu.mall.service.admin.impl;

import com.neuedu.mall.mapper.admin.MenuMapper;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.vo.admin.MenuVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.response.RespVoHandle;
import com.neuedu.mall.service.admin.AuthService;
import com.neuedu.mall.service.base.impl.BaseServiceImpl;
import com.neuedu.mall.sysconfig.security.CurrentUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuthServiceImpl extends BaseServiceImpl implements AuthService {
    private final static Logger logger = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    MenuMapper menuMapper;

    @Override
    public RespVo<List<MenuVo>> getAuthMenuList(BaseModel baseModel, boolean isFull) throws Exception {
        Integer userId = 0;
        if (!isFull) {
            userId = CurrentUser.getUserId();
        }
        List<MenuVo> menuVoList = menuMapper.getMenuListByUserId(userId);

        // 筛选出一级菜单
        List<MenuVo> rootMenuList = new ArrayList<>();
        for (MenuVo menuVo : menuVoList) {
            if (menuVo.getParentId() == 0) {
                rootMenuList.add(menuVo);
            }
        }

        // 递归组装菜单
        rootMenuList = this.handleRecursion(rootMenuList, menuVoList, MenuVo.class);
        return RespVoHandle.setSuccess(rootMenuList);
    }
}
