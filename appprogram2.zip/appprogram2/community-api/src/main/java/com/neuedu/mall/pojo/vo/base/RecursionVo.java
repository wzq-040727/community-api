package com.neuedu.mall.pojo.vo.base;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(value = "RecursionVo:递归数据")
public class RecursionVo<T> extends BaseVo {
    private static final long serialVersionUID = -6496039678934608137L;

    @ApiModelProperty(value = "id")
    private int id;
    @ApiModelProperty(value = "父级id")
    private int parentId;
    @ApiModelProperty(value = "子节点列表")
    private List<T> children;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public List<T> getChildren() {
        return children;
    }

    public void setChildren(List<T> children) {
        this.children = children;
    }
}
