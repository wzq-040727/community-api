package com.neuedu.mall.sysconfig.filter;

import com.neuedu.mall.sysconfig.request.CustomerHttpRequestWrapperBodyHandlerImpl;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class RequestFilterConfig {

    /**
     * 跨域过滤器.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Bean
    @Order(1)
    public FilterRegistrationBean corsFilterRegistration() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        ProtocolListener protocolListener = new ProtocolListener();
        registrationBean.setFilter(protocolListener);
        List<String> urlPatterns = new ArrayList<String>();
        urlPatterns.add("/*");
        registrationBean.setOrder(1);
        registrationBean.setUrlPatterns(urlPatterns);
        return registrationBean;
    }

    /**
     * 配置过滤器.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Bean
    @Order(Integer.MAX_VALUE - 1)
    public FilterRegistrationBean reqFilterRegistration() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        CustomerRequestFilter customerRequestFilter = new CustomerRequestFilter();
        customerRequestFilter.setCustomerHttpRequestWrapperBodyHandler(new CustomerHttpRequestWrapperBodyHandlerImpl());
        registrationBean.setFilter(customerRequestFilter);
        List<String> urlPatterns = new ArrayList<String>();
        urlPatterns.add("/*");
        registrationBean.setUrlPatterns(urlPatterns);
        return registrationBean;
    }
}
