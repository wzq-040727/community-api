package com.neuedu.mall.pojo.model.log;


import com.neuedu.mall.pojo.model.base.PagerModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "钱包使用记录查询入参", description = "钱包使用记录查询入参")
public class WalletLogSearchModel extends PagerModel {
    private static final long serialVersionUID = -6255826483802007663L;

    @ApiModelProperty(value = "钱包id", hidden = true)
    private Integer walletId;
    @ApiModelProperty(value = "操作类型")
    private Integer type;
    @ApiModelProperty(value = "操作结果")
    private Integer state;
    @ApiModelProperty(value = "起始操作时间")
    private String startDate;
    @ApiModelProperty(value = "结束操作时间")
    private String endDate;

    public Integer getWalletId() {
        return walletId;
    }

    public void setWalletId(Integer walletId) {
        this.walletId = walletId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
