package com.neuedu.mall.pojo.vo.goods;

import java.math.BigDecimal;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "GoodsPriceVo:商品价格信息")
public class GoodsPriceVo extends BaseVo {
    private static final long serialVersionUID = 9159173764599910582L;

    @ApiModelProperty(value = "最低价格")
    private BigDecimal minPrice;
    @ApiModelProperty(value = "最高价格")
    private BigDecimal maxPrice;
    @ApiModelProperty(value = "市场价格")
    private BigDecimal marketPrice;

    public BigDecimal getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(BigDecimal minPrice) {
        this.minPrice = minPrice;
    }

    public BigDecimal getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(BigDecimal maxPrice) {
        this.maxPrice = maxPrice;
    }

    public BigDecimal getMarketPrice() {
        return marketPrice;
    }

    public void setMarketPrice(BigDecimal marketPrice) {
        this.marketPrice = marketPrice;
    }
}
