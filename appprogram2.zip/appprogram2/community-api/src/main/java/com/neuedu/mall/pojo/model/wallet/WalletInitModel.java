package com.neuedu.mall.pojo.model.wallet;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "钱包初始化入参", description = "钱包初始化入参")
public class WalletInitModel extends BaseModel {
    private static final long serialVersionUID = -294305164985382757L;

    @ApiModelProperty(value = "用户id")
    private Integer userId;
    @ApiModelProperty(value = "钱包密码")
    private String walletPassword;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getWalletPassword() {
        return walletPassword;
    }

    public void setWalletPassword(String walletPassword) {
        this.walletPassword = walletPassword;
    }
}
