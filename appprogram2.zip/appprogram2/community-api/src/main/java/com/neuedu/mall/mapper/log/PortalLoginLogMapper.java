package com.neuedu.mall.mapper.log;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.log.PortalLoginLog;
import org.springframework.stereotype.Repository;

@Repository
public interface PortalLoginLogMapper extends BaseMapper<PortalLoginLog> {}
