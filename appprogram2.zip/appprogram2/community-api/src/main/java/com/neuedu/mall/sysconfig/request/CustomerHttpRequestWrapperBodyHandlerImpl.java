package com.neuedu.mall.sysconfig.request;

import com.alibaba.fastjson.JSONObject;
import com.neuedu.mall.constants.SecurityConstants;
import com.neuedu.mall.sysconfig.security.CurrentUser;
import com.neuedu.mall.sysconfig.security.JwtHelper;
import com.neuedu.mall.utils.IPUtils;
import io.jsonwebtoken.Claims;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.xml.xss.request.CustomerHttpRequestWrapperBodyHandler;

import javax.servlet.http.HttpServletRequest;

@Configuration
public class CustomerHttpRequestWrapperBodyHandlerImpl implements CustomerHttpRequestWrapperBodyHandler {
    private final static Logger logger = LoggerFactory.getLogger(CustomerHttpRequestWrapperBodyHandlerImpl.class);

    @Override
    public String handleBody(HttpServletRequest request, String argData) throws Exception {
        String token = null;
        JSONObject tempObj = null;
        token = request.getHeader("x-access-token");
        if (StringUtils.isBlank(argData)) {
            tempObj = new JSONObject();
        } else {
            tempObj = JSONObject.parseObject(argData);
        }
        setClientIp(IPUtils.getClientIP(request), tempObj);
        if (StringUtils.isBlank(token)){
            return tempObj.toJSONString();
        }
        Claims claims = JwtHelper.parseJWT(token, SecurityConstants.base64Security);
        setUserInfo(claims, tempObj);
        argData = tempObj.toJSONString();
        return argData;
    }

    private void setUserInfo(Claims claims, Object obj) throws Exception{
        try{
            JSONObject userObj = JSONObject.parseObject(claims.get("userInfo").toString());
            CurrentUser.setUserId(userObj.get("id").toString());
            BeanUtils.setProperty(obj, "currentUser", userObj);
        }
       catch (Exception ex){
            logger.error("[CustomerHttpRequestWrapperBodyHandlerImpl-setUserInfo]：设置用户信息失败，请确认传入对象是否继承BaseModel！", ex);
       }
    }

    private void setClientIp(String ip, Object obj) throws Exception {
        BeanUtils.setProperty(obj, "clientIp", ip);
    }
}
