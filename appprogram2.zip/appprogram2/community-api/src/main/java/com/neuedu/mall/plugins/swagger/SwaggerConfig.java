package com.neuedu.mall.plugins.swagger;

import com.google.common.base.Predicates;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
    @Bean
    public Docket webApiConfig(){
        ParameterBuilder parameterBuilder = new ParameterBuilder();
        parameterBuilder.parameterType("header")
                .name("x-access-token")
                .description("token值")
                .modelRef(new ModelRef("string"))
                .required(false).build();
        List<Parameter> parameterList = new ArrayList<Parameter>();
        parameterList.add(parameterBuilder.build());
        return new Docket(DocumentationType.SWAGGER_2) //类型：swagger
                .groupName("communityApi") //分组名称
                .apiInfo(webApiInfo()) //设置在线文档的信息
                .select()
                .paths(Predicates.not(PathSelectors.regex("/admin/.*")::apply))
                .paths(Predicates.not(PathSelectors.regex("/error.*")))
                .build().globalOperationParameters(parameterList);

    }

    private ApiInfo webApiInfo(){
        return new ApiInfoBuilder()
                .title("智慧社区系统 - 用户端 API文档")
                .description("本文档描述了智慧社区系统接口定义")
                .version("1.0")
            .contact(new Contact("neuedu", "https://www.neuedu.com", "neuedu.com"))
                .build();
    }
}
