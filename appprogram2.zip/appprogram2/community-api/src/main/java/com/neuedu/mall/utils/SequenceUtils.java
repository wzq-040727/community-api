package com.neuedu.mall.utils;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class SequenceUtils {
    /**
     * 获得一个UUID
     * @return String UUID
     */
    public static String getUUID(){
        String s = UUID.randomUUID().toString();
        //去掉“-”符号
        return s.substring(0,8)+s.substring(9,13)+s.substring(14,18)+s.substring(19,23)+s.substring(24);
    }

    /**
     * 生成指定位数随机数.
     */
    public static String creatNumber(int length) {
        int xx = 0;
        try {
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            xx = secureRandom.nextInt((int) Math.pow(10, length) - 1);
            while (xx < Math.pow(10, length - 1)) {
                xx = secureRandom.nextInt((int) Math.pow(10, length) - 1);
            }
        } catch (Exception ex) {
            xx = (int) Math.pow(10, length - 1);
        }

        return String.valueOf(xx);
    }

    public static String createOrderNo() {
        SimpleDateFormat sdfTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SS");
        return sdfTime.format(new Date()).replaceAll("[[\\s-:punct:]]", "") + creatNumber(6);
    }

    public static void main(String[] args) {
        System.out.println(createOrderNo());
    }
}
