package com.neuedu.mall.service.sms;

import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.model.sms.SmsModel;
import com.neuedu.mall.pojo.vo.response.RespVo;

/**
 * 短信发送服务接口.
 * @author mazh.
 */
public interface SmsService {
    /**
     * 短信发送服务接口-短信发送
     * @param smsModel SmsModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<Object> sendSms(SmsModel smsModel) throws Exception;

    /**
     * 短信发送服务接口-验证码验证
     *
     * @param smsDto SmsDto
     * @return Boolean
     * @throws Exception 异常
     */
    RespVo<Object> verifySms(SmsDto smsDto) throws Exception;
}
