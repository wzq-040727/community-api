package com.neuedu.mall.pojo.vo.goods;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

@ApiModel(value = "StoreGoodsVo:门店商品信息")

public class StoreGoodsVo extends BaseVo {
    private static final long serialVersionUID = -2742769124178582556L;

    @ApiModelProperty(value = "商品库存")
    private Integer goodsStock;
    @ApiModelProperty(value = "商品价格")
    private BigDecimal goodsPrice;

    public Integer getGoodsStock() {
        return goodsStock;
    }

    public void setGoodsStock(Integer goodsStock) {
        this.goodsStock = goodsStock;
    }

    public BigDecimal getGoodsPrice() {
        return goodsPrice;
    }

    public void setGoodsPrice(BigDecimal goodsPrice) {
        this.goodsPrice = goodsPrice;
    }
}
