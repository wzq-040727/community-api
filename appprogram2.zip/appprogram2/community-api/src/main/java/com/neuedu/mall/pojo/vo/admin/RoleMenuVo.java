package com.neuedu.mall.pojo.vo.admin;

import java.util.List;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "角色菜单Vo", description = "角色菜单Vo")
public class RoleMenuVo extends BaseVo {
    private static final long serialVersionUID = 1991734742332975573L;

    @ApiModelProperty(value = "菜单信息")
    List<MenuVo> menuVoList;
    @ApiModelProperty(value = "选中id")
    private List<Integer> checkedIdList;

    public List<MenuVo> getMenuVoList() {
        return menuVoList;
    }

    public void setMenuVoList(List<MenuVo> menuVoList) {
        this.menuVoList = menuVoList;
    }

    public List<Integer> getCheckedIdList() {
        return checkedIdList;
    }

    public void setCheckedIdList(List<Integer> checkedIdList) {
        this.checkedIdList = checkedIdList;
    }
}
