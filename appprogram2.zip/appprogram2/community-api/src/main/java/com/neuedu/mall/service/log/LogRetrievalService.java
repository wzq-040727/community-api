package com.neuedu.mall.service.log;

import com.neuedu.mall.pojo.dto.log.GoodsBrowseLogDto;
import com.neuedu.mall.pojo.model.log.WalletLogSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.log.WalletLogVo;
import com.neuedu.mall.pojo.vo.response.RespVo;

import java.util.List;

/**
 * 日志查看服务接口.
 *
 * @author mazh.
 */
public interface LogRetrievalService {
    /**
     * 日志服务接口-查询钱包日志
     *
     * @param walletLogModel WalletLogSearchModel
     * @return RespVo
     * @throws Exception 异常.
     */
    RespVo<PagerVo<WalletLogVo>> walletLogList(WalletLogSearchModel walletLogModel) throws Exception;

    /**
     * 日志服务接口-查询商品浏览记录Top10
     *
     * @return List<GoodsBrowseLogDto>
     * @throws Exception 异常.
     */
    List<GoodsBrowseLogDto> goodsBrowseList() throws Exception;
}
