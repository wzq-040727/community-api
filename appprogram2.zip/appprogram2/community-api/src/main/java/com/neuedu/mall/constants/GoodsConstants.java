package com.neuedu.mall.constants;

public class GoodsConstants {
    // 商品图片
    public final static Integer PICTURE_TYPE_GOODS_MAIN = 1;
    // 商品详情图片
    public final static Integer PICTURE_TYPE_GOODS_CONTENT = 2;
    // 门店商品类型
    public final static Integer STORE_GOODS_TYPE_ENABLE = 1;
}
