package com.neuedu.mall.pojo.dto.order;

import com.neuedu.mall.pojo.dto.base.BaseDto;

import java.math.BigDecimal;
import java.util.Date;

public class OrderDto extends BaseDto {
    private static final long serialVersionUID = -2532681975743125274L;

    private Integer id;
    private String orderNo;
    private BigDecimal totalPrice;
    private Integer paymentType;
    private Integer paymentSubtype;
    private Integer deliveryType;
    private Integer orderState;
    private Date createTime;
    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    public Integer getPaymentSubtype() {
        return paymentSubtype;
    }

    public void setPaymentSubtype(Integer paymentSubtype) {
        this.paymentSubtype = paymentSubtype;
    }

    public Integer getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(Integer deliveryType) {
        this.deliveryType = deliveryType;
    }

    public Integer getOrderState() {
        return orderState;
    }

    public void setOrderState(Integer orderState) {
        this.orderState = orderState;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
