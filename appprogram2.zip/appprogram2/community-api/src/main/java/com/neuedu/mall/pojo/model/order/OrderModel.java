package com.neuedu.mall.pojo.model.order;

import com.neuedu.mall.pojo.model.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(value = "订单服务入参", description = "订单服务入参")
public class OrderModel extends BaseModel {
    private static final long serialVersionUID = -5958400001165287936L;

    @ApiModelProperty(value = "购物车id列表")
    private List<Integer> cartsIdList;
    @ApiModelProperty(value = "订单编号")
    private String orderNo;
    @ApiModelProperty(value = "订单编号列表")
    private List<String> orderNoList;

    public List<Integer> getCartsIdList() {
        return cartsIdList;
    }

    public void setCartsIdList(List<Integer> cartsIdList) {
        this.cartsIdList = cartsIdList;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public List<String> getOrderNoList() {
        return orderNoList;
    }

    public void setOrderNoList(List<String> orderNoList) {
        this.orderNoList = orderNoList;
    }
}
