package com.neuedu.mall.mapper.goods;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.dto.goods.GoodsDocDto;
import com.neuedu.mall.pojo.entity.goods.Goods;
import com.neuedu.mall.pojo.model.goods.GoodsSearchModel;
import com.neuedu.mall.pojo.vo.goods.GoodsManageVo;
import com.neuedu.mall.pojo.vo.goods.GoodsVo;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public interface GoodsMapper extends BaseMapper<Goods> {


    List<GoodsDocDto> getGoodsListForES(GoodsSearchModel argModel);



}
