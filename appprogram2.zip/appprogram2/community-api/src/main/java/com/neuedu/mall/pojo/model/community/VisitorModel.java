package com.neuedu.mall.pojo.model.community;

import com.neuedu.mall.pojo.model.base.PagerModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

@ApiModel(value = "VisitorVo:访客信息")
public class VisitorModel extends PagerModel {
    private static final long serialVersionUID = -2524705908417012263L;
    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("来访目的")
    private String visitorObjective;
    @ApiModelProperty("来访时间")
    private Date visitorTime;
    @ApiModelProperty("来访状态")
    private Integer visitorStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVisitorObjective() {
        return visitorObjective;
    }

    public void setVisitorObjective(String visitorObjective) {
        this.visitorObjective = visitorObjective;
    }

    public Date getVisitorTime() {
        return visitorTime;
    }

    public void setVisitorTime(Date visitorTime) {
        this.visitorTime = visitorTime;
    }

    public Integer getVisitorStatus() {
        return visitorStatus;
    }

    public void setVisitorStatus(Integer visitorStatus) {
        this.visitorStatus = visitorStatus;
    }
}
