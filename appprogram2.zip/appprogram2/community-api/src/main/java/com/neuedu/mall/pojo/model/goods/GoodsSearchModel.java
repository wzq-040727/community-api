package com.neuedu.mall.pojo.model.goods;

import com.neuedu.mall.pojo.model.base.PagerModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "商品列表查询条件", description = "商品列表查询条件")
public class GoodsSearchModel extends PagerModel {
    private static final long serialVersionUID = 4849857407520503720L;

    @ApiModelProperty(value = "商品类型id")
    private int categoryId;
    @ApiModelProperty(value = "商品编号")
    private String goodsNo;
    @ApiModelProperty(value = "查询关键字")
    private String keyword;
    @ApiModelProperty(value = "最小价格")
    private double minPrice;
    @ApiModelProperty(value = "最大价格")
    private double maxPrice;
    @ApiModelProperty(value = "排序字段")
    private String sortKeyWord;
    @ApiModelProperty(value = "排序方式")
    private String sortOrder;
    @ApiModelProperty(value = "门店编号")
    private String storeNo;
    @ApiModelProperty(value = "门店查询类型")
    private String storeQueryType;
    @ApiModelProperty(value = "特殊模块id")
    private String specialId;
    @ApiModelProperty(value = "特殊模块查询类型")
    private String specialQueryType;

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getGoodsNo() {
        return goodsNo;
    }

    public void setGoodsNo(String goodsNo) {
        this.goodsNo = goodsNo;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(double minPrice) {
        this.minPrice = minPrice;
    }

    public double getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(double maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getSortKeyWord() {
        return sortKeyWord;
    }

    public void setSortKeyWord(String sortKeyWord) {
        this.sortKeyWord = sortKeyWord;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }

    public String getStoreQueryType() {
        return storeQueryType;
    }

    public void setStoreQueryType(String storeQueryType) {
        this.storeQueryType = storeQueryType;
    }

    public String getSpecialId() {
        return specialId;
    }

    public void setSpecialId(String specialId) {
        this.specialId = specialId;
    }

    public String getSpecialQueryType() {
        return specialQueryType;
    }

    public void setSpecialQueryType(String specialQueryType) {
        this.specialQueryType = specialQueryType;
    }
}
