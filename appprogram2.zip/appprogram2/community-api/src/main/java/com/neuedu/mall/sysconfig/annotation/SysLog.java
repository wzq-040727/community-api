package com.neuedu.mall.sysconfig.annotation;

import java.lang.annotation.*;

//运行时使用
@Retention(RetentionPolicy.RUNTIME)
//注解用于方法
@Target({ ElementType.METHOD })
//注解包含在JavaDoc中
@Documented
public @interface SysLog {
    String value() default "";
}
