package com.neuedu.mall.controller.user;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.dto.sms.SmsDto;
import com.neuedu.mall.pojo.model.sms.SmsModel;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.service.sms.SmsService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@Api(tags = "短信管理")
@RequestMapping("/user/sms")
public class SmsController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(SmsController.class);

    @Autowired
    SmsService smsService;

    @PostMapping(value = "/send")
    @ApiOperation(value = "短信发送", notes = "短信发送")
    public RespVo<Object> send(HttpServletRequest request, @RequestBody SmsModel reqParams) throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("短信管理-短信发送");
            }
            return smsService.sendSms(reqParams);
        } catch (Exception ex) {
            throw new CoreException("短信管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/verify")
    @ApiOperation(value = "短信验证", notes = "短信验证")
    public RespVo<Object> verify(HttpServletRequest request, @RequestBody SmsDto reqParams) throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("短信管理-短信验证");
            }
            return smsService.verifySms(reqParams);
        } catch (Exception ex) {
            throw new CoreException("短信管理：发生系统异常", ex);
        }
    }
}
