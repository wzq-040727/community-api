package com.neuedu.mall.utils.convert;

import org.apache.commons.beanutils.Converter;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class CustomerStringConvert implements Converter {
    private static final String DATE = "yyyy-MM-dd";
    private static final String TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS";

    public Object convert(Class arg0, Object arg1)
    {
        try
        {
            if ((arg1 != null) && (!"".equals(arg1))) {
                if ((arg1 instanceof java.util.Date)) {
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                    return df.format(new java.util.Date(((java.util.Date)arg1).getTime()));
                }if ((arg1 instanceof java.sql.Date)) {
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                    return df.format(new java.util.Date(((java.sql.Date)arg1).getTime()));
                }if ((arg1 instanceof Timestamp)) {
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                    return df.format(new Timestamp(((Timestamp)arg1).getTime()));
                }if ((arg1 instanceof Object[])) {
                    Object[] o = (Object[])(Object[])arg1;
                    return o[0];
                }
                return arg1.toString();
            }

            return null;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return arg1;
    }
}
