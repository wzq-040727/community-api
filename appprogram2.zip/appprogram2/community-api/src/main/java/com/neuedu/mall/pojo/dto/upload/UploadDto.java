package com.neuedu.mall.pojo.dto.upload;

import com.neuedu.mall.pojo.dto.base.BaseDto;

public class UploadDto extends BaseDto {
    private static final long serialVersionUID = -332994600215210059L;

    private String fileName;
    private String fileUrl;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}
