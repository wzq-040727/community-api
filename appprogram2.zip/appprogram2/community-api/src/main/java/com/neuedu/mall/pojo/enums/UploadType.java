package com.neuedu.mall.pojo.enums;

public enum UploadType {
    // 用户头像
    PORTRAIT("PORTRAIT", "/avatar", "用户头像"),
    GOODS("GOODS", "/goods", "商品图片"),
    COMPLAINT("COMPLAINT", "/complaint", "事项管理"),
    NOTICE("NOTICE", "/notice", "公告管理"),
    ;

    // 产品类型
    public final String type;

    public final String savePath;
    // 产品描述
    public final String desc;

    UploadType(String type, String savePath, String desc) {
        this.type = type;
        this.savePath = savePath;
        this.desc = desc;
    }
}
