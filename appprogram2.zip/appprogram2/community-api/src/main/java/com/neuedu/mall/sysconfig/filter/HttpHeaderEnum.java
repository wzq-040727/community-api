package com.neuedu.mall.sysconfig.filter;

public enum  HttpHeaderEnum {

    X_ACCESS_TOKEN("accessToken", "交易认证token"),
    //----------------------- Response标准响应头 BEGIN -----------------------/
    ACAC("Access-Control-Allow-Credentials", ".."),
    ACAM("Access-Control-Allow-Methods", ".."),
    ACAH("Access-Control-Allow-Headers", ".."),
    ACEH("Access-Control-Expose-Headers", ".."),
    ACAO("Access-Control-Allow-Origin", ".."),
    ACMA("Access-Control-Max-Age", ".."),
    //----------------------- Response标准响应头 END -----------------------/

    //----------------------- Response自定义响应头 END -----------------------/
    NEWTOKEN("accessToken", "新token值"),
    ACXTJ("Access-Control-X-Token-Jid", "JID内容"),
    ACXTP("access-control-x-token-pass", "TOKEN是否通过"),
    ACXAT("access-control-x-access-token", "TOKEN携带内容"),
    ACXAU("access-control-x-uri-pass", "URL鉴权是否通过"),
        //----------------------- Response自定义响应头 END -----------------------/
    ;

    /**
     * 代码.
     */
    private String httpHeaderCode;

    /**
     * 描述.
     */
    private String httpHeaderDesc;

    HttpHeaderEnum(String httpHeaderCode, String httpHeaderDesc) {
        this.httpHeaderCode = httpHeaderCode;
        this.httpHeaderDesc = httpHeaderDesc;
    }

    public String getHttpHeaderCode() {
        return httpHeaderCode;
    }

    public String getHttpHeaderDesc() {
        return httpHeaderDesc;
    }
}
