package com.neuedu.mall.service.base.impl;

import com.github.pagehelper.PageInfo;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.base.RecursionVo;
import com.neuedu.mall.utils.BeanUtilsEx;
import org.apache.commons.beanutils.BeanUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class BaseServiceImpl {
    public <T> PagerVo<T> queryPager(List<T> argList){
        PagerVo<T> vPagerVo = new PagerVo<T>();
        PageInfo<T> pageInfo = new PageInfo<>(argList);
        vPagerVo.setPageNum(pageInfo.getPageNum());
        vPagerVo.setTotal((int) pageInfo.getTotal());
        vPagerVo.setPageSize(pageInfo.getPageSize());
        vPagerVo.setRecords(pageInfo.getList());
        return vPagerVo;
    }

    // 递归方法
    protected <T extends RecursionVo<T>> List<T> handleRecursion(List<T> rootList, List<T> totalList, Class<T> clazz)
            throws Exception {
        // 第一次排序
        rootList = rootList.stream().sorted(Comparator.comparing(T::getId)).collect(Collectors.toList());
        // 递归为子节点赋值
        for (T argVo : rootList) {
            if (BeanUtilsEx.hasProperty(argVo, "areaId")){
                BeanUtils.setProperty(argVo, "areaId", argVo.getId());
            }
            List<T> childList = recursionTree(argVo, totalList, clazz);
            // 类别排序
            if (childList != null) {
                childList = childList.stream().sorted(Comparator.comparing(T::getId)).collect(Collectors.toList());
            }
            argVo.setChildren(childList);
        }
        return rootList;
    }

    private <T extends RecursionVo<T>> List<T> recursionTree(T currVo, List<T> voList, Class<T> clazz)
            throws Exception {
        // 创建集合存储符合的子元素
        List<T> childList = new ArrayList<>();
        for (T child : voList) {
            if (child.getParentId() == currVo.getId()) {
                T vo;
                vo = clazz.newInstance();
                BeanUtils.copyProperties(vo, child);
                if (BeanUtilsEx.hasProperty(vo, "areaId")){
                    BeanUtils.setProperty(vo, "areaId", vo.getId());
                }
                // 加入集合
                childList.add(vo);
            }
        }
        // 子节点排序
        childList = childList.stream().sorted(Comparator.comparing(T::getId)).collect(Collectors.toList());
        // 递归出口，没有子节点
        if (childList.size() == 0) {
            return null;
        }
        // 将集合加入到当前父对象
        currVo.setChildren(childList);
        // 递归查找这个集合中的子元素
        for (T child : childList) {
            recursionTree(child, voList, clazz);
        }
        return childList;
    }
}
