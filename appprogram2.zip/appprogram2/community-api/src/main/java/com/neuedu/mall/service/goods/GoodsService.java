package com.neuedu.mall.service.goods;

import com.neuedu.mall.pojo.dto.goods.GoodsDocDto;
import com.neuedu.mall.pojo.dto.goods.GoodsDto;
import com.neuedu.mall.pojo.model.UploadModel;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.goods.GoodsModel;
import com.neuedu.mall.pojo.model.goods.GoodsSearchModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.goods.GoodsDataVo;
import com.neuedu.mall.pojo.vo.goods.GoodsManageVo;
import com.neuedu.mall.pojo.vo.goods.GoodsStatVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.upload.UploadResultVo;

import java.util.List;

/**
 * 商品服务接口
 * 
 * @author mazh
 */
public interface GoodsService {

    /**
     * 商品服务接口-获取商品列表（ES）
     *
     * @param reqParams GoodsSearchModel
     * @return RespVo
     * @throws Exception 异常.
     */
    List<GoodsDocDto> getGoodsList(GoodsSearchModel reqParams) throws Exception;

    }
