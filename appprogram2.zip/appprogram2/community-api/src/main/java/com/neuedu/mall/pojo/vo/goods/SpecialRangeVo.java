package com.neuedu.mall.pojo.vo.goods;

import com.neuedu.mall.pojo.vo.base.BaseVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(value = "SpecialRangeVo:首页特殊模块Vo")
public class SpecialRangeVo extends BaseVo {

    private static final long serialVersionUID = 4443236944018387850L;

    @ApiModelProperty("模块名称")
    private String specialName;
    @ApiModelProperty("模块商品列表")
    private List<GoodsVo> specialGoods;

    public String getSpecialName() {
        return specialName;
    }

    public void setSpecialName(String specialName) {
        this.specialName = specialName;
    }

    public List<GoodsVo> getSpecialGoods() {
        return specialGoods;
    }

    public void setSpecialGoods(List<GoodsVo> specialGoods) {
        this.specialGoods = specialGoods;
    }
}
