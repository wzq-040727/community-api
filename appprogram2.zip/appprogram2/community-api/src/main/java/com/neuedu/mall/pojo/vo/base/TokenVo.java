package com.neuedu.mall.pojo.vo.base;

import com.neuedu.mall.pojo.vo.user.CoreUserVo;

import java.io.Serializable;

public class TokenVo implements Serializable {
    private static final long serialVersionUID = 6523587616996452042L;

    private CoreUserVo userInfo;
    private String accessToken;
    private String expiresIn;
    private String tokenType;

    public CoreUserVo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(CoreUserVo userInfo) {
        this.userInfo = userInfo;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }
}
