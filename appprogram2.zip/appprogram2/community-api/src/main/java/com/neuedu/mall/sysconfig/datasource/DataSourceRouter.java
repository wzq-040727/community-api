package com.neuedu.mall.sysconfig.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

public class DataSourceRouter extends AbstractRoutingDataSource {
    // 数据源名称线程变量
    private static final ThreadLocal<String> holder = new ThreadLocal<String>();

    // 主库
    public static final String MASTER = "master";
    // 从库
    public static final String SLAVER = "slaver";

    /**
     * 获取数据源的名称 -->Spring会自行调用
     * 
     * @return
     */
    @Override
    protected Object determineCurrentLookupKey() {
        return DataSourceRouter.getDataSource();
    }

    /**
     * 设置数据源
     * 
     * @param datasource 数据源名称
     */
    public static void setDataSource(String datasource) {
        holder.set(datasource);
    }

    /**
     * 获取数据源名称
     * 
     * @return 数据源名称
     */
    public static String getDataSource() {
        return holder.get();
    }

    /**
     * 清空数据源
     */
    public static void clearDataSource() {
        holder.remove();
    }
}
