package com.neuedu.mall.mapper.admin;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.mall.pojo.entity.admin.Menu;
import com.neuedu.mall.pojo.vo.admin.MenuVo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuMapper extends BaseMapper<Menu> {
    List<MenuVo> getMenuListByUserId(Integer userId);
}
