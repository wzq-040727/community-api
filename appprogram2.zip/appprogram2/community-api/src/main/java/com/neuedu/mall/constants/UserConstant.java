package com.neuedu.mall.constants;

public class UserConstant {
    public static final int ENABLED = 1;
    public static final int DISABLED = 2;
    public static final String DEFAULT_PORTRAIT = "/defaultpicture/1.jpg";
    public static final String USER_IDENTITY_TYPE_PORTAL = "mall-portal";
    public static final String USER_IDENTITY_TYPE_ADMIN = "mall-admin";
}
