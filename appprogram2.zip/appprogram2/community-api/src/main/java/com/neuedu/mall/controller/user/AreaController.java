package com.neuedu.mall.controller.user;

import com.neuedu.mall.controller.base.BaseController;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.user.AreaModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.user.AreaTreeVo;
import com.neuedu.mall.pojo.vo.user.AreaVo;
import com.neuedu.mall.service.user.AreaService;
import com.neuedu.mall.sysconfig.exception.CoreException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(value = "/user/area")
@Api(tags = "区域管理")
public class AreaController extends BaseController {
    private final static Logger logger = LoggerFactory.getLogger(AreaController.class);

    @Autowired
    AreaService areaService;

    @PostMapping(value = "/tree")
    @ApiOperation(value = "获取区域树列表", notes = "获取区域树列表")
    public RespVo<List<AreaTreeVo>> getAreaTree(HttpServletRequest request, @RequestBody BaseModel baseModel)
        throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("区域管理-获取区域树列表");
            }
            return areaService.getAreaTree(baseModel);
        } catch (Exception ex) {
            throw new CoreException("区域管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/manage/list")
    @ApiOperation(value = "管理端获取区域列表", notes = "管理端获取区域列表")
    public RespVo<PagerVo<AreaVo>> getAreaList(HttpServletRequest request, @RequestBody AreaModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("区域管理-管理端获取区域列表");
            }
            return areaService.getAreaList(reqParams);
        } catch (Exception ex) {
            throw new CoreException("区域管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/add")
    @ApiOperation(value = "区域新增", notes = "区域新增")
    public RespVo<Object> addArea(HttpServletRequest request, @RequestBody AreaModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("区域管理-区域新增");
            }
            return areaService.addArea(reqParams);
        } catch (Exception ex) {
            throw new CoreException("区域管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/delete")
    @ApiOperation(value = "区域删除", notes = "区域删除")
    public RespVo<Object> deleteArea(HttpServletRequest request, @RequestBody AreaModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("区域管理-区域删除");
            }
            return areaService.deleteArea(reqParams);
        } catch (Exception ex) {
            throw new CoreException("区域管理：发生系统异常", ex);
        }
    }

    @PostMapping(value = "/update")
    @ApiOperation(value = "区域修改", notes = "区域修改")
    public RespVo<Object> updateArea(HttpServletRequest request, @RequestBody AreaModel reqParams)
            throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("区域管理-区域修改");
            }
            return areaService.updateArea(reqParams);
        } catch (Exception ex) {
            throw new CoreException("区域管理：发生系统异常", ex);
        }
    }
}
