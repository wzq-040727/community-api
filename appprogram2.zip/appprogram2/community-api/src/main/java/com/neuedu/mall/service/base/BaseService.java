package com.neuedu.mall.service.base;

public interface BaseService {
}
