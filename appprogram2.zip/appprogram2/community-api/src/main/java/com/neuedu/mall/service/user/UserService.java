package com.neuedu.mall.service.user;

import com.neuedu.mall.pojo.dto.user.UserDto;
import com.neuedu.mall.pojo.model.UploadModel;
import com.neuedu.mall.pojo.model.base.BaseModel;
import com.neuedu.mall.pojo.model.user.LoginModel;
import com.neuedu.mall.pojo.model.user.RegisterModel;
import com.neuedu.mall.pojo.model.user.ResetPswModel;
import com.neuedu.mall.pojo.model.user.UserInfoModel;
import com.neuedu.mall.pojo.vo.base.PagerVo;
import com.neuedu.mall.pojo.vo.response.RespVo;
import com.neuedu.mall.pojo.vo.upload.UploadResultVo;
import com.neuedu.mall.pojo.vo.user.CoreTokenVo;
import com.neuedu.mall.pojo.vo.user.CoreUserVo;

import java.util.List;

/**
 * 用户管理接口
 * @author mazh
 */
public interface UserService {

    /**
     * 用户管理接口-用户登录
     * @param loginModel LoginMode
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<CoreTokenVo> userLogin(LoginModel loginModel) throws Exception;

    /**
     * 用户管理接口-用户注册
     * @param registerModel RegisterModel
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<Object> userRegister(RegisterModel registerModel) throws Exception;

    /**
     * 用户管理接口-验证用户信息
     * @param resetPswModel ResetPswModel
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<Object> checkUser(ResetPswModel resetPswModel) throws Exception;

    /**
     * 用户管理接口-重置密码
     * @param resetPswModel ResetPswModel
     * @param isAuth boolean
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<Object> resetPassword(ResetPswModel resetPswModel, boolean isAuth) throws Exception;

    /**
     * 用户管理接口-更新用户信息
     * @param userInfoModel UserInfoModel
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<Object> updateUserInfo(UserInfoModel userInfoModel) throws Exception;

    /**
     * 用户管理接口-更新用户信息-重新获取token
     * @param baseModel BaseModel
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<CoreTokenVo> refreshUserInfo(BaseModel baseModel) throws Exception;

    /**
     * 用户管理接口-头像上传
     *
     * @param uploadModel UploadModel
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<UploadResultVo> uploadAvatar(UploadModel uploadModel) throws Exception;

    /**
     * 用户管理接口-根据手机号查询用户信息
     *
     * @param phone String
     * @return UserDto
     * @throws Exception 异常
     */
    UserDto getUserInfo(String phone) throws Exception;

    /**
     * 用户管理接口-管理端获取用户列表
     *
     * @param userInfoModel UserInfoModel
     * @return RespVo
     * @throws Exception 异常
     */
    RespVo<PagerVo<CoreUserVo>> getUserList(UserInfoModel userInfoModel) throws Exception;

    /**
     * 用户管理接口-根据用户id获取用户列表
     *
     * @param idList List<Integer>
     * @return List<CoreUserVo>
     * @throws Exception 异常
     */
    List<CoreUserVo> getUserListByIdList(List<Integer> idList) throws Exception;
}
