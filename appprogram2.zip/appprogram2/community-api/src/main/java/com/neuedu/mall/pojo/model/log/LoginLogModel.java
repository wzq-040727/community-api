package com.neuedu.mall.pojo.model.log;

import com.neuedu.mall.pojo.model.base.BaseModel;

import java.util.Date;

public class LoginLogModel extends BaseModel {
    private static final long serialVersionUID = 5468076890413073349L;

    private Integer id;
    private Integer userId;
    private String loginIp;
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getLoginIp() {
        return loginIp;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
