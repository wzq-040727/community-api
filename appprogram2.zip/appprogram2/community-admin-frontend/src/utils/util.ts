/**
 * @description 生成唯一 uuid
 * @return string
 */
import { Menu } from '@/api/interface/auth';

export function generateUUID() {
	if (typeof crypto === 'object') {
		if (typeof crypto.randomUUID === 'function') {
			return crypto.randomUUID();
		}
		if (typeof crypto.getRandomValues === 'function' && typeof Uint8Array === 'function') {
			const callback = (c: any) => {
				const num = Number(c);
				return (num ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (num / 4)))).toString(16);
			};
			return '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, callback);
		}
	}
	let timestamp = new Date().getTime();
	let performanceNow = (typeof performance !== 'undefined' && performance.now && performance.now() * 1000) || 0;
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
		let random = Math.random() * 16;
		if (timestamp > 0) {
			random = (timestamp + random) % 16 | 0;
			timestamp = Math.floor(timestamp / 16);
		} else {
			random = (performanceNow + random) % 16 | 0;
			performanceNow = Math.floor(performanceNow / 16);
		}
		return (c === 'x' ? random : (random & 0x3) | 0x8).toString(16);
	});
}

/**
 * @description 获取静态资源服务器地址
 * @return string
 */
export function getStaticServAddr() {
	const mode: string = import.meta.env.MODE;
	if (mode === 'development') {
		return 'http://127.0.0.1:20990/storage/';
	} else {
		return '/storage/';
	}
}

export function formatContentImg(val: string) {
	return val.replace('<img src="/goods', '<img src="' + getStaticServAddr() + '/goods');
}

/**
 * @description:  是否为数组
 */
export function isArray(val: any): val is Array<any> {
	return val && Array.isArray(val);
}

/**
 * @description 格式化表格单元格默认值(el-table-column)
 * @param {Number} row 行
 * @param {Number} col 列
 * @param {String} callValue 当前单元格值
 * @return string
 * */
export function defaultFormat(row: number, col: number, callValue: any) {
	// 如果当前值为数组,使用 / 拼接（根据需求自定义）
	if (isArray(callValue)) return callValue.length ? callValue.join(' / ') : '--';
	return callValue ?? '--';
}

// 把驼峰转换成横杠链接
export const toLine = (value: string) => {
	return value.replace(/(A-Z)g/, '-$1').toLocaleLowerCase();
};

/**
 * @description 使用递归，过滤出需要渲染在左侧菜单的列表
 * @param {Array} menuList 所有菜单列表
 * @return array
 * */
export function getShowMenuList(menuList: Menu.MenuOptions[]) {
	const newMenuList: Menu.MenuOptions[] = JSON.parse(JSON.stringify(menuList));
	return newMenuList.filter((item) => {
		item.children?.length && (item.children = getShowMenuList(item.children));
		return item;
	});
}

/**
 * @description 扁平化数组对象(主要用来处理路由菜单)
 * @return array
 * @param argList
 */
export function getFlatArr(argList: any[]) {
	const newList: any[] = JSON.parse(JSON.stringify(argList));
	return newList.reduce((pre: any[], current: any) => {
		let flatArr = [...pre, current];
		if (current.children) flatArr = [...flatArr, ...getFlatArr(current.children)];
		return flatArr;
	}, []);
}

/**
 * @description 判断数据类型
 * @param {Any} val 需要判断类型的数据
 * @return string
 */
export function isType(val: any) {
	if (val === null) return 'null';
	if (typeof val !== 'object') return typeof val;
	else return Object.prototype.toString.call(val).slice(8, -1).toLocaleLowerCase();
}

/**
 * @description 格式化数字，保留指定位数
 */
export function formatNumber(value: number) {
	if (!value) return '0.00';
	const intPart = value | 0; //获取整数部分
	const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分每三位加一个逗号
	let floatPart = '.00'; //预定义小数部分
	const vVal: string = value.toString();
	const value2Array = vVal.split('.');

	//=2表示数据有小数位
	if (value2Array.length == 2) {
		floatPart = value2Array[1].toString(); //拿到小数部分
		if (floatPart.length > 2) {
			//若小数位数在两位以上，则四舍五入保留两位小数
			return parseFloat(vVal).toFixed(2);
		} else if (floatPart.length == 1) {
			//若小数位数只有一位，补0
			return intPartFormat + '.' + floatPart + '0';
		} else {
			return intPartFormat + '.' + floatPart;
		}
	} else {
		//数据为整数
		return intPartFormat + floatPart;
	}
}

export const shortcuts = [
	{
		text: '上周',
		value: () => {
			const end = new Date();
			const start = new Date();
			start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
			return [start, end];
		},
	},
	{
		text: '上个月',
		value: () => {
			const end = new Date();
			const start = new Date();
			start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
			return [start, end];
		},
	},
	{
		text: '前三个月',
		value: () => {
			const end = new Date();
			const start = new Date();
			start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
			return [start, end];
		},
	},
];

export function formatComplaintImg(val: string) {
	return val.replace('<img src="/complaint', '<img src="' + getStaticServAddr() + '/complaint');
}

export function formatNoticeImg(val: string) {
	return val.replace('<img src="/notice', '<img src="' + getStaticServAddr() + '/notice');
}
