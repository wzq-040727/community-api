// * 文件上传模块
export namespace Upload {
	export interface ResUpload {
		fileName: string;
		fileUrl: string;
	}
}
