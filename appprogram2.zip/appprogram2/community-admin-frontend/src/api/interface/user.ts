//  登录模块
import { ReqPage } from '@/api/interface/index';

export namespace Login {
    export interface ReqLoginForm {
        phone: string;
        userPassword: string;
        identityType: string;
    }
    export interface ReqRegForm {
        phone: string;
        userPassword: string;
        verCode: string;
    }
    export interface ReqResetPswForm {
        userId: string;
        phone: string;
        userPassword: string;
        verCode: string;
    }
    export interface ResLogin {
        accessToken: string;
        userInfo: User.UserInfo;
    }
}

// * 用户管理模块
export namespace User {
    export interface UserInfo {
        id: number;
        sex: string;
        userName: string;
        phone: string;
        mail: string;
        avatar: string;
        userPassword: string;
        userStatus: string;
        lastLoginTime: string;
    }
}