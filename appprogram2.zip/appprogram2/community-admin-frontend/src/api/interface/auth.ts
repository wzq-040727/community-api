// * 菜单管理模块
export declare namespace Menu {
	interface MenuOptions {
		path: string;
		name: string;
		component: string | (() => Promise<any>);
		icon: string;
		children: MenuOptions[];
	}
}
