export namespace Category {
	export interface ResCategoryVo {
		id: number;
		parentId: number;
		categoryName: string;
		categoryType: number;
		createTime: string;
		updateTime: string;
		children: ResCategoryVo[];
	}
	export interface ReqCategory {
		id: number;
		categoryName: string;
		categoryType: number;
		parentId: number;
	}
}

export namespace Goods {
	export interface GoodsMangeData {
		id: number;
		goodsNo: string;
		goodsName: string;
		categoryId: number;
		categoryName: string;
		goodsIntroduce: string;
		goodsContent: string;
		goodsPicture: string;
		pictures: GoodsPictureVo[];
		goodsMarketPrice: number;
		goodsState: number;
		createTime: string;
		updateTime: string;
	}
	export interface GoodsPictureVo {
		pictureUrl: string;
	}
	export interface ReqGoodsSearch {
		categoryId: number;
		keyword: string;
		minPrice: string;
		maxPrice: string;
	}
	export interface ResGoodsStatData {
		salesRankingNames: string[];
		salesRankingCounts: number[];
		browseRankingNames: string[];
		browseRankingCounts: number[];
	}
}
