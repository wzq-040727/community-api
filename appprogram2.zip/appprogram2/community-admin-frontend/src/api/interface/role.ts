// * 角色模块

import { ReqPage } from '@/api/interface/index';
import { Menu } from '@/api/interface/auth';
import { User } from '@/api/interface/user';

export namespace Role {
	export interface ReqRoleList extends ReqPage {
		roleDesc: string;
	}
	export interface ReqRole {
		id: number;
		roleName: string;
		roleDesc: string;
		roleState: number;
	}
	export interface ResRoleList {
		id: number;
		roleName: string;
		roleDesc: string;
		roleState: number;
		createTime: string;
		updateTime: string;
	}
	export interface ResRoleMenuVo {
		menuVoList: Menu.MenuOptions[];
		checkedIdList: number[];
	}
	export interface ReqRoleMenu {
		roleId: number;
		menuIdList: number[];
	}
	export interface ReqUserQuery extends ReqPage {
		userName: string;
		phone: string;
		roleId: number;
	}
	export interface ResRoleUserVo extends User.UserInfo {
		roleId: number;
		roleName: string;
		roleDesc: string;
	}
	export interface ReqSetUserRole {
		userId: number;
		roleId: number;
	}
}
