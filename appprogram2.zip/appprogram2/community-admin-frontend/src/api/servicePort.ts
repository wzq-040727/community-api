// 后端各个服务的基础路径
export const ADMIN_CENTER = '/api/admin';
export const USER_CENTER = '/api/user';
export const GOODS_CENTER = '/api/goods';
export const ORDER_CENTER = '/api/order';

export const COMMUNITY_CENTER = '/api/community';