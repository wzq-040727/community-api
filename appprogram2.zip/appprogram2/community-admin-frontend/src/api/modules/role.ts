/**
 * @name 角色管理模块
 */
import http from '@/request';
import { Role } from '@/api/interface/role';
import { ADMIN_CENTER } from '@/api/servicePort';
import { ResPage, ResultData } from '@/api/interface';
import { User } from '@/api/interface/user';

export const getRoleList = (params: Role.ReqRoleList) => {
	return http.post<ResPage<Role.ResRoleList>>(ADMIN_CENTER + '/role/manage/list', params);
};

export const getAllRoleList = () => {
	return http.post<Role.ResRoleList[]>(ADMIN_CENTER + '/role/manage/list/all', {});
};

export const addRole = (params: Role.ReqRole) => {
	return http.post<ResultData>(ADMIN_CENTER + '/role/manage/add', params);
};

export const updateRole = (params: Role.ReqRole) => {
	return http.post<ResultData>(ADMIN_CENTER + '/role/manage/update', params);
};

export const getRoleMenuLink = (roleId: number) => {
	return http.post<Role.ResRoleMenuVo>(ADMIN_CENTER + '/role/manage/menuLink/data', { id: roleId });
};

export const saveRoleMenuLink = (params: Role.ReqRoleMenu) => {
	return http.post<ResultData>(ADMIN_CENTER + '/role/manage/menuLink/save', params);
};

export const getUserList = (params: Role.ReqUserQuery) => {
	return http.post<ResPage<Role.ResRoleUserVo>>(ADMIN_CENTER + '/role/manage/user/info/list', params);
};

export const saveRoleUserLink = (params: Role.ReqSetUserRole) => {
	return http.post<ResPage<Role.ResRoleUserVo>>(ADMIN_CENTER + '/role/manage//userLink/save', params);
};
