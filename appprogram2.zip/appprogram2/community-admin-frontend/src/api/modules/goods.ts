/**
 * @name 商品管理模块
 */

import http from '@/request';
import { Role } from '@/api/interface/role';
import { ADMIN_CENTER, GOODS_CENTER } from '@/api/servicePort';
import { ResPage, ResultData } from '@/api/interface';
import { User } from '@/api/interface/user';
import { Category, Goods } from '@/api/interface/goods';
import { Upload } from '@/api/interface/upload';

export const getCategoryList = (params: Category.ReqCategory) => {
	return http.post<ResPage<Category.ResCategoryVo>>(GOODS_CENTER + '/category/manage/list', params);
};

export const getCategoryTree = () => {
	return http.get<Category.ResCategoryVo[]>(GOODS_CENTER + `/category/tree?whole=Y`, {});
};

export const addCategory = (params: Category.ReqCategory) => {
	return http.post<ResultData>(GOODS_CENTER + '/category/manage/add', params);
};

export const updateCategory = (params: Category.ReqCategory) => {
	return http.post<ResultData>(GOODS_CENTER + '/category/manage/update', params);
};

export const deleteCategory = (id: number) => {
	return http.post<ResultData>(GOODS_CENTER + '/category/manage/delete', { id });
};

export const getGoodsManageList = (params: Goods.ReqGoodsSearch) => {
	return http.post<ResPage<Goods.GoodsMangeData>>(GOODS_CENTER + '/manage/goods/list', params);
};

// * 图片上传
export const uploadGoodsImage = (params: any) => {
	return http.post<Upload.ResUpload>(GOODS_CENTER + `/image/upload`, params);
};

export const addGoods = (params: Goods.GoodsMangeData) => {
	return http.post<Upload.ResUpload>(GOODS_CENTER + `/manage/add`, params);
};

export const updateGoods = (params: Goods.GoodsMangeData) => {
	return http.post<Upload.ResUpload>(GOODS_CENTER + `/manage/update`, params);
};

export const deleteGoods = (goodsIdList: number[]) => {
	return http.post<Upload.ResUpload>(GOODS_CENTER + `/manage/delete`, { goodsIdList });
};

export const goodsStatistic = () => {
	return http.post<Goods.ResGoodsStatData>(GOODS_CENTER + `/manage/goods/stat`, {});
};
