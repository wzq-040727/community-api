/**
 * @name 用户管理模块
 */

import http from '@/request';
import { Login } from '@/api/interface/user';
import { USER_CENTER } from '@/api/servicePort';

// * 用户登录
export const userLogin = (params: Login.ReqLoginForm) => {
    return http.post<Login.ResLogin>(USER_CENTER + `/login`, params, { headers: { noLoading: true } });
};