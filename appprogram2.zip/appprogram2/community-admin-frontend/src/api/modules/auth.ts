/**
 * @name 授权管理模块
 */
import http from '@/request';
import { Menu } from '@/api/interface/auth';
import { ADMIN_CENTER, USER_CENTER } from '@/api/servicePort';

export const getAuthMenuList = () => {
	return http.post<Menu.MenuOptions[]>(ADMIN_CENTER + '/auth/menu/list', {}, { headers: { noLoading: true } });
};
