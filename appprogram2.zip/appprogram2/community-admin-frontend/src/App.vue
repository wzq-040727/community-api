<template>
  <router-view />
</template>

<script setup lang="ts">
// 全局组件
</script>

<style scoped>
#app {
  width: 100%;
  height: 100%;
}
</style>
