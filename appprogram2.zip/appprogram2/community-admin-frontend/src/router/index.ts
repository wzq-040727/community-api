import { createRouter, createWebHashHistory, createWebHistory, RouteRecordRaw, useRoute } from 'vue-router';
import { staticRouter, errorRouter } from '@/router/staticRouter';
import { GlobalStore } from '@/stores';
import { AuthStore } from '@/stores/auth';
import { initDynamicRouter } from '@/router/dynamicRouter';

import NProgress from 'nprogress';
import 'nprogress/nprogress.css';

NProgress.configure({
	easing: 'ease', // 动画方式
	speed: 500, // 递增进度条的速度
	showSpinner: false, // 是否显示加载ico
	trickleSpeed: 200, // 自动递增间隔
	minimum: 0.3, // 初始化时的最小百分比
});

const router = createRouter({
	history: createWebHistory(),
	routes: [...staticRouter, ...errorRouter],
	strict: false,
	scrollBehavior: () => ({ left: 0, top: 0 }),
});

/**
 * @description 路由拦截 beforeEach
 **/
router.beforeEach(async (to, from, next) => {
	const globalStore = GlobalStore();
	const authStore = AuthStore();
	// 每次切换页面时，调用进度条
	NProgress.start();
	// // 判断是访问登陆页，有 Token 就在当前页面，没有 Token 重置路由并放行到登陆页
	if (to.path === '/login') {
		if (globalStore.token) {
			return next(from.fullPath);
		}
		await resetRouter();
		return next();
	}

	// 判断是否有 Token，没有重定向到 login
	if (!globalStore.token) {
		return next({ path: '/login', replace: true });
	}

	// 如果没有菜单列表，就重新请求菜单列表并添加动态路由
	if (!authStore.getAuthMenuList.length) {
		await initDynamicRouter();
		return next({ ...to, replace: true });
	}
	// 正常跳转页面
	await next();
});

/**
 * @description 路由跳转结束
 * */
router.afterEach(() => {
	NProgress.done();
});

/**
 * @description 重置路由
 * */
export const resetRouter = () => {
	const authStore = AuthStore();
	authStore.getFlatMenuList.forEach((route) => {
		const { name } = route;
		if (name && router.hasRoute(name)) router.removeRoute(name);
	});
};

/**
 * @description 路由跳转错误
 * */
router.onError((error) => {
	NProgress.done();
	console.warn('路由错误', error.message);
});

export default router;
