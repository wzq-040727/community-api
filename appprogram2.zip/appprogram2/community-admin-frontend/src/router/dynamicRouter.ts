import { GlobalStore } from '@/stores';
import { ElNotification } from 'element-plus';
import router from '@/router/index';
import { isType, getFlatArr } from '@/utils/util';
import { AuthStore } from '@/stores/auth';

// 引入 views 文件夹下所有 vue 文件
const modules = import.meta.glob('@/views/**/*.vue');

/**
 * 初始化动态路由
 */
export const initDynamicRouter = async () => {
	const globalStore = GlobalStore();
	const authStore = AuthStore();
	try {
		// 1.获取菜单列表
		await authStore.loadAuthMenuList();

		// 2.判断当前用户有没有菜单权限
		if (!authStore.getAuthMenuList.length) {
			ElNotification({
				title: '无权限访问',
				message: '当前账号无任何菜单权限，请联系系统管理员！',
				type: 'warning',
				duration: 3000,
			});
			globalStore.setToken('');
			await router.replace('/login');
			return Promise.reject('No permission');
		}

		// 3.添加动态路由 (getFlatArr 方法把菜单全部处理成一维数组，方便添加动态路由)
		authStore.getFlatMenuList.forEach((item: any) => {
			if (item.children) delete item.children;
			if (item.component) {
				item.component = modules['/src/views' + item.component + '.vue'];
			}
			router.addRoute('layout', item);
		});
	} catch (error) {
		// 当菜单请求出错时，重定向到登陆页
		globalStore.setToken('');
		await router.replace('/login');
		return Promise.reject(error);
	}
};
