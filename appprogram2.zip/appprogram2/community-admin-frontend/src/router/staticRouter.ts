import { RouteRecordRaw } from 'vue-router';

/**
 * staticRouter(静态路由)
 */
export const staticRouter: RouteRecordRaw[] = [
	{
		path: '/login',
		name: 'login',
		component: () => import('@/views/login.vue'),
		meta: {
			title: '登录',
		},
	},
	{
		path: '/',
		name: 'layout',
		component: () => import('@/layout/index.vue'),
		children: [
			// {
			// 	path: '/index',
			// 	component: () => import('@/views/index.vue'),
			// },
			// {
			// 	path: '/auth',
			// 	name: '权限管理',
			// 	component: () => import('@/views/auth/role/index.vue'),
			// },
			// {
			// 	path: '/auth/role',
			// 	name: '角色管理',
			// 	component: () => import('@/views/auth/role/index.vue'),
			// },
		],
	},
];

/**
 * errorRouter(错误页面路由)
 */
export const errorRouter = [
	{
		path: '/403',
		name: '403',
		component: () => import('@/components/errorPage/403.vue'),
		meta: {
			title: '403页面',
		},
	},
	{
		path: '/404',
		name: '404',
		component: () => import('@/components/errorPage/404.vue'),
		meta: {
			title: '404页面',
		},
	},
	{
		path: '/500',
		name: '500',
		component: () => import('@/components/errorPage/500.vue'),
		meta: {
			title: '500页面',
		},
	},
	// 解决刷新页面，路由警告
	{
		path: '/:pathMatch(.*)*',
		component: () => import('@/components/errorPage/404.vue'),
	},
];
