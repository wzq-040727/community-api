<template>
  <div class="login-container">
    <div class="login-box">
      <div class="login-header">
        <h2>智慧社区管理端</h2>
        <p>欢迎回来，请登录您的账号</p>
      </div>
      <el-form
        ref="loginFormRef"
        :model="loginForm"
        :rules="loginRules"
        class="login-form"
      >
        <el-form-item prop="username">
          <el-input
            v-model="loginForm.phone"
            placeholder="请输入用户名"
            prefix-icon="User"
            size="large"
          />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="loginForm.userPassword"
            type="password"
            placeholder="请输入密码"
            prefix-icon="Lock"
            size="large"
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            size="large"
            class="login-btn"
            :loading="loading"
            @click="handleLogin"
          >
            登录
          </el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import type { FormInstance, FormRules } from 'element-plus'
import { Login } from '@/api/interface/user';
import { userLogin } from '@/api/modules/user';

const router = useRouter()
const loginFormRef = ref<FormInstance>()
const loading = ref(false)

/* const loginForm = reactive({
  username: '',
  password: ''
}) */

const loginForm = reactive<Login.ReqLoginForm>({
    phone: '18611111111',
    userPassword: '11',
    identityType: 'mall-admin',
});

const loginRules: FormRules = {
  phone: [
    { required: true, message: '请输入用户名', trigger: 'blur' }
  ],
  userPassword: [
    { required: true, message: '请输入密码', trigger: 'blur' }
  ]
}

const handleLogin = async () => {
  if (!loginFormRef.value) return
  
  const valid = await loginFormRef.value.validate()
  if (!valid) return
  
  loading.value = true
  
  
  try {
      // 1.执行登录接口
      const { body } = await userLogin(loginForm);
      console.log(body.accessToken);
      console.log(body.userInfo);

      // 2.跳转到首页
      await router.push('/dashboard');

    } finally {
      loading.value = false;
    }
}
</script>

<style scoped lang="scss">
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  
  .login-box {
    width: 400px;
    padding: 40px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    
    .login-header {
      text-align: center;
      margin-bottom: 30px;
      
      h2 {
        color: #333;
        margin-bottom: 10px;
        font-weight: 600;
      }
      
      p {
        color: #666;
        font-size: 14px;
      }
    }
    
    .login-form {
      .login-btn {
        width: 100%;
        margin-top: 10px;
      }
    }
  }
}
</style>