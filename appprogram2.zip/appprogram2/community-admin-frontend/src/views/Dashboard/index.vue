<template>
  <div class="dashboard-container">
    <div class="dashboard-header">
      <h1>仪表板</h1>
    </div>
    
    <div class="dashboard-content">
      <el-row :gutter="20">
        <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
          <el-card class="dashboard-card">
            <template #header>
              <div class="card-header">
                <span>用户总数</span>
              </div>
            </template>
            <div class="card-content">
              <h3 class="card-value">1,234</h3>
              <div class="card-footer">
                <span class="positive">+12%</span>
                <span class="sub-text">较上月</span>
              </div>
            </div>
          </el-card>
        </el-col>
        
        <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
          <el-card class="dashboard-card">
            <template #header>
              <div class="card-header">
                <span>设备总数</span>
              </div>
            </template>
            <div class="card-content">
              <h3 class="card-value">567</h3>
              <div class="card-footer">
                <span class="positive">+8%</span>
                <span class="sub-text">较上月</span>
              </div>
            </div>
          </el-card>
        </el-col>
        
        <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
          <el-card class="dashboard-card">
            <template #header>
              <div class="card-header">
                <span>告警总数</span>
              </div>
            </template>
            <div class="card-content">
              <h3 class="card-value">89</h3>
              <div class="card-footer">
                <span class="negative">-5%</span>
                <span class="sub-text">较上月</span>
              </div>
            </div>
          </el-card>
        </el-col>
        
        <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
          <el-card class="dashboard-card">
            <template #header>
              <div class="card-header">
                <span>处理率</span>
              </div>
            </template>
            <div class="card-content">
              <h3 class="card-value">98.5%</h3>
              <div class="card-footer">
                <span class="positive">+2%</span>
                <span class="sub-text">较上月</span>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
      
      <el-row :gutter="20" class="mt-20">
        <el-col :xs="24" :sm="24" :md="16" :lg="16" :xl="16">
          <el-card>
            <template #header>
              <div class="card-header">
                <span>系统访问统计</span>
              </div>
            </template>
            <div class="chart-container">
              <!-- 这里可以放置ECharts图表 -->
              <div class="placeholder-chart">
                <h3>ECharts图表区域</h3>
                <p>访问量统计图表将显示在这里</p>
              </div>
            </div>
          </el-card>
        </el-col>
        
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="8">
          <el-card>
            <template #header>
              <div class="card-header">
                <span>最新告警</span>
              </div>
            </template>
            <el-timeline class="timeline">
              <el-timeline-item
                v-for="(alert, index) in alerts"
                :key="index"
                :timestamp="alert.time"
              >
                {{ alert.content }}
              </el-timeline-item>
            </el-timeline>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const alerts = ref([
  { time: '2023-05-01 14:30', content: '门禁系统异常' },
  { time: '2023-05-01 12:15', content: '电梯维护完成' },
  { time: '2023-05-01 10:00', content: '消防系统检查正常' },
  { time: '2023-04-30 16:45', content: '停车场系统升级完成' },
  { time: '2023-04-30 09:20', content: '监控摄像头故障已修复' }
])
</script>

<style scoped lang="scss">
.dashboard-container {
  padding: 20px;
  
  .dashboard-header {
    margin-bottom: 20px;
    
    h1 {
      font-size: 24px;
      font-weight: 600;
      color: #333;
    }
  }
  
  .dashboard-card {
    margin-bottom: 20px;
    
    .card-header {
      font-weight: 600;
      color: #333;
    }
    
    .card-content {
      .card-value {
        font-size: 32px;
        font-weight: 700;
        margin: 10px 0;
        color: #409eff;
      }
      
      .card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 14px;
        
        .positive {
          color: #67c23a;
        }
        
        .negative {
          color: #f56c6c;
        }
        
        .sub-text {
          color: #909399;
        }
      }
    }
  }
  
  .mt-20 {
    margin-top: 20px;
  }
  
  .chart-container {
    height: 300px;
    
    .placeholder-chart {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100%;
      background: #f5f7fa;
      border-radius: 4px;
      
      h3 {
        margin-bottom: 10px;
        color: #333;
      }
      
      p {
        color: #666;
      }
    }
  }
  
  .timeline {
    padding: 10px;
  }
}
</style>