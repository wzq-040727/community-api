<template>
	<div class="login-container flx-center">
		<div class="login-box">
			<div class="login-form">
				<div class="login-logo">
					<!--					<img class="login-icon" :src="logo" alt="" />-->
					<h2 class="logo-text">智慧社区-后台管理系统</h2>
				</div>
				<div>
					<el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" size="large">
						<el-form-item prop="phone">
							<el-input v-model="loginForm.phone" placeholder="请输入手机号码">
								<template #prefix>
									<el-icon class="el-input__icon"><user /></el-icon>
								</template>
							</el-input>
						</el-form-item>
						<el-form-item prop="userPassword">
							<el-input type="password" v-model="loginForm.userPassword" placeholder="请输入密码" show-password autocomplete="new-password">
								<template #prefix>
									<el-icon class="el-input__icon"><lock /></el-icon>
								</template>
							</el-input>
						</el-form-item>
					</el-form>
					<div class="login-btn">
						<el-button size="large" type="primary" :loading="loading" @click="login(loginFormRef)"> 登录 </el-button>
						<el-button size="large" @click="resetForm(loginFormRef)">重置</el-button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script lang="ts" setup>
import logo from '@/assets/images/neuedu-v.04c859db5cc89b24c824a6cdb50b7a2a.svg';
import { ref, reactive, onMounted } from 'vue';
import { CircleClose, UserFilled } from '@element-plus/icons-vue';
import type { ElForm } from 'element-plus';
import { Login } from '@/api/interface/user';
import { ElMessage } from 'element-plus';
import { userLogin } from '@/api/modules/user';
import { GlobalStore } from '@/stores';
import { TabsStore } from '@/stores/tabs';
import { useRouter } from 'vue-router';
import { initDynamicRouter } from '@/router/dynamicRouter';

const globalStore = GlobalStore();
const tabStore = TabsStore();
const router = useRouter();

const loginForm = reactive<Login.ReqLoginForm>({
	phone: '18611111111',
	userPassword: '11',
	identityType: 'mall-admin',
});

const loading = ref(false);

// 定义 formRef（校验规则）
type FormInstance = InstanceType<typeof ElForm>;
const loginFormRef = ref<FormInstance>();
const loginRules = reactive({
	phone: [{ required: true, message: '请输入手机号码', trigger: 'blur' }],
	userPassword: [{ required: true, message: '请输入密码', trigger: 'blur' }],
});

const login = (formEl: FormInstance | undefined) => {
	if (!formEl) return;
	formEl.validate(async (valid) => {
		if (!valid) return;
		loading.value = true;
		try {
			// 1.执行登录接口
			const { body } = await userLogin(loginForm);
			globalStore.setToken(body.accessToken);
			globalStore.setUserInfo(body.userInfo);

			// 2.添加动态路由
			await initDynamicRouter();

			// 3.清除tab数据
			await tabStore.closeMultipleTab();

			// 4.跳转到首页
			await router.push('/index');
		} finally {
			loading.value = false;
		}
	});
};

// resetForm
const resetForm = (formEl: FormInstance | undefined) => {
	if (!formEl) return;
	formEl.resetFields();
};

onMounted(() => {
	// 监听enter事件（调用登录）
	document.onkeydown = (e: any) => {
		e = window.event || e;
		if (e.code === 'Enter' || e.code === 'enter' || e.code === 'NumpadEnter') {
			if (loading.value) return;
			login(loginFormRef.value);
		}
	};
});
</script>
<style lang="scss" scoped>
.login-container {
	height: 100%;
	min-height: 550px;
	background-color: #eeeeee;
}
.flx-center {
	display: flex;
	align-items: center;
	justify-content: center;
}
.login-box {
	position: relative;
	box-sizing: border-box;
	display: flex;
	justify-content: space-around;
	width: 480px;
	height: 600px;
	padding: 0 50px;
	background-color: hsl(0deg 0% 100% / 80%);
	border-radius: 10px;
}
.login-logo {
	display: flex;
	align-items: center;
	justify-content: center;
	img {
		width: 200px;
		height: 165px;
	}
	.logo-text {
		margin-top: 30px;
		margin-bottom: 50px;
		font-size: 30px;
		font-weight: bold;
		color: #34495e;
		white-space: nowrap;
	}
}
.el-form-item {
	margin-bottom: 40px;
}
.login-btn {
	display: flex;
	justify-content: space-between;
	width: 100%;
	margin-top: 40px;
	white-space: nowrap;
	.el-button {
		width: 185px;
	}
}
</style>
