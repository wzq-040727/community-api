import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import ElementPlus from 'element-plus';
import 'element-plus/dist/index.css';
import locale from 'element-plus/es/locale/lang/zh-cn'; // 因element-plus默认是英文，我们指定一下默认中文
// pinia store
import pinia from '@/stores/index';
// element icons
import * as Icons from '@element-plus/icons-vue';
import svgIcon from '@components/svgIcon/index.vue';

import '@/plugins/css/base.scss';
import '@/plugins/css/index.scss';
import '@/plugins/css/element.scss';
import { zhCn } from 'element-plus/es/locale/index.mjs';
const app = createApp(App);
// 注册ElementPlus
app.use(ElementPlus, {
	locale: zhCn, // 语言设置，使用新的中文语言包
	// size: Cookies.get('size') || 'medium' // 设置默认尺寸
});
// 注册element Icons组件
Object.keys(Icons).forEach((key) => {
	app.component(key, Icons[key as keyof typeof Icons]);
});
// 全局注册菜单图标
for (let i in Icons) {
	const icons = Icons as any;
	app.component(`ext-${icons[i].name}`, icons[i]);
}
app.component('svg-icon', svgIcon);
app.use(router);
app.use(pinia);
app.mount('#app');
