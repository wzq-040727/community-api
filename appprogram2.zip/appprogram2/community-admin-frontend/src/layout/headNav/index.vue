<template>
	<div class="header">
		<div class="logo">
			<transition name="fade">
				<span style="font-weight: bold; font-size: 20px">智慧社区</span>
			</transition>
		</div>
		<span class="pointer" @click="toggle">
			<svg-icon v-if="collapse" name="ext-Expand" :size="20"></svg-icon>
			<svg-icon v-else name="ext-Fold" :size="20"></svg-icon>
		</span>
		<div class="header-breadcrumb">
			<el-breadcrumb class="app-breadcrumb" separator-class="el-icon-arrow-right">
				<transition-group name="breadcrumb">
					<el-breadcrumb-item v-for="item in breadcrumbs" :key="item.path">
						<a @click.prevent="handleLink(item)">
							{{ item.name }}
						</a>
					</el-breadcrumb-item>
				</transition-group>
			</el-breadcrumb>
		</div>
		<div class="user-info">
			<el-row :gutter="18">
				<el-col :span="4"> <Fullscreen id="fullscreen" /> </el-col>
				<el-col style="margin-top: 2px" :span="8"> {{ globalStore.userInfo.userName }} </el-col>
				<el-col style="margin-top: 1px" :span="5"> <el-button icon="Close" link size="default" @click="userLogout">退出系统</el-button></el-col>
			</el-row>
		</div>
	</div>
</template>

<script lang="ts" setup>
import { ref, watch, onBeforeMount } from 'vue';
import { useRoute, useRouter, RouteLocationMatched } from 'vue-router';
import { compile } from 'path-to-regexp';
import logo from '@/assets/images/neuedu-v.04c859db5cc89b24c824a6cdb50b7a2a.svg';
import Fullscreen from './components/fullScreen.vue';
import { GlobalStore } from '@/stores';
import { TabsStore } from '@/stores/tabs';
import { ElMessage, ElMessageBox, ElNotification } from 'element-plus';

const globalStore = GlobalStore();
const tabStore = TabsStore();

const breadcrumbs = ref([] as Array<RouteLocationMatched>);
type Props = {
	collapse: boolean;
};

const userLogout = async () => {
	ElMessageBox.confirm('确定要退出登录吗?', '系统提示', {
		confirmButtonText: '确定',
		cancelButtonText: '取消',
		type: 'warning',
	}).then(async () => {
		globalStore.userInfo = {};
		globalStore.token = '';
		await tabStore.closeMultipleTab();
		await router.push('/login');
		ElNotification({
			title: '操作成功',
			message: '退出登录成功',
			type: 'info',
			duration: 3000,
		});
	});
};
let props = defineProps<Props>();

const route = useRoute();
const router = useRouter();

function getBreadcrumb() {
	let matched = route.matched.filter((item) => item.name);
	const first = matched[0];
	if (!isDashboard(first)) {
		matched = [{ path: '/', name: '首页' } as any].concat(matched);
	}
	breadcrumbs.value = matched.filter((item) => {
		return item.name !== 'layout';
	});
}

function isDashboard(route: RouteLocationMatched) {
	const name = route && route.name;
	if (!name) {
		return false;
	}
	return name.toString().trim().toLocaleLowerCase() === 'index'.toLocaleLowerCase();
}

function handleLink(item: any) {
	const { path } = item;

	router.push(pathCompile(path)).catch((err) => {
		console.warn(err);
	});
}

const pathCompile = (path: string) => {
	const { params } = route;
	const toPath = compile(path);
	return toPath(params);
};

let emit = defineEmits(['update:collapse']);

const toggle = () => {
	emit('update:collapse', !props.collapse);
};

watch(
	() => route.path,
	(path) => {
		getBreadcrumb();
	}
);

onBeforeMount(() => {
	getBreadcrumb();
});
</script>
<style lang="scss" scoped>
.user-info {
	position: absolute;
	width: 280px;
	right: 0px;
	font-size: 14px;
}
.logo {
	width: 130px;
	padding-right: 60px;
}
.header {
	height: 50px;
	display: flex;
	align-items: center;
	border-bottom: 1px solid #eee;
	padding: 5px 20px;
}
.pointer {
	cursor: pointer;
	svg {
		width: 1em;
		height: 1em;
	}
}
.header-breadcrumb {
	margin-left: 10px;
}
.el-breadcrumb__inner,
.el-breadcrumb__inner a {
	font-weight: 400 !important;
}

.app-breadcrumb.el-breadcrumb {
	display: inline-block;
	font-size: 14px;
	line-height: 50px;
	margin-left: 8px;
}
</style>
