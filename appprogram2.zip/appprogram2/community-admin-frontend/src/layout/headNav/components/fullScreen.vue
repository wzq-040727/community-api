<template>
	<div class="fullscreen">
		<el-image class="images" v-if="!isFullscreen" :src="Full" @click="toggle"></el-image>
		<el-image class="images" style="width: 15px" v-else :src="Exit" @click="toggle"></el-image>
	</div>
</template>

<script setup lang="ts">
import { useFullscreen } from '@vueuse/core';
import Full from '@/assets/icons/fullscreen.svg';
import Exit from '@/assets/icons/exit-fullscreen.svg';
const { toggle, isFullscreen } = useFullscreen();
</script>
<style lang="scss" scoped>
.images {
	width: 15px;
	margin-top: 5px;
	cursor: pointer;
}
</style>
