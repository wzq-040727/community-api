<template>
	<system-menu :collapse="collapse" class="el-menu-vertical-demo"></system-menu>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import SystemMenu from '@/components/menu/index.vue';
import { useRoute } from 'vue-router';

const route = useRoute();

type Props = {
	collapse: boolean;
};
let props = defineProps<Props>();
</script>
<style lang="scss" scoped>
.pl-1 {
	padding-left: 10px;
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
	width: 200px;
	min-height: 400px;
}
</style>
