<template>
	<el-container>
		<el-header>
			<head-nav v-model:collapse="isCollapse"></head-nav>
		</el-header>
		<el-container>
			<el-aside width="auto">
				<side-nav v-model:collapse="isCollapse"></side-nav>
			</el-aside>
			<el-main style="background-color: #f4f5f8; padding: 0">
				<el-container>
					<el-header style="height: 20px">
						<Tabs />
					</el-header>
					<el-main style="padding: 15px; margin-top: 20px">
						<router-view v-slot="{ Component, route }"> <component :is="Component" :key="route.path" v-if="isRouterShow" /> </router-view
					></el-main>
				</el-container>
			</el-main>
		</el-container>
	</el-container>
</template>

<script lang="ts" setup>
import { ref, provide } from 'vue';
import HeadNav from '@/layout/headNav/index.vue';
import SideNav from '@/layout/sideNav/index.vue';
import Tabs from '@/layout/tabs/index.vue';

// 刷新当前页面
const isRouterShow = ref(true);

const refreshCurrentPage = (val: boolean) => (isRouterShow.value = val);

let isCollapse = ref(false);
</script>
<style lang="scss" scoped>
.el-header {
	padding: 0;
}
.fade-enter-active,
.fade-leave-active {
	transition: opacity 0.1s;
}
.fade-enter,
.fade-leave-to {
	opacity: 0;
}
</style>
