import { defineStore } from 'pinia';
import piniaPersistConfig from './piniaPersist';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';
import router from '@/router/index';

/* tabsMenuProps */
export interface TabsMenuProps {
	icon: string;
	title: string;
	path: string;
	close: boolean;
}

/* TabsState */
export interface TabsState {
	tabsMenuList: TabsMenuProps[];
}

// TabsStore
export const TabsStore = defineStore({
	id: 'TabsState',
	state: (): TabsState => ({
		tabsMenuList: [],
	}),
	getters: {},
	actions: {
		// Add Tabs
		async addTabs(tabItem: TabsMenuProps) {
			// not add tabs white list
			if (this.tabsMenuList.every((item) => item.path !== tabItem.path)) {
				this.tabsMenuList.push(tabItem);
			}
		},
		// Remove Tabs
		async removeTabs(tabPath: string, isCurrent = true) {
			const tabsMenuList = this.tabsMenuList;
			if (isCurrent) {
				tabsMenuList.forEach((item, index) => {
					if (item.path !== tabPath) return;
					const nextTab = tabsMenuList[index + 1] || tabsMenuList[index - 1];
					if (!nextTab) return;
					router.push(nextTab.path);
				});
			}
			this.tabsMenuList = tabsMenuList.filter((item) => item.path !== tabPath);
		},
		// Close MultipleTab
		async closeMultipleTab(tabsMenuValue?: string) {
			this.tabsMenuList = this.tabsMenuList.filter((item) => {
				return item.path === tabsMenuValue || !item.close;
			});
		},
	},
	persist: piniaPersistConfig('TabsState'),
});
