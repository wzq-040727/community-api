import { defineStore } from 'pinia';
import { Menu } from '@/api/interface/auth';
import { getAuthMenuList } from '@/api/modules/auth';
import { getShowMenuList, getFlatArr } from '@/utils/util';

export interface AuthState {
	authMenuList: Menu.MenuOptions[];
}

// AuthStore
export const AuthStore = defineStore({
	id: 'AuthState',
	state: (): AuthState => ({
		// 当前页面的 router name，用来做按钮权限筛选
		// 菜单权限列表
		authMenuList: [],
	}),
	getters: {
		// 后端返回的菜单列表 ==> 这里没有经过任何处理
		getAuthMenuList: (state) => state.authMenuList,
		// 后端返回的菜单列表 ==> 左侧菜单栏渲染，需要去除 isHide == true
		getShowMenuList: (state) => getShowMenuList(state.authMenuList),
		// 扁平化之后的一维数组路由，主要用来添加动态路由
		getFlatMenuList: (state) => getFlatArr(state.authMenuList),
	},
	actions: {
		// loadAuthMenuList
		async loadAuthMenuList() {
			const { body } = await getAuthMenuList();
			this.authMenuList = body;
		},
	},
});
