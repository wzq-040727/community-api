export interface MenuOptions {
	path: string;
	name: string;
	children?: MenuOptions[];
}
