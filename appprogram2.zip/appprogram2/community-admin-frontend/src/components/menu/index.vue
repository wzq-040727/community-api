<template>
	<el-menu :default-active="route.path" :router="false" :collapse="collapse" :collapse-transition="false" :unique-opened="true">
		<SubMenu :menu-list="menuList" />
	</el-menu>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import { MenuOptions } from '@/components/menu/type';
import SubMenu from '@/components/menu/subMenu/index.vue';
import { useRoute } from 'vue-router';
import { AuthStore } from '@/stores/auth';

const route = useRoute();

const authStore = AuthStore();

type Props = {
	collapse: boolean;
};

defineProps<Props>();

const menuList = ref<MenuOptions[]>([]);

onMounted(async () => {
	if (authStore.getShowMenuList.length === 0) {
		await authStore.loadAuthMenuList();
	}
	menuList.value = authStore.authMenuList;
});
</script>
